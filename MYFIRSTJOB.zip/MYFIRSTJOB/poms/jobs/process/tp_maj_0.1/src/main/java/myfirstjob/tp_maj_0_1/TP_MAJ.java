// ============================================================================
//
// Copyright (c) 2006-2015, Talend SA
//
// Ce code source a été automatiquement généré par_Talend Open Studio for Data Integration
// / Soumis à la Licence Apache, Version 2.0 (la "Licence") ;
// votre utilisation de ce fichier doit respecter les termes de la Licence.
// Vous pouvez obtenir une copie de la Licence sur
// http://www.apache.org/licenses/LICENSE-2.0
// 
// Sauf lorsqu'explicitement prévu par la loi en vigueur ou accepté par écrit, le logiciel
// distribué sous la Licence est distribué "TEL QUEL",
// SANS GARANTIE OU CONDITION D'AUCUNE SORTE, expresse ou implicite.
// Consultez la Licence pour connaître la terminologie spécifique régissant les autorisations et
// les limites prévues par la Licence.

package myfirstjob.tp_maj_0_1;

import routines.Numeric;
import routines.DataOperation;
import routines.TalendDataGenerator;
import routines.TalendStringUtil;
import routines.TalendString;
import routines.StringHandling;
import routines.Relational;
import routines.TalendDate;
import routines.Mathematical;
import routines.system.*;
import routines.system.api.*;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import java.math.BigDecimal;
import java.io.ByteArrayOutputStream;
import java.io.ByteArrayInputStream;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.ObjectOutputStream;
import java.io.ObjectInputStream;
import java.io.IOException;
import java.util.Comparator;

@SuppressWarnings("unused")

/**
 * Job: TP_MAJ Purpose: <br>
 * Description: <br>
 * 
 * @author user@talend.com
 * @version 8.0.1.20211109_1610
 * @status
 */
public class TP_MAJ implements TalendJob {

	protected static void logIgnoredError(String message, Throwable cause) {
		System.err.println(message);
		if (cause != null) {
			cause.printStackTrace();
		}

	}

	public final Object obj = new Object();

	// for transmiting parameters purpose
	private Object valueObject = null;

	public Object getValueObject() {
		return this.valueObject;
	}

	public void setValueObject(Object valueObject) {
		this.valueObject = valueObject;
	}

	private final static String defaultCharset = java.nio.charset.Charset.defaultCharset().name();

	private final static String utf8Charset = "UTF-8";

	// contains type for every context property
	public class PropertiesWithType extends java.util.Properties {
		private static final long serialVersionUID = 1L;
		private java.util.Map<String, String> propertyTypes = new java.util.HashMap<>();

		public PropertiesWithType(java.util.Properties properties) {
			super(properties);
		}

		public PropertiesWithType() {
			super();
		}

		public void setContextType(String key, String type) {
			propertyTypes.put(key, type);
		}

		public String getContextType(String key) {
			return propertyTypes.get(key);
		}
	}

	// create and load default properties
	private java.util.Properties defaultProps = new java.util.Properties();

	// create application properties with default
	public class ContextProperties extends PropertiesWithType {

		private static final long serialVersionUID = 1L;

		public ContextProperties(java.util.Properties properties) {
			super(properties);
		}

		public ContextProperties() {
			super();
		}

		public void synchronizeContext() {

		}

		// if the stored or passed value is "<TALEND_NULL>" string, it mean null
		public String getStringValue(String key) {
			String origin_value = this.getProperty(key);
			if (NULL_VALUE_EXPRESSION_IN_COMMAND_STRING_FOR_CHILD_JOB_ONLY.equals(origin_value)) {
				return null;
			}
			return origin_value;
		}

	}

	protected ContextProperties context = new ContextProperties(); // will be instanciated by MS.

	public ContextProperties getContext() {
		return this.context;
	}

	private final String jobVersion = "0.1";
	private final String jobName = "TP_MAJ";
	private final String projectName = "MYFIRSTJOB";
	public Integer errorCode = null;
	private String currentComponent = "";

	private final java.util.Map<String, Object> globalMap = new java.util.HashMap<String, Object>();
	private final static java.util.Map<String, Object> junitGlobalMap = new java.util.HashMap<String, Object>();

	private final java.util.Map<String, Long> start_Hash = new java.util.HashMap<String, Long>();
	private final java.util.Map<String, Long> end_Hash = new java.util.HashMap<String, Long>();
	private final java.util.Map<String, Boolean> ok_Hash = new java.util.HashMap<String, Boolean>();
	public final java.util.List<String[]> globalBuffer = new java.util.ArrayList<String[]>();

	private RunStat runStat = new RunStat();

	// OSGi DataSource
	private final static String KEY_DB_DATASOURCES = "KEY_DB_DATASOURCES";

	private final static String KEY_DB_DATASOURCES_RAW = "KEY_DB_DATASOURCES_RAW";

	public void setDataSources(java.util.Map<String, javax.sql.DataSource> dataSources) {
		java.util.Map<String, routines.system.TalendDataSource> talendDataSources = new java.util.HashMap<String, routines.system.TalendDataSource>();
		for (java.util.Map.Entry<String, javax.sql.DataSource> dataSourceEntry : dataSources.entrySet()) {
			talendDataSources.put(dataSourceEntry.getKey(),
					new routines.system.TalendDataSource(dataSourceEntry.getValue()));
		}
		globalMap.put(KEY_DB_DATASOURCES, talendDataSources);
		globalMap.put(KEY_DB_DATASOURCES_RAW, new java.util.HashMap<String, javax.sql.DataSource>(dataSources));
	}

	public void setDataSourceReferences(List serviceReferences) throws Exception {

		java.util.Map<String, routines.system.TalendDataSource> talendDataSources = new java.util.HashMap<String, routines.system.TalendDataSource>();
		java.util.Map<String, javax.sql.DataSource> dataSources = new java.util.HashMap<String, javax.sql.DataSource>();

		for (java.util.Map.Entry<String, javax.sql.DataSource> entry : BundleUtils
				.getServices(serviceReferences, javax.sql.DataSource.class).entrySet()) {
			dataSources.put(entry.getKey(), entry.getValue());
			talendDataSources.put(entry.getKey(), new routines.system.TalendDataSource(entry.getValue()));
		}

		globalMap.put(KEY_DB_DATASOURCES, talendDataSources);
		globalMap.put(KEY_DB_DATASOURCES_RAW, new java.util.HashMap<String, javax.sql.DataSource>(dataSources));
	}

	private final java.io.ByteArrayOutputStream baos = new java.io.ByteArrayOutputStream();
	private final java.io.PrintStream errorMessagePS = new java.io.PrintStream(new java.io.BufferedOutputStream(baos));

	public String getExceptionStackTrace() {
		if ("failure".equals(this.getStatus())) {
			errorMessagePS.flush();
			return baos.toString();
		}
		return null;
	}

	private Exception exception;

	public Exception getException() {
		if ("failure".equals(this.getStatus())) {
			return this.exception;
		}
		return null;
	}

	private class TalendException extends Exception {

		private static final long serialVersionUID = 1L;

		private java.util.Map<String, Object> globalMap = null;
		private Exception e = null;
		private String currentComponent = null;
		private String virtualComponentName = null;

		public void setVirtualComponentName(String virtualComponentName) {
			this.virtualComponentName = virtualComponentName;
		}

		private TalendException(Exception e, String errorComponent, final java.util.Map<String, Object> globalMap) {
			this.currentComponent = errorComponent;
			this.globalMap = globalMap;
			this.e = e;
		}

		public Exception getException() {
			return this.e;
		}

		public String getCurrentComponent() {
			return this.currentComponent;
		}

		public String getExceptionCauseMessage(Exception e) {
			Throwable cause = e;
			String message = null;
			int i = 10;
			while (null != cause && 0 < i--) {
				message = cause.getMessage();
				if (null == message) {
					cause = cause.getCause();
				} else {
					break;
				}
			}
			if (null == message) {
				message = e.getClass().getName();
			}
			return message;
		}

		@Override
		public void printStackTrace() {
			if (!(e instanceof TalendException || e instanceof TDieException)) {
				if (virtualComponentName != null && currentComponent.indexOf(virtualComponentName + "_") == 0) {
					globalMap.put(virtualComponentName + "_ERROR_MESSAGE", getExceptionCauseMessage(e));
				}
				globalMap.put(currentComponent + "_ERROR_MESSAGE", getExceptionCauseMessage(e));
				System.err.println("Exception in component " + currentComponent + " (" + jobName + ")");
			}
			if (!(e instanceof TDieException)) {
				if (e instanceof TalendException) {
					e.printStackTrace();
				} else {
					e.printStackTrace();
					e.printStackTrace(errorMessagePS);
					TP_MAJ.this.exception = e;
				}
			}
			if (!(e instanceof TalendException)) {
				try {
					for (java.lang.reflect.Method m : this.getClass().getEnclosingClass().getMethods()) {
						if (m.getName().compareTo(currentComponent + "_error") == 0) {
							m.invoke(TP_MAJ.this, new Object[] { e, currentComponent, globalMap });
							break;
						}
					}

					if (!(e instanceof TDieException)) {
					}
				} catch (Exception e) {
					this.e.printStackTrace();
				}
			}
		}
	}

	public void tDie_1_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap)
			throws TalendException {

		end_Hash.put(errorComponent, System.currentTimeMillis());

		tDie_1_onSubJobError(exception, errorComponent, globalMap);
	}

	public void tFileInputExcel_1_error(Exception exception, String errorComponent,
			final java.util.Map<String, Object> globalMap) throws TalendException {

		end_Hash.put(errorComponent, System.currentTimeMillis());

		status = "failure";

		tFileInputExcel_1_onSubJobError(exception, errorComponent, globalMap);
	}

	public void tLogRow_1_error(Exception exception, String errorComponent,
			final java.util.Map<String, Object> globalMap) throws TalendException {

		end_Hash.put(errorComponent, System.currentTimeMillis());

		status = "failure";

		tFileInputExcel_1_onSubJobError(exception, errorComponent, globalMap);
	}

	public void tFilterColumns_1_error(Exception exception, String errorComponent,
			final java.util.Map<String, Object> globalMap) throws TalendException {

		end_Hash.put(errorComponent, System.currentTimeMillis());

		status = "failure";

		tFileInputExcel_1_onSubJobError(exception, errorComponent, globalMap);
	}

	public void tMap_1_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap)
			throws TalendException {

		end_Hash.put(errorComponent, System.currentTimeMillis());

		status = "failure";

		tFileInputExcel_1_onSubJobError(exception, errorComponent, globalMap);
	}

	public void tFilterRow_1_error(Exception exception, String errorComponent,
			final java.util.Map<String, Object> globalMap) throws TalendException {

		end_Hash.put(errorComponent, System.currentTimeMillis());

		status = "failure";

		tFileInputExcel_1_onSubJobError(exception, errorComponent, globalMap);
	}

	public void tMap_2_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap)
			throws TalendException {

		end_Hash.put(errorComponent, System.currentTimeMillis());

		status = "failure";

		tFileInputExcel_1_onSubJobError(exception, errorComponent, globalMap);
	}

	public void tLogRow_5_error(Exception exception, String errorComponent,
			final java.util.Map<String, Object> globalMap) throws TalendException {

		end_Hash.put(errorComponent, System.currentTimeMillis());

		status = "failure";

		tFileInputExcel_1_onSubJobError(exception, errorComponent, globalMap);
	}

	public void tFileOutputDelimited_2_error(Exception exception, String errorComponent,
			final java.util.Map<String, Object> globalMap) throws TalendException {

		end_Hash.put(errorComponent, System.currentTimeMillis());

		status = "failure";

		tFileInputExcel_1_onSubJobError(exception, errorComponent, globalMap);
	}

	public void tLogRow_6_error(Exception exception, String errorComponent,
			final java.util.Map<String, Object> globalMap) throws TalendException {

		end_Hash.put(errorComponent, System.currentTimeMillis());

		status = "failure";

		tFileInputExcel_1_onSubJobError(exception, errorComponent, globalMap);
	}

	public void tFileOutputDelimited_3_error(Exception exception, String errorComponent,
			final java.util.Map<String, Object> globalMap) throws TalendException {

		end_Hash.put(errorComponent, System.currentTimeMillis());

		status = "failure";

		tFileInputExcel_1_onSubJobError(exception, errorComponent, globalMap);
	}

	public void tLogRow_4_error(Exception exception, String errorComponent,
			final java.util.Map<String, Object> globalMap) throws TalendException {

		end_Hash.put(errorComponent, System.currentTimeMillis());

		status = "failure";

		tFileInputExcel_1_onSubJobError(exception, errorComponent, globalMap);
	}

	public void tFileOutputXML_1_error(Exception exception, String errorComponent,
			final java.util.Map<String, Object> globalMap) throws TalendException {

		end_Hash.put(errorComponent, System.currentTimeMillis());

		status = "failure";

		tFileInputExcel_1_onSubJobError(exception, errorComponent, globalMap);
	}

	public void tLogRow_7_error(Exception exception, String errorComponent,
			final java.util.Map<String, Object> globalMap) throws TalendException {

		end_Hash.put(errorComponent, System.currentTimeMillis());

		status = "failure";

		tFileInputExcel_1_onSubJobError(exception, errorComponent, globalMap);
	}

	public void tFileOutputExcel_1_error(Exception exception, String errorComponent,
			final java.util.Map<String, Object> globalMap) throws TalendException {

		end_Hash.put(errorComponent, System.currentTimeMillis());

		status = "failure";

		tFileInputExcel_1_onSubJobError(exception, errorComponent, globalMap);
	}

	public void tLogRow_8_error(Exception exception, String errorComponent,
			final java.util.Map<String, Object> globalMap) throws TalendException {

		end_Hash.put(errorComponent, System.currentTimeMillis());

		status = "failure";

		tFileInputExcel_1_onSubJobError(exception, errorComponent, globalMap);
	}

	public void tFileOutputExcel_2_error(Exception exception, String errorComponent,
			final java.util.Map<String, Object> globalMap) throws TalendException {

		end_Hash.put(errorComponent, System.currentTimeMillis());

		status = "failure";

		tFileInputExcel_1_onSubJobError(exception, errorComponent, globalMap);
	}

	public void tLogRow_9_error(Exception exception, String errorComponent,
			final java.util.Map<String, Object> globalMap) throws TalendException {

		end_Hash.put(errorComponent, System.currentTimeMillis());

		status = "failure";

		tFileInputExcel_1_onSubJobError(exception, errorComponent, globalMap);
	}

	public void tFileOutputExcel_3_error(Exception exception, String errorComponent,
			final java.util.Map<String, Object> globalMap) throws TalendException {

		end_Hash.put(errorComponent, System.currentTimeMillis());

		status = "failure";

		tFileInputExcel_1_onSubJobError(exception, errorComponent, globalMap);
	}

	public void tFileOutputDelimited_1_error(Exception exception, String errorComponent,
			final java.util.Map<String, Object> globalMap) throws TalendException {

		end_Hash.put(errorComponent, System.currentTimeMillis());

		status = "failure";

		tFileInputExcel_1_onSubJobError(exception, errorComponent, globalMap);
	}

	public void tFileInputDelimited_1_error(Exception exception, String errorComponent,
			final java.util.Map<String, Object> globalMap) throws TalendException {

		end_Hash.put(errorComponent, System.currentTimeMillis());

		status = "failure";

		tFileInputDelimited_1_onSubJobError(exception, errorComponent, globalMap);
	}

	public void tLogRow_2_error(Exception exception, String errorComponent,
			final java.util.Map<String, Object> globalMap) throws TalendException {

		end_Hash.put(errorComponent, System.currentTimeMillis());

		status = "failure";

		tFileInputDelimited_1_onSubJobError(exception, errorComponent, globalMap);
	}

	public void tFileInputXML_1_error(Exception exception, String errorComponent,
			final java.util.Map<String, Object> globalMap) throws TalendException {

		end_Hash.put(errorComponent, System.currentTimeMillis());

		status = "failure";

		tFileInputXML_1_onSubJobError(exception, errorComponent, globalMap);
	}

	public void tLogRow_3_error(Exception exception, String errorComponent,
			final java.util.Map<String, Object> globalMap) throws TalendException {

		end_Hash.put(errorComponent, System.currentTimeMillis());

		status = "failure";

		tFileInputXML_1_onSubJobError(exception, errorComponent, globalMap);
	}

	public void tMsgBox_1_error(Exception exception, String errorComponent,
			final java.util.Map<String, Object> globalMap) throws TalendException {

		end_Hash.put(errorComponent, System.currentTimeMillis());

		status = "failure";

		tMsgBox_1_onSubJobError(exception, errorComponent, globalMap);
	}

	public void tWarn_2_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap)
			throws TalendException {

		end_Hash.put(errorComponent, System.currentTimeMillis());

		status = "failure";

		tWarn_2_onSubJobError(exception, errorComponent, globalMap);
	}

	public void tMsgBox_2_error(Exception exception, String errorComponent,
			final java.util.Map<String, Object> globalMap) throws TalendException {

		end_Hash.put(errorComponent, System.currentTimeMillis());

		status = "failure";

		tMsgBox_2_onSubJobError(exception, errorComponent, globalMap);
	}

	public void tWarn_3_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap)
			throws TalendException {

		end_Hash.put(errorComponent, System.currentTimeMillis());

		status = "failure";

		tWarn_3_onSubJobError(exception, errorComponent, globalMap);
	}

	public void tPostjob_1_error(Exception exception, String errorComponent,
			final java.util.Map<String, Object> globalMap) throws TalendException {

		end_Hash.put(errorComponent, System.currentTimeMillis());

		status = "failure";

		tPostjob_1_onSubJobError(exception, errorComponent, globalMap);
	}

	public void tPrejob_1_error(Exception exception, String errorComponent,
			final java.util.Map<String, Object> globalMap) throws TalendException {

		end_Hash.put(errorComponent, System.currentTimeMillis());

		status = "failure";

		tPrejob_1_onSubJobError(exception, errorComponent, globalMap);
	}

	public void tWarn_1_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap)
			throws TalendException {

		end_Hash.put(errorComponent, System.currentTimeMillis());

		status = "failure";

		tWarn_1_onSubJobError(exception, errorComponent, globalMap);
	}

	public void tAdvancedHash_row2_error(Exception exception, String errorComponent,
			final java.util.Map<String, Object> globalMap) throws TalendException {

		end_Hash.put(errorComponent, System.currentTimeMillis());

		status = "failure";

		tFileInputDelimited_1_onSubJobError(exception, errorComponent, globalMap);
	}

	public void tAdvancedHash_row6_error(Exception exception, String errorComponent,
			final java.util.Map<String, Object> globalMap) throws TalendException {

		end_Hash.put(errorComponent, System.currentTimeMillis());

		status = "failure";

		tFileInputXML_1_onSubJobError(exception, errorComponent, globalMap);
	}

	public void tSortRow_1_SortOut_error(Exception exception, String errorComponent,
			final java.util.Map<String, Object> globalMap) throws TalendException {

		tSortRow_1_SortIn_error(exception, errorComponent, globalMap);

	}

	public void tSortRow_1_SortIn_error(Exception exception, String errorComponent,
			final java.util.Map<String, Object> globalMap) throws TalendException {

		end_Hash.put(errorComponent, System.currentTimeMillis());

		status = "failure";

		tFileInputExcel_1_onSubJobError(exception, errorComponent, globalMap);
	}

	public void tSortRow_2_SortOut_error(Exception exception, String errorComponent,
			final java.util.Map<String, Object> globalMap) throws TalendException {

		tSortRow_2_SortIn_error(exception, errorComponent, globalMap);

	}

	public void tSortRow_2_SortIn_error(Exception exception, String errorComponent,
			final java.util.Map<String, Object> globalMap) throws TalendException {

		end_Hash.put(errorComponent, System.currentTimeMillis());

		status = "failure";

		tFileInputExcel_1_onSubJobError(exception, errorComponent, globalMap);
	}

	public void tSortRow_3_SortOut_error(Exception exception, String errorComponent,
			final java.util.Map<String, Object> globalMap) throws TalendException {

		tSortRow_3_SortIn_error(exception, errorComponent, globalMap);

	}

	public void tSortRow_3_SortIn_error(Exception exception, String errorComponent,
			final java.util.Map<String, Object> globalMap) throws TalendException {

		end_Hash.put(errorComponent, System.currentTimeMillis());

		status = "failure";

		tFileInputExcel_1_onSubJobError(exception, errorComponent, globalMap);
	}

	public void tAggregateRow_1_AGGOUT_error(Exception exception, String errorComponent,
			final java.util.Map<String, Object> globalMap) throws TalendException {

		tAggregateRow_1_AGGIN_error(exception, errorComponent, globalMap);

	}

	public void tAggregateRow_1_AGGIN_error(Exception exception, String errorComponent,
			final java.util.Map<String, Object> globalMap) throws TalendException {

		end_Hash.put(errorComponent, System.currentTimeMillis());

		status = "failure";

		tFileInputExcel_1_onSubJobError(exception, errorComponent, globalMap);
	}

	public void tSortRow_4_SortOut_error(Exception exception, String errorComponent,
			final java.util.Map<String, Object> globalMap) throws TalendException {

		tSortRow_4_SortIn_error(exception, errorComponent, globalMap);

	}

	public void tSortRow_4_SortIn_error(Exception exception, String errorComponent,
			final java.util.Map<String, Object> globalMap) throws TalendException {

		end_Hash.put(errorComponent, System.currentTimeMillis());

		status = "failure";

		tFileInputExcel_1_onSubJobError(exception, errorComponent, globalMap);
	}

	public void tSortRow_5_SortOut_error(Exception exception, String errorComponent,
			final java.util.Map<String, Object> globalMap) throws TalendException {

		tSortRow_5_SortIn_error(exception, errorComponent, globalMap);

	}

	public void tSortRow_5_SortIn_error(Exception exception, String errorComponent,
			final java.util.Map<String, Object> globalMap) throws TalendException {

		end_Hash.put(errorComponent, System.currentTimeMillis());

		status = "failure";

		tFileInputExcel_1_onSubJobError(exception, errorComponent, globalMap);
	}

	public void tDie_1_onSubJobError(Exception exception, String errorComponent,
			final java.util.Map<String, Object> globalMap) throws TalendException {

		resumeUtil.addLog("SYSTEM_LOG", "NODE:" + errorComponent, "", Thread.currentThread().getId() + "", "ERROR", "",
				exception.getMessage(), ResumeUtil.getExceptionStackTrace(exception), "");

		try {

			if (this.execStat) {
				runStat.updateStatOnConnection("OnSubjobError1", 0, "error");
			}

			errorCode = null;
			tFileInputExcel_1Process(globalMap);
			if (!"failure".equals(status)) {
				status = "end";
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public void tFileInputExcel_1_onSubJobError(Exception exception, String errorComponent,
			final java.util.Map<String, Object> globalMap) throws TalendException {

		resumeUtil.addLog("SYSTEM_LOG", "NODE:" + errorComponent, "", Thread.currentThread().getId() + "", "FATAL", "",
				exception.getMessage(), ResumeUtil.getExceptionStackTrace(exception), "");

	}

	public void tFileInputDelimited_1_onSubJobError(Exception exception, String errorComponent,
			final java.util.Map<String, Object> globalMap) throws TalendException {

		resumeUtil.addLog("SYSTEM_LOG", "NODE:" + errorComponent, "", Thread.currentThread().getId() + "", "FATAL", "",
				exception.getMessage(), ResumeUtil.getExceptionStackTrace(exception), "");

	}

	public void tFileInputXML_1_onSubJobError(Exception exception, String errorComponent,
			final java.util.Map<String, Object> globalMap) throws TalendException {

		resumeUtil.addLog("SYSTEM_LOG", "NODE:" + errorComponent, "", Thread.currentThread().getId() + "", "FATAL", "",
				exception.getMessage(), ResumeUtil.getExceptionStackTrace(exception), "");

	}

	public void tMsgBox_1_onSubJobError(Exception exception, String errorComponent,
			final java.util.Map<String, Object> globalMap) throws TalendException {

		resumeUtil.addLog("SYSTEM_LOG", "NODE:" + errorComponent, "", Thread.currentThread().getId() + "", "FATAL", "",
				exception.getMessage(), ResumeUtil.getExceptionStackTrace(exception), "");

	}

	public void tWarn_2_onSubJobError(Exception exception, String errorComponent,
			final java.util.Map<String, Object> globalMap) throws TalendException {

		resumeUtil.addLog("SYSTEM_LOG", "NODE:" + errorComponent, "", Thread.currentThread().getId() + "", "FATAL", "",
				exception.getMessage(), ResumeUtil.getExceptionStackTrace(exception), "");

	}

	public void tMsgBox_2_onSubJobError(Exception exception, String errorComponent,
			final java.util.Map<String, Object> globalMap) throws TalendException {

		resumeUtil.addLog("SYSTEM_LOG", "NODE:" + errorComponent, "", Thread.currentThread().getId() + "", "FATAL", "",
				exception.getMessage(), ResumeUtil.getExceptionStackTrace(exception), "");

	}

	public void tWarn_3_onSubJobError(Exception exception, String errorComponent,
			final java.util.Map<String, Object> globalMap) throws TalendException {

		resumeUtil.addLog("SYSTEM_LOG", "NODE:" + errorComponent, "", Thread.currentThread().getId() + "", "FATAL", "",
				exception.getMessage(), ResumeUtil.getExceptionStackTrace(exception), "");

	}

	public void tPostjob_1_onSubJobError(Exception exception, String errorComponent,
			final java.util.Map<String, Object> globalMap) throws TalendException {

		resumeUtil.addLog("SYSTEM_LOG", "NODE:" + errorComponent, "", Thread.currentThread().getId() + "", "FATAL", "",
				exception.getMessage(), ResumeUtil.getExceptionStackTrace(exception), "");

	}

	public void tPrejob_1_onSubJobError(Exception exception, String errorComponent,
			final java.util.Map<String, Object> globalMap) throws TalendException {

		resumeUtil.addLog("SYSTEM_LOG", "NODE:" + errorComponent, "", Thread.currentThread().getId() + "", "FATAL", "",
				exception.getMessage(), ResumeUtil.getExceptionStackTrace(exception), "");

	}

	public void tWarn_1_onSubJobError(Exception exception, String errorComponent,
			final java.util.Map<String, Object> globalMap) throws TalendException {

		resumeUtil.addLog("SYSTEM_LOG", "NODE:" + errorComponent, "", Thread.currentThread().getId() + "", "FATAL", "",
				exception.getMessage(), ResumeUtil.getExceptionStackTrace(exception), "");

	}

	public void tDie_1Process(final java.util.Map<String, Object> globalMap) throws TalendException {
		globalMap.put("tDie_1_SUBPROCESS_STATE", 0);

		final boolean execStat = this.execStat;

		String iterateId = "";

		String currentComponent = "";
		java.util.Map<String, Object> resourceMap = new java.util.HashMap<String, Object>();

		try {
			// TDI-39566 avoid throwing an useless Exception
			boolean resumeIt = true;
			if (globalResumeTicket == false && resumeEntryMethodName != null) {
				String currentMethodName = new java.lang.Exception().getStackTrace()[0].getMethodName();
				resumeIt = resumeEntryMethodName.equals(currentMethodName);
			}
			if (resumeIt || globalResumeTicket) { // start the resume
				globalResumeTicket = true;

				/**
				 * [tDie_1 begin ] start
				 */

				ok_Hash.put("tDie_1", false);
				start_Hash.put("tDie_1", System.currentTimeMillis());

				currentComponent = "tDie_1";

				int tos_count_tDie_1 = 0;

				/**
				 * [tDie_1 begin ] stop
				 */

				/**
				 * [tDie_1 main ] start
				 */

				currentComponent = "tDie_1";

				try {
					globalMap.put("tDie_1_DIE_PRIORITY", 5);
					System.err.println("the end is near");

					globalMap.put("tDie_1_DIE_MESSAGE", "the end is near");
					globalMap.put("tDie_1_DIE_MESSAGES", "the end is near");

				} catch (Exception | Error e_tDie_1) {
					globalMap.put("tDie_1_ERROR_MESSAGE", e_tDie_1.getMessage());
					logIgnoredError(
							String.format("tDie_1 - tDie failed to log message due to internal error: %s", e_tDie_1),
							e_tDie_1);
				}

				currentComponent = "tDie_1";
				status = "failure";
				errorCode = new Integer(4);
				globalMap.put("tDie_1_DIE_CODE", errorCode);

				if (true) {
					throw new TDieException();
				}

				tos_count_tDie_1++;

				/**
				 * [tDie_1 main ] stop
				 */

				/**
				 * [tDie_1 process_data_begin ] start
				 */

				currentComponent = "tDie_1";

				/**
				 * [tDie_1 process_data_begin ] stop
				 */

				/**
				 * [tDie_1 process_data_end ] start
				 */

				currentComponent = "tDie_1";

				/**
				 * [tDie_1 process_data_end ] stop
				 */

				/**
				 * [tDie_1 end ] start
				 */

				currentComponent = "tDie_1";

				ok_Hash.put("tDie_1", true);
				end_Hash.put("tDie_1", System.currentTimeMillis());

				/**
				 * [tDie_1 end ] stop
				 */
			} // end the resume

		} catch (java.lang.Exception e) {

			TalendException te = new TalendException(e, currentComponent, globalMap);

			throw te;
		} catch (java.lang.Error error) {

			runStat.stopThreadStat();

			throw error;
		} finally {

			try {

				/**
				 * [tDie_1 finally ] start
				 */

				currentComponent = "tDie_1";

				/**
				 * [tDie_1 finally ] stop
				 */
			} catch (java.lang.Exception e) {
				// ignore
			} catch (java.lang.Error error) {
				// ignore
			}
			resourceMap = null;
		}

		globalMap.put("tDie_1_SUBPROCESS_STATE", 1);
	}

	public static class row21Struct implements routines.system.IPersistableRow<row21Struct> {
		final static byte[] commonByteArrayLock_MYFIRSTJOB_TP_MAJ = new byte[0];
		static byte[] commonByteArray_MYFIRSTJOB_TP_MAJ = new byte[0];
		protected static final int DEFAULT_HASHCODE = 1;
		protected static final int PRIME = 31;
		protected int hashCode = DEFAULT_HASHCODE;
		public boolean hashCodeDirty = true;

		public String loopKey;

		public Integer id;

		public Integer getId() {
			return this.id;
		}

		public String title;

		public String getTitle() {
			return this.title;
		}

		public java.util.Date date;

		public java.util.Date getDate() {
			return this.date;
		}

		public Integer budget;

		public Integer getBudget() {
			return this.budget;
		}

		public Long revenue;

		public Long getRevenue() {
			return this.revenue;
		}

		public Long gain_perte;

		public Long getGain_perte() {
			return this.gain_perte;
		}

		@Override
		public int hashCode() {
			if (this.hashCodeDirty) {
				final int prime = PRIME;
				int result = DEFAULT_HASHCODE;

				result = prime * result + ((this.id == null) ? 0 : this.id.hashCode());

				this.hashCode = result;
				this.hashCodeDirty = false;
			}
			return this.hashCode;
		}

		@Override
		public boolean equals(Object obj) {
			if (this == obj)
				return true;
			if (obj == null)
				return false;
			if (getClass() != obj.getClass())
				return false;
			final row21Struct other = (row21Struct) obj;

			if (this.id == null) {
				if (other.id != null)
					return false;

			} else if (!this.id.equals(other.id))

				return false;

			return true;
		}

		public void copyDataTo(row21Struct other) {

			other.id = this.id;
			other.title = this.title;
			other.date = this.date;
			other.budget = this.budget;
			other.revenue = this.revenue;
			other.gain_perte = this.gain_perte;

		}

		public void copyKeysDataTo(row21Struct other) {

			other.id = this.id;

		}

		private Integer readInteger(ObjectInputStream dis) throws IOException {
			Integer intReturn;
			int length = 0;
			length = dis.readByte();
			if (length == -1) {
				intReturn = null;
			} else {
				intReturn = dis.readInt();
			}
			return intReturn;
		}

		private Integer readInteger(org.jboss.marshalling.Unmarshaller dis) throws IOException {
			Integer intReturn;
			int length = 0;
			length = dis.readByte();
			if (length == -1) {
				intReturn = null;
			} else {
				intReturn = dis.readInt();
			}
			return intReturn;
		}

		private void writeInteger(Integer intNum, ObjectOutputStream dos) throws IOException {
			if (intNum == null) {
				dos.writeByte(-1);
			} else {
				dos.writeByte(0);
				dos.writeInt(intNum);
			}
		}

		private void writeInteger(Integer intNum, org.jboss.marshalling.Marshaller marshaller) throws IOException {
			if (intNum == null) {
				marshaller.writeByte(-1);
			} else {
				marshaller.writeByte(0);
				marshaller.writeInt(intNum);
			}
		}

		private String readString(ObjectInputStream dis) throws IOException {
			String strReturn = null;
			int length = 0;
			length = dis.readInt();
			if (length == -1) {
				strReturn = null;
			} else {
				if (length > commonByteArray_MYFIRSTJOB_TP_MAJ.length) {
					if (length < 1024 && commonByteArray_MYFIRSTJOB_TP_MAJ.length == 0) {
						commonByteArray_MYFIRSTJOB_TP_MAJ = new byte[1024];
					} else {
						commonByteArray_MYFIRSTJOB_TP_MAJ = new byte[2 * length];
					}
				}
				dis.readFully(commonByteArray_MYFIRSTJOB_TP_MAJ, 0, length);
				strReturn = new String(commonByteArray_MYFIRSTJOB_TP_MAJ, 0, length, utf8Charset);
			}
			return strReturn;
		}

		private String readString(org.jboss.marshalling.Unmarshaller unmarshaller) throws IOException {
			String strReturn = null;
			int length = 0;
			length = unmarshaller.readInt();
			if (length == -1) {
				strReturn = null;
			} else {
				if (length > commonByteArray_MYFIRSTJOB_TP_MAJ.length) {
					if (length < 1024 && commonByteArray_MYFIRSTJOB_TP_MAJ.length == 0) {
						commonByteArray_MYFIRSTJOB_TP_MAJ = new byte[1024];
					} else {
						commonByteArray_MYFIRSTJOB_TP_MAJ = new byte[2 * length];
					}
				}
				unmarshaller.readFully(commonByteArray_MYFIRSTJOB_TP_MAJ, 0, length);
				strReturn = new String(commonByteArray_MYFIRSTJOB_TP_MAJ, 0, length, utf8Charset);
			}
			return strReturn;
		}

		private void writeString(String str, ObjectOutputStream dos) throws IOException {
			if (str == null) {
				dos.writeInt(-1);
			} else {
				byte[] byteArray = str.getBytes(utf8Charset);
				dos.writeInt(byteArray.length);
				dos.write(byteArray);
			}
		}

		private void writeString(String str, org.jboss.marshalling.Marshaller marshaller) throws IOException {
			if (str == null) {
				marshaller.writeInt(-1);
			} else {
				byte[] byteArray = str.getBytes(utf8Charset);
				marshaller.writeInt(byteArray.length);
				marshaller.write(byteArray);
			}
		}

		private java.util.Date readDate(ObjectInputStream dis) throws IOException {
			java.util.Date dateReturn = null;
			int length = 0;
			length = dis.readByte();
			if (length == -1) {
				dateReturn = null;
			} else {
				dateReturn = new Date(dis.readLong());
			}
			return dateReturn;
		}

		private java.util.Date readDate(org.jboss.marshalling.Unmarshaller unmarshaller) throws IOException {
			java.util.Date dateReturn = null;
			int length = 0;
			length = unmarshaller.readByte();
			if (length == -1) {
				dateReturn = null;
			} else {
				dateReturn = new Date(unmarshaller.readLong());
			}
			return dateReturn;
		}

		private void writeDate(java.util.Date date1, ObjectOutputStream dos) throws IOException {
			if (date1 == null) {
				dos.writeByte(-1);
			} else {
				dos.writeByte(0);
				dos.writeLong(date1.getTime());
			}
		}

		private void writeDate(java.util.Date date1, org.jboss.marshalling.Marshaller marshaller) throws IOException {
			if (date1 == null) {
				marshaller.writeByte(-1);
			} else {
				marshaller.writeByte(0);
				marshaller.writeLong(date1.getTime());
			}
		}

		public void readData(ObjectInputStream dis) {

			synchronized (commonByteArrayLock_MYFIRSTJOB_TP_MAJ) {

				try {

					int length = 0;

					this.id = readInteger(dis);

					this.title = readString(dis);

					this.date = readDate(dis);

					this.budget = readInteger(dis);

					length = dis.readByte();
					if (length == -1) {
						this.revenue = null;
					} else {
						this.revenue = dis.readLong();
					}

					length = dis.readByte();
					if (length == -1) {
						this.gain_perte = null;
					} else {
						this.gain_perte = dis.readLong();
					}

				} catch (IOException e) {
					throw new RuntimeException(e);

				}

			}

		}

		public void readData(org.jboss.marshalling.Unmarshaller dis) {

			synchronized (commonByteArrayLock_MYFIRSTJOB_TP_MAJ) {

				try {

					int length = 0;

					this.id = readInteger(dis);

					this.title = readString(dis);

					this.date = readDate(dis);

					this.budget = readInteger(dis);

					length = dis.readByte();
					if (length == -1) {
						this.revenue = null;
					} else {
						this.revenue = dis.readLong();
					}

					length = dis.readByte();
					if (length == -1) {
						this.gain_perte = null;
					} else {
						this.gain_perte = dis.readLong();
					}

				} catch (IOException e) {
					throw new RuntimeException(e);

				}

			}

		}

		public void writeData(ObjectOutputStream dos) {
			try {

				// Integer

				writeInteger(this.id, dos);

				// String

				writeString(this.title, dos);

				// java.util.Date

				writeDate(this.date, dos);

				// Integer

				writeInteger(this.budget, dos);

				// Long

				if (this.revenue == null) {
					dos.writeByte(-1);
				} else {
					dos.writeByte(0);
					dos.writeLong(this.revenue);
				}

				// Long

				if (this.gain_perte == null) {
					dos.writeByte(-1);
				} else {
					dos.writeByte(0);
					dos.writeLong(this.gain_perte);
				}

			} catch (IOException e) {
				throw new RuntimeException(e);
			}

		}

		public void writeData(org.jboss.marshalling.Marshaller dos) {
			try {

				// Integer

				writeInteger(this.id, dos);

				// String

				writeString(this.title, dos);

				// java.util.Date

				writeDate(this.date, dos);

				// Integer

				writeInteger(this.budget, dos);

				// Long

				if (this.revenue == null) {
					dos.writeByte(-1);
				} else {
					dos.writeByte(0);
					dos.writeLong(this.revenue);
				}

				// Long

				if (this.gain_perte == null) {
					dos.writeByte(-1);
				} else {
					dos.writeByte(0);
					dos.writeLong(this.gain_perte);
				}

			} catch (IOException e) {
				throw new RuntimeException(e);
			}

		}

		public String toString() {

			StringBuilder sb = new StringBuilder();
			sb.append(super.toString());
			sb.append("[");
			sb.append("id=" + String.valueOf(id));
			sb.append(",title=" + title);
			sb.append(",date=" + String.valueOf(date));
			sb.append(",budget=" + String.valueOf(budget));
			sb.append(",revenue=" + String.valueOf(revenue));
			sb.append(",gain_perte=" + String.valueOf(gain_perte));
			sb.append("]");

			return sb.toString();
		}

		/**
		 * Compare keys
		 */
		public int compareTo(row21Struct other) {

			int returnValue = -1;

			returnValue = checkNullsAndCompare(this.id, other.id);
			if (returnValue != 0) {
				return returnValue;
			}

			return returnValue;
		}

		private int checkNullsAndCompare(Object object1, Object object2) {
			int returnValue = 0;
			if (object1 instanceof Comparable && object2 instanceof Comparable) {
				returnValue = ((Comparable) object1).compareTo(object2);
			} else if (object1 != null && object2 != null) {
				returnValue = compareStrings(object1.toString(), object2.toString());
			} else if (object1 == null && object2 != null) {
				returnValue = 1;
			} else if (object1 != null && object2 == null) {
				returnValue = -1;
			} else {
				returnValue = 0;
			}

			return returnValue;
		}

		private int compareStrings(String string1, String string2) {
			return string1.compareTo(string2);
		}

	}

	public static class OnRowsEndStructtSortRow_5
			implements routines.system.IPersistableRow<OnRowsEndStructtSortRow_5> {
		final static byte[] commonByteArrayLock_MYFIRSTJOB_TP_MAJ = new byte[0];
		static byte[] commonByteArray_MYFIRSTJOB_TP_MAJ = new byte[0];
		protected static final int DEFAULT_HASHCODE = 1;
		protected static final int PRIME = 31;
		protected int hashCode = DEFAULT_HASHCODE;
		public boolean hashCodeDirty = true;

		public String loopKey;

		public Integer id;

		public Integer getId() {
			return this.id;
		}

		public String title;

		public String getTitle() {
			return this.title;
		}

		public java.util.Date date;

		public java.util.Date getDate() {
			return this.date;
		}

		public Integer budget;

		public Integer getBudget() {
			return this.budget;
		}

		public Long revenue;

		public Long getRevenue() {
			return this.revenue;
		}

		public Long gain_perte;

		public Long getGain_perte() {
			return this.gain_perte;
		}

		@Override
		public int hashCode() {
			if (this.hashCodeDirty) {
				final int prime = PRIME;
				int result = DEFAULT_HASHCODE;

				result = prime * result + ((this.id == null) ? 0 : this.id.hashCode());

				this.hashCode = result;
				this.hashCodeDirty = false;
			}
			return this.hashCode;
		}

		@Override
		public boolean equals(Object obj) {
			if (this == obj)
				return true;
			if (obj == null)
				return false;
			if (getClass() != obj.getClass())
				return false;
			final OnRowsEndStructtSortRow_5 other = (OnRowsEndStructtSortRow_5) obj;

			if (this.id == null) {
				if (other.id != null)
					return false;

			} else if (!this.id.equals(other.id))

				return false;

			return true;
		}

		public void copyDataTo(OnRowsEndStructtSortRow_5 other) {

			other.id = this.id;
			other.title = this.title;
			other.date = this.date;
			other.budget = this.budget;
			other.revenue = this.revenue;
			other.gain_perte = this.gain_perte;

		}

		public void copyKeysDataTo(OnRowsEndStructtSortRow_5 other) {

			other.id = this.id;

		}

		private Integer readInteger(ObjectInputStream dis) throws IOException {
			Integer intReturn;
			int length = 0;
			length = dis.readByte();
			if (length == -1) {
				intReturn = null;
			} else {
				intReturn = dis.readInt();
			}
			return intReturn;
		}

		private Integer readInteger(org.jboss.marshalling.Unmarshaller dis) throws IOException {
			Integer intReturn;
			int length = 0;
			length = dis.readByte();
			if (length == -1) {
				intReturn = null;
			} else {
				intReturn = dis.readInt();
			}
			return intReturn;
		}

		private void writeInteger(Integer intNum, ObjectOutputStream dos) throws IOException {
			if (intNum == null) {
				dos.writeByte(-1);
			} else {
				dos.writeByte(0);
				dos.writeInt(intNum);
			}
		}

		private void writeInteger(Integer intNum, org.jboss.marshalling.Marshaller marshaller) throws IOException {
			if (intNum == null) {
				marshaller.writeByte(-1);
			} else {
				marshaller.writeByte(0);
				marshaller.writeInt(intNum);
			}
		}

		private String readString(ObjectInputStream dis) throws IOException {
			String strReturn = null;
			int length = 0;
			length = dis.readInt();
			if (length == -1) {
				strReturn = null;
			} else {
				if (length > commonByteArray_MYFIRSTJOB_TP_MAJ.length) {
					if (length < 1024 && commonByteArray_MYFIRSTJOB_TP_MAJ.length == 0) {
						commonByteArray_MYFIRSTJOB_TP_MAJ = new byte[1024];
					} else {
						commonByteArray_MYFIRSTJOB_TP_MAJ = new byte[2 * length];
					}
				}
				dis.readFully(commonByteArray_MYFIRSTJOB_TP_MAJ, 0, length);
				strReturn = new String(commonByteArray_MYFIRSTJOB_TP_MAJ, 0, length, utf8Charset);
			}
			return strReturn;
		}

		private String readString(org.jboss.marshalling.Unmarshaller unmarshaller) throws IOException {
			String strReturn = null;
			int length = 0;
			length = unmarshaller.readInt();
			if (length == -1) {
				strReturn = null;
			} else {
				if (length > commonByteArray_MYFIRSTJOB_TP_MAJ.length) {
					if (length < 1024 && commonByteArray_MYFIRSTJOB_TP_MAJ.length == 0) {
						commonByteArray_MYFIRSTJOB_TP_MAJ = new byte[1024];
					} else {
						commonByteArray_MYFIRSTJOB_TP_MAJ = new byte[2 * length];
					}
				}
				unmarshaller.readFully(commonByteArray_MYFIRSTJOB_TP_MAJ, 0, length);
				strReturn = new String(commonByteArray_MYFIRSTJOB_TP_MAJ, 0, length, utf8Charset);
			}
			return strReturn;
		}

		private void writeString(String str, ObjectOutputStream dos) throws IOException {
			if (str == null) {
				dos.writeInt(-1);
			} else {
				byte[] byteArray = str.getBytes(utf8Charset);
				dos.writeInt(byteArray.length);
				dos.write(byteArray);
			}
		}

		private void writeString(String str, org.jboss.marshalling.Marshaller marshaller) throws IOException {
			if (str == null) {
				marshaller.writeInt(-1);
			} else {
				byte[] byteArray = str.getBytes(utf8Charset);
				marshaller.writeInt(byteArray.length);
				marshaller.write(byteArray);
			}
		}

		private java.util.Date readDate(ObjectInputStream dis) throws IOException {
			java.util.Date dateReturn = null;
			int length = 0;
			length = dis.readByte();
			if (length == -1) {
				dateReturn = null;
			} else {
				dateReturn = new Date(dis.readLong());
			}
			return dateReturn;
		}

		private java.util.Date readDate(org.jboss.marshalling.Unmarshaller unmarshaller) throws IOException {
			java.util.Date dateReturn = null;
			int length = 0;
			length = unmarshaller.readByte();
			if (length == -1) {
				dateReturn = null;
			} else {
				dateReturn = new Date(unmarshaller.readLong());
			}
			return dateReturn;
		}

		private void writeDate(java.util.Date date1, ObjectOutputStream dos) throws IOException {
			if (date1 == null) {
				dos.writeByte(-1);
			} else {
				dos.writeByte(0);
				dos.writeLong(date1.getTime());
			}
		}

		private void writeDate(java.util.Date date1, org.jboss.marshalling.Marshaller marshaller) throws IOException {
			if (date1 == null) {
				marshaller.writeByte(-1);
			} else {
				marshaller.writeByte(0);
				marshaller.writeLong(date1.getTime());
			}
		}

		public void readData(ObjectInputStream dis) {

			synchronized (commonByteArrayLock_MYFIRSTJOB_TP_MAJ) {

				try {

					int length = 0;

					this.id = readInteger(dis);

					this.title = readString(dis);

					this.date = readDate(dis);

					this.budget = readInteger(dis);

					length = dis.readByte();
					if (length == -1) {
						this.revenue = null;
					} else {
						this.revenue = dis.readLong();
					}

					length = dis.readByte();
					if (length == -1) {
						this.gain_perte = null;
					} else {
						this.gain_perte = dis.readLong();
					}

				} catch (IOException e) {
					throw new RuntimeException(e);

				}

			}

		}

		public void readData(org.jboss.marshalling.Unmarshaller dis) {

			synchronized (commonByteArrayLock_MYFIRSTJOB_TP_MAJ) {

				try {

					int length = 0;

					this.id = readInteger(dis);

					this.title = readString(dis);

					this.date = readDate(dis);

					this.budget = readInteger(dis);

					length = dis.readByte();
					if (length == -1) {
						this.revenue = null;
					} else {
						this.revenue = dis.readLong();
					}

					length = dis.readByte();
					if (length == -1) {
						this.gain_perte = null;
					} else {
						this.gain_perte = dis.readLong();
					}

				} catch (IOException e) {
					throw new RuntimeException(e);

				}

			}

		}

		public void writeData(ObjectOutputStream dos) {
			try {

				// Integer

				writeInteger(this.id, dos);

				// String

				writeString(this.title, dos);

				// java.util.Date

				writeDate(this.date, dos);

				// Integer

				writeInteger(this.budget, dos);

				// Long

				if (this.revenue == null) {
					dos.writeByte(-1);
				} else {
					dos.writeByte(0);
					dos.writeLong(this.revenue);
				}

				// Long

				if (this.gain_perte == null) {
					dos.writeByte(-1);
				} else {
					dos.writeByte(0);
					dos.writeLong(this.gain_perte);
				}

			} catch (IOException e) {
				throw new RuntimeException(e);
			}

		}

		public void writeData(org.jboss.marshalling.Marshaller dos) {
			try {

				// Integer

				writeInteger(this.id, dos);

				// String

				writeString(this.title, dos);

				// java.util.Date

				writeDate(this.date, dos);

				// Integer

				writeInteger(this.budget, dos);

				// Long

				if (this.revenue == null) {
					dos.writeByte(-1);
				} else {
					dos.writeByte(0);
					dos.writeLong(this.revenue);
				}

				// Long

				if (this.gain_perte == null) {
					dos.writeByte(-1);
				} else {
					dos.writeByte(0);
					dos.writeLong(this.gain_perte);
				}

			} catch (IOException e) {
				throw new RuntimeException(e);
			}

		}

		public String toString() {

			StringBuilder sb = new StringBuilder();
			sb.append(super.toString());
			sb.append("[");
			sb.append("id=" + String.valueOf(id));
			sb.append(",title=" + title);
			sb.append(",date=" + String.valueOf(date));
			sb.append(",budget=" + String.valueOf(budget));
			sb.append(",revenue=" + String.valueOf(revenue));
			sb.append(",gain_perte=" + String.valueOf(gain_perte));
			sb.append("]");

			return sb.toString();
		}

		/**
		 * Compare keys
		 */
		public int compareTo(OnRowsEndStructtSortRow_5 other) {

			int returnValue = -1;

			returnValue = checkNullsAndCompare(this.id, other.id);
			if (returnValue != 0) {
				return returnValue;
			}

			return returnValue;
		}

		private int checkNullsAndCompare(Object object1, Object object2) {
			int returnValue = 0;
			if (object1 instanceof Comparable && object2 instanceof Comparable) {
				returnValue = ((Comparable) object1).compareTo(object2);
			} else if (object1 != null && object2 != null) {
				returnValue = compareStrings(object1.toString(), object2.toString());
			} else if (object1 == null && object2 != null) {
				returnValue = 1;
			} else if (object1 != null && object2 == null) {
				returnValue = -1;
			} else {
				returnValue = 0;
			}

			return returnValue;
		}

		private int compareStrings(String string1, String string2) {
			return string1.compareTo(string2);
		}

	}

	public static class row20Struct implements routines.system.IPersistableRow<row20Struct> {
		final static byte[] commonByteArrayLock_MYFIRSTJOB_TP_MAJ = new byte[0];
		static byte[] commonByteArray_MYFIRSTJOB_TP_MAJ = new byte[0];
		protected static final int DEFAULT_HASHCODE = 1;
		protected static final int PRIME = 31;
		protected int hashCode = DEFAULT_HASHCODE;
		public boolean hashCodeDirty = true;

		public String loopKey;

		public Integer id;

		public Integer getId() {
			return this.id;
		}

		public String title;

		public String getTitle() {
			return this.title;
		}

		public java.util.Date date;

		public java.util.Date getDate() {
			return this.date;
		}

		public Integer budget;

		public Integer getBudget() {
			return this.budget;
		}

		public Long revenue;

		public Long getRevenue() {
			return this.revenue;
		}

		public Long gain_perte;

		public Long getGain_perte() {
			return this.gain_perte;
		}

		@Override
		public int hashCode() {
			if (this.hashCodeDirty) {
				final int prime = PRIME;
				int result = DEFAULT_HASHCODE;

				result = prime * result + ((this.id == null) ? 0 : this.id.hashCode());

				this.hashCode = result;
				this.hashCodeDirty = false;
			}
			return this.hashCode;
		}

		@Override
		public boolean equals(Object obj) {
			if (this == obj)
				return true;
			if (obj == null)
				return false;
			if (getClass() != obj.getClass())
				return false;
			final row20Struct other = (row20Struct) obj;

			if (this.id == null) {
				if (other.id != null)
					return false;

			} else if (!this.id.equals(other.id))

				return false;

			return true;
		}

		public void copyDataTo(row20Struct other) {

			other.id = this.id;
			other.title = this.title;
			other.date = this.date;
			other.budget = this.budget;
			other.revenue = this.revenue;
			other.gain_perte = this.gain_perte;

		}

		public void copyKeysDataTo(row20Struct other) {

			other.id = this.id;

		}

		private Integer readInteger(ObjectInputStream dis) throws IOException {
			Integer intReturn;
			int length = 0;
			length = dis.readByte();
			if (length == -1) {
				intReturn = null;
			} else {
				intReturn = dis.readInt();
			}
			return intReturn;
		}

		private Integer readInteger(org.jboss.marshalling.Unmarshaller dis) throws IOException {
			Integer intReturn;
			int length = 0;
			length = dis.readByte();
			if (length == -1) {
				intReturn = null;
			} else {
				intReturn = dis.readInt();
			}
			return intReturn;
		}

		private void writeInteger(Integer intNum, ObjectOutputStream dos) throws IOException {
			if (intNum == null) {
				dos.writeByte(-1);
			} else {
				dos.writeByte(0);
				dos.writeInt(intNum);
			}
		}

		private void writeInteger(Integer intNum, org.jboss.marshalling.Marshaller marshaller) throws IOException {
			if (intNum == null) {
				marshaller.writeByte(-1);
			} else {
				marshaller.writeByte(0);
				marshaller.writeInt(intNum);
			}
		}

		private String readString(ObjectInputStream dis) throws IOException {
			String strReturn = null;
			int length = 0;
			length = dis.readInt();
			if (length == -1) {
				strReturn = null;
			} else {
				if (length > commonByteArray_MYFIRSTJOB_TP_MAJ.length) {
					if (length < 1024 && commonByteArray_MYFIRSTJOB_TP_MAJ.length == 0) {
						commonByteArray_MYFIRSTJOB_TP_MAJ = new byte[1024];
					} else {
						commonByteArray_MYFIRSTJOB_TP_MAJ = new byte[2 * length];
					}
				}
				dis.readFully(commonByteArray_MYFIRSTJOB_TP_MAJ, 0, length);
				strReturn = new String(commonByteArray_MYFIRSTJOB_TP_MAJ, 0, length, utf8Charset);
			}
			return strReturn;
		}

		private String readString(org.jboss.marshalling.Unmarshaller unmarshaller) throws IOException {
			String strReturn = null;
			int length = 0;
			length = unmarshaller.readInt();
			if (length == -1) {
				strReturn = null;
			} else {
				if (length > commonByteArray_MYFIRSTJOB_TP_MAJ.length) {
					if (length < 1024 && commonByteArray_MYFIRSTJOB_TP_MAJ.length == 0) {
						commonByteArray_MYFIRSTJOB_TP_MAJ = new byte[1024];
					} else {
						commonByteArray_MYFIRSTJOB_TP_MAJ = new byte[2 * length];
					}
				}
				unmarshaller.readFully(commonByteArray_MYFIRSTJOB_TP_MAJ, 0, length);
				strReturn = new String(commonByteArray_MYFIRSTJOB_TP_MAJ, 0, length, utf8Charset);
			}
			return strReturn;
		}

		private void writeString(String str, ObjectOutputStream dos) throws IOException {
			if (str == null) {
				dos.writeInt(-1);
			} else {
				byte[] byteArray = str.getBytes(utf8Charset);
				dos.writeInt(byteArray.length);
				dos.write(byteArray);
			}
		}

		private void writeString(String str, org.jboss.marshalling.Marshaller marshaller) throws IOException {
			if (str == null) {
				marshaller.writeInt(-1);
			} else {
				byte[] byteArray = str.getBytes(utf8Charset);
				marshaller.writeInt(byteArray.length);
				marshaller.write(byteArray);
			}
		}

		private java.util.Date readDate(ObjectInputStream dis) throws IOException {
			java.util.Date dateReturn = null;
			int length = 0;
			length = dis.readByte();
			if (length == -1) {
				dateReturn = null;
			} else {
				dateReturn = new Date(dis.readLong());
			}
			return dateReturn;
		}

		private java.util.Date readDate(org.jboss.marshalling.Unmarshaller unmarshaller) throws IOException {
			java.util.Date dateReturn = null;
			int length = 0;
			length = unmarshaller.readByte();
			if (length == -1) {
				dateReturn = null;
			} else {
				dateReturn = new Date(unmarshaller.readLong());
			}
			return dateReturn;
		}

		private void writeDate(java.util.Date date1, ObjectOutputStream dos) throws IOException {
			if (date1 == null) {
				dos.writeByte(-1);
			} else {
				dos.writeByte(0);
				dos.writeLong(date1.getTime());
			}
		}

		private void writeDate(java.util.Date date1, org.jboss.marshalling.Marshaller marshaller) throws IOException {
			if (date1 == null) {
				marshaller.writeByte(-1);
			} else {
				marshaller.writeByte(0);
				marshaller.writeLong(date1.getTime());
			}
		}

		public void readData(ObjectInputStream dis) {

			synchronized (commonByteArrayLock_MYFIRSTJOB_TP_MAJ) {

				try {

					int length = 0;

					this.id = readInteger(dis);

					this.title = readString(dis);

					this.date = readDate(dis);

					this.budget = readInteger(dis);

					length = dis.readByte();
					if (length == -1) {
						this.revenue = null;
					} else {
						this.revenue = dis.readLong();
					}

					length = dis.readByte();
					if (length == -1) {
						this.gain_perte = null;
					} else {
						this.gain_perte = dis.readLong();
					}

				} catch (IOException e) {
					throw new RuntimeException(e);

				}

			}

		}

		public void readData(org.jboss.marshalling.Unmarshaller dis) {

			synchronized (commonByteArrayLock_MYFIRSTJOB_TP_MAJ) {

				try {

					int length = 0;

					this.id = readInteger(dis);

					this.title = readString(dis);

					this.date = readDate(dis);

					this.budget = readInteger(dis);

					length = dis.readByte();
					if (length == -1) {
						this.revenue = null;
					} else {
						this.revenue = dis.readLong();
					}

					length = dis.readByte();
					if (length == -1) {
						this.gain_perte = null;
					} else {
						this.gain_perte = dis.readLong();
					}

				} catch (IOException e) {
					throw new RuntimeException(e);

				}

			}

		}

		public void writeData(ObjectOutputStream dos) {
			try {

				// Integer

				writeInteger(this.id, dos);

				// String

				writeString(this.title, dos);

				// java.util.Date

				writeDate(this.date, dos);

				// Integer

				writeInteger(this.budget, dos);

				// Long

				if (this.revenue == null) {
					dos.writeByte(-1);
				} else {
					dos.writeByte(0);
					dos.writeLong(this.revenue);
				}

				// Long

				if (this.gain_perte == null) {
					dos.writeByte(-1);
				} else {
					dos.writeByte(0);
					dos.writeLong(this.gain_perte);
				}

			} catch (IOException e) {
				throw new RuntimeException(e);
			}

		}

		public void writeData(org.jboss.marshalling.Marshaller dos) {
			try {

				// Integer

				writeInteger(this.id, dos);

				// String

				writeString(this.title, dos);

				// java.util.Date

				writeDate(this.date, dos);

				// Integer

				writeInteger(this.budget, dos);

				// Long

				if (this.revenue == null) {
					dos.writeByte(-1);
				} else {
					dos.writeByte(0);
					dos.writeLong(this.revenue);
				}

				// Long

				if (this.gain_perte == null) {
					dos.writeByte(-1);
				} else {
					dos.writeByte(0);
					dos.writeLong(this.gain_perte);
				}

			} catch (IOException e) {
				throw new RuntimeException(e);
			}

		}

		public String toString() {

			StringBuilder sb = new StringBuilder();
			sb.append(super.toString());
			sb.append("[");
			sb.append("id=" + String.valueOf(id));
			sb.append(",title=" + title);
			sb.append(",date=" + String.valueOf(date));
			sb.append(",budget=" + String.valueOf(budget));
			sb.append(",revenue=" + String.valueOf(revenue));
			sb.append(",gain_perte=" + String.valueOf(gain_perte));
			sb.append("]");

			return sb.toString();
		}

		/**
		 * Compare keys
		 */
		public int compareTo(row20Struct other) {

			int returnValue = -1;

			returnValue = checkNullsAndCompare(this.id, other.id);
			if (returnValue != 0) {
				return returnValue;
			}

			return returnValue;
		}

		private int checkNullsAndCompare(Object object1, Object object2) {
			int returnValue = 0;
			if (object1 instanceof Comparable && object2 instanceof Comparable) {
				returnValue = ((Comparable) object1).compareTo(object2);
			} else if (object1 != null && object2 != null) {
				returnValue = compareStrings(object1.toString(), object2.toString());
			} else if (object1 == null && object2 != null) {
				returnValue = 1;
			} else if (object1 != null && object2 == null) {
				returnValue = -1;
			} else {
				returnValue = 0;
			}

			return returnValue;
		}

		private int compareStrings(String string1, String string2) {
			return string1.compareTo(string2);
		}

	}

	public static class row19Struct implements routines.system.IPersistableRow<row19Struct> {
		final static byte[] commonByteArrayLock_MYFIRSTJOB_TP_MAJ = new byte[0];
		static byte[] commonByteArray_MYFIRSTJOB_TP_MAJ = new byte[0];
		protected static final int DEFAULT_HASHCODE = 1;
		protected static final int PRIME = 31;
		protected int hashCode = DEFAULT_HASHCODE;
		public boolean hashCodeDirty = true;

		public String loopKey;

		public Integer id;

		public Integer getId() {
			return this.id;
		}

		public java.util.Date date;

		public java.util.Date getDate() {
			return this.date;
		}

		public Integer budget;

		public Integer getBudget() {
			return this.budget;
		}

		public Long revenue;

		public Long getRevenue() {
			return this.revenue;
		}

		@Override
		public int hashCode() {
			if (this.hashCodeDirty) {
				final int prime = PRIME;
				int result = DEFAULT_HASHCODE;

				result = prime * result + ((this.id == null) ? 0 : this.id.hashCode());

				this.hashCode = result;
				this.hashCodeDirty = false;
			}
			return this.hashCode;
		}

		@Override
		public boolean equals(Object obj) {
			if (this == obj)
				return true;
			if (obj == null)
				return false;
			if (getClass() != obj.getClass())
				return false;
			final row19Struct other = (row19Struct) obj;

			if (this.id == null) {
				if (other.id != null)
					return false;

			} else if (!this.id.equals(other.id))

				return false;

			return true;
		}

		public void copyDataTo(row19Struct other) {

			other.id = this.id;
			other.date = this.date;
			other.budget = this.budget;
			other.revenue = this.revenue;

		}

		public void copyKeysDataTo(row19Struct other) {

			other.id = this.id;

		}

		private Integer readInteger(ObjectInputStream dis) throws IOException {
			Integer intReturn;
			int length = 0;
			length = dis.readByte();
			if (length == -1) {
				intReturn = null;
			} else {
				intReturn = dis.readInt();
			}
			return intReturn;
		}

		private Integer readInteger(org.jboss.marshalling.Unmarshaller dis) throws IOException {
			Integer intReturn;
			int length = 0;
			length = dis.readByte();
			if (length == -1) {
				intReturn = null;
			} else {
				intReturn = dis.readInt();
			}
			return intReturn;
		}

		private void writeInteger(Integer intNum, ObjectOutputStream dos) throws IOException {
			if (intNum == null) {
				dos.writeByte(-1);
			} else {
				dos.writeByte(0);
				dos.writeInt(intNum);
			}
		}

		private void writeInteger(Integer intNum, org.jboss.marshalling.Marshaller marshaller) throws IOException {
			if (intNum == null) {
				marshaller.writeByte(-1);
			} else {
				marshaller.writeByte(0);
				marshaller.writeInt(intNum);
			}
		}

		private java.util.Date readDate(ObjectInputStream dis) throws IOException {
			java.util.Date dateReturn = null;
			int length = 0;
			length = dis.readByte();
			if (length == -1) {
				dateReturn = null;
			} else {
				dateReturn = new Date(dis.readLong());
			}
			return dateReturn;
		}

		private java.util.Date readDate(org.jboss.marshalling.Unmarshaller unmarshaller) throws IOException {
			java.util.Date dateReturn = null;
			int length = 0;
			length = unmarshaller.readByte();
			if (length == -1) {
				dateReturn = null;
			} else {
				dateReturn = new Date(unmarshaller.readLong());
			}
			return dateReturn;
		}

		private void writeDate(java.util.Date date1, ObjectOutputStream dos) throws IOException {
			if (date1 == null) {
				dos.writeByte(-1);
			} else {
				dos.writeByte(0);
				dos.writeLong(date1.getTime());
			}
		}

		private void writeDate(java.util.Date date1, org.jboss.marshalling.Marshaller marshaller) throws IOException {
			if (date1 == null) {
				marshaller.writeByte(-1);
			} else {
				marshaller.writeByte(0);
				marshaller.writeLong(date1.getTime());
			}
		}

		public void readData(ObjectInputStream dis) {

			synchronized (commonByteArrayLock_MYFIRSTJOB_TP_MAJ) {

				try {

					int length = 0;

					this.id = readInteger(dis);

					this.date = readDate(dis);

					this.budget = readInteger(dis);

					length = dis.readByte();
					if (length == -1) {
						this.revenue = null;
					} else {
						this.revenue = dis.readLong();
					}

				} catch (IOException e) {
					throw new RuntimeException(e);

				}

			}

		}

		public void readData(org.jboss.marshalling.Unmarshaller dis) {

			synchronized (commonByteArrayLock_MYFIRSTJOB_TP_MAJ) {

				try {

					int length = 0;

					this.id = readInteger(dis);

					this.date = readDate(dis);

					this.budget = readInteger(dis);

					length = dis.readByte();
					if (length == -1) {
						this.revenue = null;
					} else {
						this.revenue = dis.readLong();
					}

				} catch (IOException e) {
					throw new RuntimeException(e);

				}

			}

		}

		public void writeData(ObjectOutputStream dos) {
			try {

				// Integer

				writeInteger(this.id, dos);

				// java.util.Date

				writeDate(this.date, dos);

				// Integer

				writeInteger(this.budget, dos);

				// Long

				if (this.revenue == null) {
					dos.writeByte(-1);
				} else {
					dos.writeByte(0);
					dos.writeLong(this.revenue);
				}

			} catch (IOException e) {
				throw new RuntimeException(e);
			}

		}

		public void writeData(org.jboss.marshalling.Marshaller dos) {
			try {

				// Integer

				writeInteger(this.id, dos);

				// java.util.Date

				writeDate(this.date, dos);

				// Integer

				writeInteger(this.budget, dos);

				// Long

				if (this.revenue == null) {
					dos.writeByte(-1);
				} else {
					dos.writeByte(0);
					dos.writeLong(this.revenue);
				}

			} catch (IOException e) {
				throw new RuntimeException(e);
			}

		}

		public String toString() {

			StringBuilder sb = new StringBuilder();
			sb.append(super.toString());
			sb.append("[");
			sb.append("id=" + String.valueOf(id));
			sb.append(",date=" + String.valueOf(date));
			sb.append(",budget=" + String.valueOf(budget));
			sb.append(",revenue=" + String.valueOf(revenue));
			sb.append("]");

			return sb.toString();
		}

		/**
		 * Compare keys
		 */
		public int compareTo(row19Struct other) {

			int returnValue = -1;

			returnValue = checkNullsAndCompare(this.id, other.id);
			if (returnValue != 0) {
				return returnValue;
			}

			return returnValue;
		}

		private int checkNullsAndCompare(Object object1, Object object2) {
			int returnValue = 0;
			if (object1 instanceof Comparable && object2 instanceof Comparable) {
				returnValue = ((Comparable) object1).compareTo(object2);
			} else if (object1 != null && object2 != null) {
				returnValue = compareStrings(object1.toString(), object2.toString());
			} else if (object1 == null && object2 != null) {
				returnValue = 1;
			} else if (object1 != null && object2 == null) {
				returnValue = -1;
			} else {
				returnValue = 0;
			}

			return returnValue;
		}

		private int compareStrings(String string1, String string2) {
			return string1.compareTo(string2);
		}

	}

	public static class OnRowsEndStructtSortRow_4
			implements routines.system.IPersistableRow<OnRowsEndStructtSortRow_4> {
		final static byte[] commonByteArrayLock_MYFIRSTJOB_TP_MAJ = new byte[0];
		static byte[] commonByteArray_MYFIRSTJOB_TP_MAJ = new byte[0];
		protected static final int DEFAULT_HASHCODE = 1;
		protected static final int PRIME = 31;
		protected int hashCode = DEFAULT_HASHCODE;
		public boolean hashCodeDirty = true;

		public String loopKey;

		public Integer id;

		public Integer getId() {
			return this.id;
		}

		public java.util.Date date;

		public java.util.Date getDate() {
			return this.date;
		}

		public Integer budget;

		public Integer getBudget() {
			return this.budget;
		}

		public Long revenue;

		public Long getRevenue() {
			return this.revenue;
		}

		@Override
		public int hashCode() {
			if (this.hashCodeDirty) {
				final int prime = PRIME;
				int result = DEFAULT_HASHCODE;

				result = prime * result + ((this.id == null) ? 0 : this.id.hashCode());

				this.hashCode = result;
				this.hashCodeDirty = false;
			}
			return this.hashCode;
		}

		@Override
		public boolean equals(Object obj) {
			if (this == obj)
				return true;
			if (obj == null)
				return false;
			if (getClass() != obj.getClass())
				return false;
			final OnRowsEndStructtSortRow_4 other = (OnRowsEndStructtSortRow_4) obj;

			if (this.id == null) {
				if (other.id != null)
					return false;

			} else if (!this.id.equals(other.id))

				return false;

			return true;
		}

		public void copyDataTo(OnRowsEndStructtSortRow_4 other) {

			other.id = this.id;
			other.date = this.date;
			other.budget = this.budget;
			other.revenue = this.revenue;

		}

		public void copyKeysDataTo(OnRowsEndStructtSortRow_4 other) {

			other.id = this.id;

		}

		private Integer readInteger(ObjectInputStream dis) throws IOException {
			Integer intReturn;
			int length = 0;
			length = dis.readByte();
			if (length == -1) {
				intReturn = null;
			} else {
				intReturn = dis.readInt();
			}
			return intReturn;
		}

		private Integer readInteger(org.jboss.marshalling.Unmarshaller dis) throws IOException {
			Integer intReturn;
			int length = 0;
			length = dis.readByte();
			if (length == -1) {
				intReturn = null;
			} else {
				intReturn = dis.readInt();
			}
			return intReturn;
		}

		private void writeInteger(Integer intNum, ObjectOutputStream dos) throws IOException {
			if (intNum == null) {
				dos.writeByte(-1);
			} else {
				dos.writeByte(0);
				dos.writeInt(intNum);
			}
		}

		private void writeInteger(Integer intNum, org.jboss.marshalling.Marshaller marshaller) throws IOException {
			if (intNum == null) {
				marshaller.writeByte(-1);
			} else {
				marshaller.writeByte(0);
				marshaller.writeInt(intNum);
			}
		}

		private java.util.Date readDate(ObjectInputStream dis) throws IOException {
			java.util.Date dateReturn = null;
			int length = 0;
			length = dis.readByte();
			if (length == -1) {
				dateReturn = null;
			} else {
				dateReturn = new Date(dis.readLong());
			}
			return dateReturn;
		}

		private java.util.Date readDate(org.jboss.marshalling.Unmarshaller unmarshaller) throws IOException {
			java.util.Date dateReturn = null;
			int length = 0;
			length = unmarshaller.readByte();
			if (length == -1) {
				dateReturn = null;
			} else {
				dateReturn = new Date(unmarshaller.readLong());
			}
			return dateReturn;
		}

		private void writeDate(java.util.Date date1, ObjectOutputStream dos) throws IOException {
			if (date1 == null) {
				dos.writeByte(-1);
			} else {
				dos.writeByte(0);
				dos.writeLong(date1.getTime());
			}
		}

		private void writeDate(java.util.Date date1, org.jboss.marshalling.Marshaller marshaller) throws IOException {
			if (date1 == null) {
				marshaller.writeByte(-1);
			} else {
				marshaller.writeByte(0);
				marshaller.writeLong(date1.getTime());
			}
		}

		public void readData(ObjectInputStream dis) {

			synchronized (commonByteArrayLock_MYFIRSTJOB_TP_MAJ) {

				try {

					int length = 0;

					this.id = readInteger(dis);

					this.date = readDate(dis);

					this.budget = readInteger(dis);

					length = dis.readByte();
					if (length == -1) {
						this.revenue = null;
					} else {
						this.revenue = dis.readLong();
					}

				} catch (IOException e) {
					throw new RuntimeException(e);

				}

			}

		}

		public void readData(org.jboss.marshalling.Unmarshaller dis) {

			synchronized (commonByteArrayLock_MYFIRSTJOB_TP_MAJ) {

				try {

					int length = 0;

					this.id = readInteger(dis);

					this.date = readDate(dis);

					this.budget = readInteger(dis);

					length = dis.readByte();
					if (length == -1) {
						this.revenue = null;
					} else {
						this.revenue = dis.readLong();
					}

				} catch (IOException e) {
					throw new RuntimeException(e);

				}

			}

		}

		public void writeData(ObjectOutputStream dos) {
			try {

				// Integer

				writeInteger(this.id, dos);

				// java.util.Date

				writeDate(this.date, dos);

				// Integer

				writeInteger(this.budget, dos);

				// Long

				if (this.revenue == null) {
					dos.writeByte(-1);
				} else {
					dos.writeByte(0);
					dos.writeLong(this.revenue);
				}

			} catch (IOException e) {
				throw new RuntimeException(e);
			}

		}

		public void writeData(org.jboss.marshalling.Marshaller dos) {
			try {

				// Integer

				writeInteger(this.id, dos);

				// java.util.Date

				writeDate(this.date, dos);

				// Integer

				writeInteger(this.budget, dos);

				// Long

				if (this.revenue == null) {
					dos.writeByte(-1);
				} else {
					dos.writeByte(0);
					dos.writeLong(this.revenue);
				}

			} catch (IOException e) {
				throw new RuntimeException(e);
			}

		}

		public String toString() {

			StringBuilder sb = new StringBuilder();
			sb.append(super.toString());
			sb.append("[");
			sb.append("id=" + String.valueOf(id));
			sb.append(",date=" + String.valueOf(date));
			sb.append(",budget=" + String.valueOf(budget));
			sb.append(",revenue=" + String.valueOf(revenue));
			sb.append("]");

			return sb.toString();
		}

		/**
		 * Compare keys
		 */
		public int compareTo(OnRowsEndStructtSortRow_4 other) {

			int returnValue = -1;

			returnValue = checkNullsAndCompare(this.id, other.id);
			if (returnValue != 0) {
				return returnValue;
			}

			return returnValue;
		}

		private int checkNullsAndCompare(Object object1, Object object2) {
			int returnValue = 0;
			if (object1 instanceof Comparable && object2 instanceof Comparable) {
				returnValue = ((Comparable) object1).compareTo(object2);
			} else if (object1 != null && object2 != null) {
				returnValue = compareStrings(object1.toString(), object2.toString());
			} else if (object1 == null && object2 != null) {
				returnValue = 1;
			} else if (object1 != null && object2 == null) {
				returnValue = -1;
			} else {
				returnValue = 0;
			}

			return returnValue;
		}

		private int compareStrings(String string1, String string2) {
			return string1.compareTo(string2);
		}

	}

	public static class row18Struct implements routines.system.IPersistableRow<row18Struct> {
		final static byte[] commonByteArrayLock_MYFIRSTJOB_TP_MAJ = new byte[0];
		static byte[] commonByteArray_MYFIRSTJOB_TP_MAJ = new byte[0];
		protected static final int DEFAULT_HASHCODE = 1;
		protected static final int PRIME = 31;
		protected int hashCode = DEFAULT_HASHCODE;
		public boolean hashCodeDirty = true;

		public String loopKey;

		public Integer id;

		public Integer getId() {
			return this.id;
		}

		public java.util.Date date;

		public java.util.Date getDate() {
			return this.date;
		}

		public Integer budget;

		public Integer getBudget() {
			return this.budget;
		}

		public Long revenue;

		public Long getRevenue() {
			return this.revenue;
		}

		@Override
		public int hashCode() {
			if (this.hashCodeDirty) {
				final int prime = PRIME;
				int result = DEFAULT_HASHCODE;

				result = prime * result + ((this.id == null) ? 0 : this.id.hashCode());

				this.hashCode = result;
				this.hashCodeDirty = false;
			}
			return this.hashCode;
		}

		@Override
		public boolean equals(Object obj) {
			if (this == obj)
				return true;
			if (obj == null)
				return false;
			if (getClass() != obj.getClass())
				return false;
			final row18Struct other = (row18Struct) obj;

			if (this.id == null) {
				if (other.id != null)
					return false;

			} else if (!this.id.equals(other.id))

				return false;

			return true;
		}

		public void copyDataTo(row18Struct other) {

			other.id = this.id;
			other.date = this.date;
			other.budget = this.budget;
			other.revenue = this.revenue;

		}

		public void copyKeysDataTo(row18Struct other) {

			other.id = this.id;

		}

		private Integer readInteger(ObjectInputStream dis) throws IOException {
			Integer intReturn;
			int length = 0;
			length = dis.readByte();
			if (length == -1) {
				intReturn = null;
			} else {
				intReturn = dis.readInt();
			}
			return intReturn;
		}

		private Integer readInteger(org.jboss.marshalling.Unmarshaller dis) throws IOException {
			Integer intReturn;
			int length = 0;
			length = dis.readByte();
			if (length == -1) {
				intReturn = null;
			} else {
				intReturn = dis.readInt();
			}
			return intReturn;
		}

		private void writeInteger(Integer intNum, ObjectOutputStream dos) throws IOException {
			if (intNum == null) {
				dos.writeByte(-1);
			} else {
				dos.writeByte(0);
				dos.writeInt(intNum);
			}
		}

		private void writeInteger(Integer intNum, org.jboss.marshalling.Marshaller marshaller) throws IOException {
			if (intNum == null) {
				marshaller.writeByte(-1);
			} else {
				marshaller.writeByte(0);
				marshaller.writeInt(intNum);
			}
		}

		private java.util.Date readDate(ObjectInputStream dis) throws IOException {
			java.util.Date dateReturn = null;
			int length = 0;
			length = dis.readByte();
			if (length == -1) {
				dateReturn = null;
			} else {
				dateReturn = new Date(dis.readLong());
			}
			return dateReturn;
		}

		private java.util.Date readDate(org.jboss.marshalling.Unmarshaller unmarshaller) throws IOException {
			java.util.Date dateReturn = null;
			int length = 0;
			length = unmarshaller.readByte();
			if (length == -1) {
				dateReturn = null;
			} else {
				dateReturn = new Date(unmarshaller.readLong());
			}
			return dateReturn;
		}

		private void writeDate(java.util.Date date1, ObjectOutputStream dos) throws IOException {
			if (date1 == null) {
				dos.writeByte(-1);
			} else {
				dos.writeByte(0);
				dos.writeLong(date1.getTime());
			}
		}

		private void writeDate(java.util.Date date1, org.jboss.marshalling.Marshaller marshaller) throws IOException {
			if (date1 == null) {
				marshaller.writeByte(-1);
			} else {
				marshaller.writeByte(0);
				marshaller.writeLong(date1.getTime());
			}
		}

		public void readData(ObjectInputStream dis) {

			synchronized (commonByteArrayLock_MYFIRSTJOB_TP_MAJ) {

				try {

					int length = 0;

					this.id = readInteger(dis);

					this.date = readDate(dis);

					this.budget = readInteger(dis);

					length = dis.readByte();
					if (length == -1) {
						this.revenue = null;
					} else {
						this.revenue = dis.readLong();
					}

				} catch (IOException e) {
					throw new RuntimeException(e);

				}

			}

		}

		public void readData(org.jboss.marshalling.Unmarshaller dis) {

			synchronized (commonByteArrayLock_MYFIRSTJOB_TP_MAJ) {

				try {

					int length = 0;

					this.id = readInteger(dis);

					this.date = readDate(dis);

					this.budget = readInteger(dis);

					length = dis.readByte();
					if (length == -1) {
						this.revenue = null;
					} else {
						this.revenue = dis.readLong();
					}

				} catch (IOException e) {
					throw new RuntimeException(e);

				}

			}

		}

		public void writeData(ObjectOutputStream dos) {
			try {

				// Integer

				writeInteger(this.id, dos);

				// java.util.Date

				writeDate(this.date, dos);

				// Integer

				writeInteger(this.budget, dos);

				// Long

				if (this.revenue == null) {
					dos.writeByte(-1);
				} else {
					dos.writeByte(0);
					dos.writeLong(this.revenue);
				}

			} catch (IOException e) {
				throw new RuntimeException(e);
			}

		}

		public void writeData(org.jboss.marshalling.Marshaller dos) {
			try {

				// Integer

				writeInteger(this.id, dos);

				// java.util.Date

				writeDate(this.date, dos);

				// Integer

				writeInteger(this.budget, dos);

				// Long

				if (this.revenue == null) {
					dos.writeByte(-1);
				} else {
					dos.writeByte(0);
					dos.writeLong(this.revenue);
				}

			} catch (IOException e) {
				throw new RuntimeException(e);
			}

		}

		public String toString() {

			StringBuilder sb = new StringBuilder();
			sb.append(super.toString());
			sb.append("[");
			sb.append("id=" + String.valueOf(id));
			sb.append(",date=" + String.valueOf(date));
			sb.append(",budget=" + String.valueOf(budget));
			sb.append(",revenue=" + String.valueOf(revenue));
			sb.append("]");

			return sb.toString();
		}

		/**
		 * Compare keys
		 */
		public int compareTo(row18Struct other) {

			int returnValue = -1;

			returnValue = checkNullsAndCompare(this.id, other.id);
			if (returnValue != 0) {
				return returnValue;
			}

			return returnValue;
		}

		private int checkNullsAndCompare(Object object1, Object object2) {
			int returnValue = 0;
			if (object1 instanceof Comparable && object2 instanceof Comparable) {
				returnValue = ((Comparable) object1).compareTo(object2);
			} else if (object1 != null && object2 != null) {
				returnValue = compareStrings(object1.toString(), object2.toString());
			} else if (object1 == null && object2 != null) {
				returnValue = 1;
			} else if (object1 != null && object2 == null) {
				returnValue = -1;
			} else {
				returnValue = 0;
			}

			return returnValue;
		}

		private int compareStrings(String string1, String string2) {
			return string1.compareTo(string2);
		}

	}

	public static class OnRowsEndStructtAggregateRow_1
			implements routines.system.IPersistableRow<OnRowsEndStructtAggregateRow_1> {
		final static byte[] commonByteArrayLock_MYFIRSTJOB_TP_MAJ = new byte[0];
		static byte[] commonByteArray_MYFIRSTJOB_TP_MAJ = new byte[0];
		protected static final int DEFAULT_HASHCODE = 1;
		protected static final int PRIME = 31;
		protected int hashCode = DEFAULT_HASHCODE;
		public boolean hashCodeDirty = true;

		public String loopKey;

		public Integer id;

		public Integer getId() {
			return this.id;
		}

		public java.util.Date date;

		public java.util.Date getDate() {
			return this.date;
		}

		public Integer budget;

		public Integer getBudget() {
			return this.budget;
		}

		public Long revenue;

		public Long getRevenue() {
			return this.revenue;
		}

		@Override
		public int hashCode() {
			if (this.hashCodeDirty) {
				final int prime = PRIME;
				int result = DEFAULT_HASHCODE;

				result = prime * result + ((this.id == null) ? 0 : this.id.hashCode());

				this.hashCode = result;
				this.hashCodeDirty = false;
			}
			return this.hashCode;
		}

		@Override
		public boolean equals(Object obj) {
			if (this == obj)
				return true;
			if (obj == null)
				return false;
			if (getClass() != obj.getClass())
				return false;
			final OnRowsEndStructtAggregateRow_1 other = (OnRowsEndStructtAggregateRow_1) obj;

			if (this.id == null) {
				if (other.id != null)
					return false;

			} else if (!this.id.equals(other.id))

				return false;

			return true;
		}

		public void copyDataTo(OnRowsEndStructtAggregateRow_1 other) {

			other.id = this.id;
			other.date = this.date;
			other.budget = this.budget;
			other.revenue = this.revenue;

		}

		public void copyKeysDataTo(OnRowsEndStructtAggregateRow_1 other) {

			other.id = this.id;

		}

		private Integer readInteger(ObjectInputStream dis) throws IOException {
			Integer intReturn;
			int length = 0;
			length = dis.readByte();
			if (length == -1) {
				intReturn = null;
			} else {
				intReturn = dis.readInt();
			}
			return intReturn;
		}

		private Integer readInteger(org.jboss.marshalling.Unmarshaller dis) throws IOException {
			Integer intReturn;
			int length = 0;
			length = dis.readByte();
			if (length == -1) {
				intReturn = null;
			} else {
				intReturn = dis.readInt();
			}
			return intReturn;
		}

		private void writeInteger(Integer intNum, ObjectOutputStream dos) throws IOException {
			if (intNum == null) {
				dos.writeByte(-1);
			} else {
				dos.writeByte(0);
				dos.writeInt(intNum);
			}
		}

		private void writeInteger(Integer intNum, org.jboss.marshalling.Marshaller marshaller) throws IOException {
			if (intNum == null) {
				marshaller.writeByte(-1);
			} else {
				marshaller.writeByte(0);
				marshaller.writeInt(intNum);
			}
		}

		private java.util.Date readDate(ObjectInputStream dis) throws IOException {
			java.util.Date dateReturn = null;
			int length = 0;
			length = dis.readByte();
			if (length == -1) {
				dateReturn = null;
			} else {
				dateReturn = new Date(dis.readLong());
			}
			return dateReturn;
		}

		private java.util.Date readDate(org.jboss.marshalling.Unmarshaller unmarshaller) throws IOException {
			java.util.Date dateReturn = null;
			int length = 0;
			length = unmarshaller.readByte();
			if (length == -1) {
				dateReturn = null;
			} else {
				dateReturn = new Date(unmarshaller.readLong());
			}
			return dateReturn;
		}

		private void writeDate(java.util.Date date1, ObjectOutputStream dos) throws IOException {
			if (date1 == null) {
				dos.writeByte(-1);
			} else {
				dos.writeByte(0);
				dos.writeLong(date1.getTime());
			}
		}

		private void writeDate(java.util.Date date1, org.jboss.marshalling.Marshaller marshaller) throws IOException {
			if (date1 == null) {
				marshaller.writeByte(-1);
			} else {
				marshaller.writeByte(0);
				marshaller.writeLong(date1.getTime());
			}
		}

		public void readData(ObjectInputStream dis) {

			synchronized (commonByteArrayLock_MYFIRSTJOB_TP_MAJ) {

				try {

					int length = 0;

					this.id = readInteger(dis);

					this.date = readDate(dis);

					this.budget = readInteger(dis);

					length = dis.readByte();
					if (length == -1) {
						this.revenue = null;
					} else {
						this.revenue = dis.readLong();
					}

				} catch (IOException e) {
					throw new RuntimeException(e);

				}

			}

		}

		public void readData(org.jboss.marshalling.Unmarshaller dis) {

			synchronized (commonByteArrayLock_MYFIRSTJOB_TP_MAJ) {

				try {

					int length = 0;

					this.id = readInteger(dis);

					this.date = readDate(dis);

					this.budget = readInteger(dis);

					length = dis.readByte();
					if (length == -1) {
						this.revenue = null;
					} else {
						this.revenue = dis.readLong();
					}

				} catch (IOException e) {
					throw new RuntimeException(e);

				}

			}

		}

		public void writeData(ObjectOutputStream dos) {
			try {

				// Integer

				writeInteger(this.id, dos);

				// java.util.Date

				writeDate(this.date, dos);

				// Integer

				writeInteger(this.budget, dos);

				// Long

				if (this.revenue == null) {
					dos.writeByte(-1);
				} else {
					dos.writeByte(0);
					dos.writeLong(this.revenue);
				}

			} catch (IOException e) {
				throw new RuntimeException(e);
			}

		}

		public void writeData(org.jboss.marshalling.Marshaller dos) {
			try {

				// Integer

				writeInteger(this.id, dos);

				// java.util.Date

				writeDate(this.date, dos);

				// Integer

				writeInteger(this.budget, dos);

				// Long

				if (this.revenue == null) {
					dos.writeByte(-1);
				} else {
					dos.writeByte(0);
					dos.writeLong(this.revenue);
				}

			} catch (IOException e) {
				throw new RuntimeException(e);
			}

		}

		public String toString() {

			StringBuilder sb = new StringBuilder();
			sb.append(super.toString());
			sb.append("[");
			sb.append("id=" + String.valueOf(id));
			sb.append(",date=" + String.valueOf(date));
			sb.append(",budget=" + String.valueOf(budget));
			sb.append(",revenue=" + String.valueOf(revenue));
			sb.append("]");

			return sb.toString();
		}

		/**
		 * Compare keys
		 */
		public int compareTo(OnRowsEndStructtAggregateRow_1 other) {

			int returnValue = -1;

			returnValue = checkNullsAndCompare(this.id, other.id);
			if (returnValue != 0) {
				return returnValue;
			}

			return returnValue;
		}

		private int checkNullsAndCompare(Object object1, Object object2) {
			int returnValue = 0;
			if (object1 instanceof Comparable && object2 instanceof Comparable) {
				returnValue = ((Comparable) object1).compareTo(object2);
			} else if (object1 != null && object2 != null) {
				returnValue = compareStrings(object1.toString(), object2.toString());
			} else if (object1 == null && object2 != null) {
				returnValue = 1;
			} else if (object1 != null && object2 == null) {
				returnValue = -1;
			} else {
				returnValue = 0;
			}

			return returnValue;
		}

		private int compareStrings(String string1, String string2) {
			return string1.compareTo(string2);
		}

	}

	public static class row17Struct implements routines.system.IPersistableRow<row17Struct> {
		final static byte[] commonByteArrayLock_MYFIRSTJOB_TP_MAJ = new byte[0];
		static byte[] commonByteArray_MYFIRSTJOB_TP_MAJ = new byte[0];
		protected static final int DEFAULT_HASHCODE = 1;
		protected static final int PRIME = 31;
		protected int hashCode = DEFAULT_HASHCODE;
		public boolean hashCodeDirty = true;

		public String loopKey;

		public Integer id;

		public Integer getId() {
			return this.id;
		}

		public String title;

		public String getTitle() {
			return this.title;
		}

		public java.util.Date date;

		public java.util.Date getDate() {
			return this.date;
		}

		public Integer budget;

		public Integer getBudget() {
			return this.budget;
		}

		public Long revenue;

		public Long getRevenue() {
			return this.revenue;
		}

		@Override
		public int hashCode() {
			if (this.hashCodeDirty) {
				final int prime = PRIME;
				int result = DEFAULT_HASHCODE;

				result = prime * result + ((this.id == null) ? 0 : this.id.hashCode());

				this.hashCode = result;
				this.hashCodeDirty = false;
			}
			return this.hashCode;
		}

		@Override
		public boolean equals(Object obj) {
			if (this == obj)
				return true;
			if (obj == null)
				return false;
			if (getClass() != obj.getClass())
				return false;
			final row17Struct other = (row17Struct) obj;

			if (this.id == null) {
				if (other.id != null)
					return false;

			} else if (!this.id.equals(other.id))

				return false;

			return true;
		}

		public void copyDataTo(row17Struct other) {

			other.id = this.id;
			other.title = this.title;
			other.date = this.date;
			other.budget = this.budget;
			other.revenue = this.revenue;

		}

		public void copyKeysDataTo(row17Struct other) {

			other.id = this.id;

		}

		private Integer readInteger(ObjectInputStream dis) throws IOException {
			Integer intReturn;
			int length = 0;
			length = dis.readByte();
			if (length == -1) {
				intReturn = null;
			} else {
				intReturn = dis.readInt();
			}
			return intReturn;
		}

		private Integer readInteger(org.jboss.marshalling.Unmarshaller dis) throws IOException {
			Integer intReturn;
			int length = 0;
			length = dis.readByte();
			if (length == -1) {
				intReturn = null;
			} else {
				intReturn = dis.readInt();
			}
			return intReturn;
		}

		private void writeInteger(Integer intNum, ObjectOutputStream dos) throws IOException {
			if (intNum == null) {
				dos.writeByte(-1);
			} else {
				dos.writeByte(0);
				dos.writeInt(intNum);
			}
		}

		private void writeInteger(Integer intNum, org.jboss.marshalling.Marshaller marshaller) throws IOException {
			if (intNum == null) {
				marshaller.writeByte(-1);
			} else {
				marshaller.writeByte(0);
				marshaller.writeInt(intNum);
			}
		}

		private String readString(ObjectInputStream dis) throws IOException {
			String strReturn = null;
			int length = 0;
			length = dis.readInt();
			if (length == -1) {
				strReturn = null;
			} else {
				if (length > commonByteArray_MYFIRSTJOB_TP_MAJ.length) {
					if (length < 1024 && commonByteArray_MYFIRSTJOB_TP_MAJ.length == 0) {
						commonByteArray_MYFIRSTJOB_TP_MAJ = new byte[1024];
					} else {
						commonByteArray_MYFIRSTJOB_TP_MAJ = new byte[2 * length];
					}
				}
				dis.readFully(commonByteArray_MYFIRSTJOB_TP_MAJ, 0, length);
				strReturn = new String(commonByteArray_MYFIRSTJOB_TP_MAJ, 0, length, utf8Charset);
			}
			return strReturn;
		}

		private String readString(org.jboss.marshalling.Unmarshaller unmarshaller) throws IOException {
			String strReturn = null;
			int length = 0;
			length = unmarshaller.readInt();
			if (length == -1) {
				strReturn = null;
			} else {
				if (length > commonByteArray_MYFIRSTJOB_TP_MAJ.length) {
					if (length < 1024 && commonByteArray_MYFIRSTJOB_TP_MAJ.length == 0) {
						commonByteArray_MYFIRSTJOB_TP_MAJ = new byte[1024];
					} else {
						commonByteArray_MYFIRSTJOB_TP_MAJ = new byte[2 * length];
					}
				}
				unmarshaller.readFully(commonByteArray_MYFIRSTJOB_TP_MAJ, 0, length);
				strReturn = new String(commonByteArray_MYFIRSTJOB_TP_MAJ, 0, length, utf8Charset);
			}
			return strReturn;
		}

		private void writeString(String str, ObjectOutputStream dos) throws IOException {
			if (str == null) {
				dos.writeInt(-1);
			} else {
				byte[] byteArray = str.getBytes(utf8Charset);
				dos.writeInt(byteArray.length);
				dos.write(byteArray);
			}
		}

		private void writeString(String str, org.jboss.marshalling.Marshaller marshaller) throws IOException {
			if (str == null) {
				marshaller.writeInt(-1);
			} else {
				byte[] byteArray = str.getBytes(utf8Charset);
				marshaller.writeInt(byteArray.length);
				marshaller.write(byteArray);
			}
		}

		private java.util.Date readDate(ObjectInputStream dis) throws IOException {
			java.util.Date dateReturn = null;
			int length = 0;
			length = dis.readByte();
			if (length == -1) {
				dateReturn = null;
			} else {
				dateReturn = new Date(dis.readLong());
			}
			return dateReturn;
		}

		private java.util.Date readDate(org.jboss.marshalling.Unmarshaller unmarshaller) throws IOException {
			java.util.Date dateReturn = null;
			int length = 0;
			length = unmarshaller.readByte();
			if (length == -1) {
				dateReturn = null;
			} else {
				dateReturn = new Date(unmarshaller.readLong());
			}
			return dateReturn;
		}

		private void writeDate(java.util.Date date1, ObjectOutputStream dos) throws IOException {
			if (date1 == null) {
				dos.writeByte(-1);
			} else {
				dos.writeByte(0);
				dos.writeLong(date1.getTime());
			}
		}

		private void writeDate(java.util.Date date1, org.jboss.marshalling.Marshaller marshaller) throws IOException {
			if (date1 == null) {
				marshaller.writeByte(-1);
			} else {
				marshaller.writeByte(0);
				marshaller.writeLong(date1.getTime());
			}
		}

		public void readData(ObjectInputStream dis) {

			synchronized (commonByteArrayLock_MYFIRSTJOB_TP_MAJ) {

				try {

					int length = 0;

					this.id = readInteger(dis);

					this.title = readString(dis);

					this.date = readDate(dis);

					this.budget = readInteger(dis);

					length = dis.readByte();
					if (length == -1) {
						this.revenue = null;
					} else {
						this.revenue = dis.readLong();
					}

				} catch (IOException e) {
					throw new RuntimeException(e);

				}

			}

		}

		public void readData(org.jboss.marshalling.Unmarshaller dis) {

			synchronized (commonByteArrayLock_MYFIRSTJOB_TP_MAJ) {

				try {

					int length = 0;

					this.id = readInteger(dis);

					this.title = readString(dis);

					this.date = readDate(dis);

					this.budget = readInteger(dis);

					length = dis.readByte();
					if (length == -1) {
						this.revenue = null;
					} else {
						this.revenue = dis.readLong();
					}

				} catch (IOException e) {
					throw new RuntimeException(e);

				}

			}

		}

		public void writeData(ObjectOutputStream dos) {
			try {

				// Integer

				writeInteger(this.id, dos);

				// String

				writeString(this.title, dos);

				// java.util.Date

				writeDate(this.date, dos);

				// Integer

				writeInteger(this.budget, dos);

				// Long

				if (this.revenue == null) {
					dos.writeByte(-1);
				} else {
					dos.writeByte(0);
					dos.writeLong(this.revenue);
				}

			} catch (IOException e) {
				throw new RuntimeException(e);
			}

		}

		public void writeData(org.jboss.marshalling.Marshaller dos) {
			try {

				// Integer

				writeInteger(this.id, dos);

				// String

				writeString(this.title, dos);

				// java.util.Date

				writeDate(this.date, dos);

				// Integer

				writeInteger(this.budget, dos);

				// Long

				if (this.revenue == null) {
					dos.writeByte(-1);
				} else {
					dos.writeByte(0);
					dos.writeLong(this.revenue);
				}

			} catch (IOException e) {
				throw new RuntimeException(e);
			}

		}

		public String toString() {

			StringBuilder sb = new StringBuilder();
			sb.append(super.toString());
			sb.append("[");
			sb.append("id=" + String.valueOf(id));
			sb.append(",title=" + title);
			sb.append(",date=" + String.valueOf(date));
			sb.append(",budget=" + String.valueOf(budget));
			sb.append(",revenue=" + String.valueOf(revenue));
			sb.append("]");

			return sb.toString();
		}

		/**
		 * Compare keys
		 */
		public int compareTo(row17Struct other) {

			int returnValue = -1;

			returnValue = checkNullsAndCompare(this.id, other.id);
			if (returnValue != 0) {
				return returnValue;
			}

			return returnValue;
		}

		private int checkNullsAndCompare(Object object1, Object object2) {
			int returnValue = 0;
			if (object1 instanceof Comparable && object2 instanceof Comparable) {
				returnValue = ((Comparable) object1).compareTo(object2);
			} else if (object1 != null && object2 != null) {
				returnValue = compareStrings(object1.toString(), object2.toString());
			} else if (object1 == null && object2 != null) {
				returnValue = 1;
			} else if (object1 != null && object2 == null) {
				returnValue = -1;
			} else {
				returnValue = 0;
			}

			return returnValue;
		}

		private int compareStrings(String string1, String string2) {
			return string1.compareTo(string2);
		}

	}

	public static class row16Struct implements routines.system.IPersistableRow<row16Struct> {
		final static byte[] commonByteArrayLock_MYFIRSTJOB_TP_MAJ = new byte[0];
		static byte[] commonByteArray_MYFIRSTJOB_TP_MAJ = new byte[0];
		protected static final int DEFAULT_HASHCODE = 1;
		protected static final int PRIME = 31;
		protected int hashCode = DEFAULT_HASHCODE;
		public boolean hashCodeDirty = true;

		public String loopKey;

		public Integer id;

		public Integer getId() {
			return this.id;
		}

		public String title;

		public String getTitle() {
			return this.title;
		}

		public java.util.Date date;

		public java.util.Date getDate() {
			return this.date;
		}

		public Integer budget;

		public Integer getBudget() {
			return this.budget;
		}

		public Long revenue;

		public Long getRevenue() {
			return this.revenue;
		}

		@Override
		public int hashCode() {
			if (this.hashCodeDirty) {
				final int prime = PRIME;
				int result = DEFAULT_HASHCODE;

				result = prime * result + ((this.id == null) ? 0 : this.id.hashCode());

				this.hashCode = result;
				this.hashCodeDirty = false;
			}
			return this.hashCode;
		}

		@Override
		public boolean equals(Object obj) {
			if (this == obj)
				return true;
			if (obj == null)
				return false;
			if (getClass() != obj.getClass())
				return false;
			final row16Struct other = (row16Struct) obj;

			if (this.id == null) {
				if (other.id != null)
					return false;

			} else if (!this.id.equals(other.id))

				return false;

			return true;
		}

		public void copyDataTo(row16Struct other) {

			other.id = this.id;
			other.title = this.title;
			other.date = this.date;
			other.budget = this.budget;
			other.revenue = this.revenue;

		}

		public void copyKeysDataTo(row16Struct other) {

			other.id = this.id;

		}

		private Integer readInteger(ObjectInputStream dis) throws IOException {
			Integer intReturn;
			int length = 0;
			length = dis.readByte();
			if (length == -1) {
				intReturn = null;
			} else {
				intReturn = dis.readInt();
			}
			return intReturn;
		}

		private Integer readInteger(org.jboss.marshalling.Unmarshaller dis) throws IOException {
			Integer intReturn;
			int length = 0;
			length = dis.readByte();
			if (length == -1) {
				intReturn = null;
			} else {
				intReturn = dis.readInt();
			}
			return intReturn;
		}

		private void writeInteger(Integer intNum, ObjectOutputStream dos) throws IOException {
			if (intNum == null) {
				dos.writeByte(-1);
			} else {
				dos.writeByte(0);
				dos.writeInt(intNum);
			}
		}

		private void writeInteger(Integer intNum, org.jboss.marshalling.Marshaller marshaller) throws IOException {
			if (intNum == null) {
				marshaller.writeByte(-1);
			} else {
				marshaller.writeByte(0);
				marshaller.writeInt(intNum);
			}
		}

		private String readString(ObjectInputStream dis) throws IOException {
			String strReturn = null;
			int length = 0;
			length = dis.readInt();
			if (length == -1) {
				strReturn = null;
			} else {
				if (length > commonByteArray_MYFIRSTJOB_TP_MAJ.length) {
					if (length < 1024 && commonByteArray_MYFIRSTJOB_TP_MAJ.length == 0) {
						commonByteArray_MYFIRSTJOB_TP_MAJ = new byte[1024];
					} else {
						commonByteArray_MYFIRSTJOB_TP_MAJ = new byte[2 * length];
					}
				}
				dis.readFully(commonByteArray_MYFIRSTJOB_TP_MAJ, 0, length);
				strReturn = new String(commonByteArray_MYFIRSTJOB_TP_MAJ, 0, length, utf8Charset);
			}
			return strReturn;
		}

		private String readString(org.jboss.marshalling.Unmarshaller unmarshaller) throws IOException {
			String strReturn = null;
			int length = 0;
			length = unmarshaller.readInt();
			if (length == -1) {
				strReturn = null;
			} else {
				if (length > commonByteArray_MYFIRSTJOB_TP_MAJ.length) {
					if (length < 1024 && commonByteArray_MYFIRSTJOB_TP_MAJ.length == 0) {
						commonByteArray_MYFIRSTJOB_TP_MAJ = new byte[1024];
					} else {
						commonByteArray_MYFIRSTJOB_TP_MAJ = new byte[2 * length];
					}
				}
				unmarshaller.readFully(commonByteArray_MYFIRSTJOB_TP_MAJ, 0, length);
				strReturn = new String(commonByteArray_MYFIRSTJOB_TP_MAJ, 0, length, utf8Charset);
			}
			return strReturn;
		}

		private void writeString(String str, ObjectOutputStream dos) throws IOException {
			if (str == null) {
				dos.writeInt(-1);
			} else {
				byte[] byteArray = str.getBytes(utf8Charset);
				dos.writeInt(byteArray.length);
				dos.write(byteArray);
			}
		}

		private void writeString(String str, org.jboss.marshalling.Marshaller marshaller) throws IOException {
			if (str == null) {
				marshaller.writeInt(-1);
			} else {
				byte[] byteArray = str.getBytes(utf8Charset);
				marshaller.writeInt(byteArray.length);
				marshaller.write(byteArray);
			}
		}

		private java.util.Date readDate(ObjectInputStream dis) throws IOException {
			java.util.Date dateReturn = null;
			int length = 0;
			length = dis.readByte();
			if (length == -1) {
				dateReturn = null;
			} else {
				dateReturn = new Date(dis.readLong());
			}
			return dateReturn;
		}

		private java.util.Date readDate(org.jboss.marshalling.Unmarshaller unmarshaller) throws IOException {
			java.util.Date dateReturn = null;
			int length = 0;
			length = unmarshaller.readByte();
			if (length == -1) {
				dateReturn = null;
			} else {
				dateReturn = new Date(unmarshaller.readLong());
			}
			return dateReturn;
		}

		private void writeDate(java.util.Date date1, ObjectOutputStream dos) throws IOException {
			if (date1 == null) {
				dos.writeByte(-1);
			} else {
				dos.writeByte(0);
				dos.writeLong(date1.getTime());
			}
		}

		private void writeDate(java.util.Date date1, org.jboss.marshalling.Marshaller marshaller) throws IOException {
			if (date1 == null) {
				marshaller.writeByte(-1);
			} else {
				marshaller.writeByte(0);
				marshaller.writeLong(date1.getTime());
			}
		}

		public void readData(ObjectInputStream dis) {

			synchronized (commonByteArrayLock_MYFIRSTJOB_TP_MAJ) {

				try {

					int length = 0;

					this.id = readInteger(dis);

					this.title = readString(dis);

					this.date = readDate(dis);

					this.budget = readInteger(dis);

					length = dis.readByte();
					if (length == -1) {
						this.revenue = null;
					} else {
						this.revenue = dis.readLong();
					}

				} catch (IOException e) {
					throw new RuntimeException(e);

				}

			}

		}

		public void readData(org.jboss.marshalling.Unmarshaller dis) {

			synchronized (commonByteArrayLock_MYFIRSTJOB_TP_MAJ) {

				try {

					int length = 0;

					this.id = readInteger(dis);

					this.title = readString(dis);

					this.date = readDate(dis);

					this.budget = readInteger(dis);

					length = dis.readByte();
					if (length == -1) {
						this.revenue = null;
					} else {
						this.revenue = dis.readLong();
					}

				} catch (IOException e) {
					throw new RuntimeException(e);

				}

			}

		}

		public void writeData(ObjectOutputStream dos) {
			try {

				// Integer

				writeInteger(this.id, dos);

				// String

				writeString(this.title, dos);

				// java.util.Date

				writeDate(this.date, dos);

				// Integer

				writeInteger(this.budget, dos);

				// Long

				if (this.revenue == null) {
					dos.writeByte(-1);
				} else {
					dos.writeByte(0);
					dos.writeLong(this.revenue);
				}

			} catch (IOException e) {
				throw new RuntimeException(e);
			}

		}

		public void writeData(org.jboss.marshalling.Marshaller dos) {
			try {

				// Integer

				writeInteger(this.id, dos);

				// String

				writeString(this.title, dos);

				// java.util.Date

				writeDate(this.date, dos);

				// Integer

				writeInteger(this.budget, dos);

				// Long

				if (this.revenue == null) {
					dos.writeByte(-1);
				} else {
					dos.writeByte(0);
					dos.writeLong(this.revenue);
				}

			} catch (IOException e) {
				throw new RuntimeException(e);
			}

		}

		public String toString() {

			StringBuilder sb = new StringBuilder();
			sb.append(super.toString());
			sb.append("[");
			sb.append("id=" + String.valueOf(id));
			sb.append(",title=" + title);
			sb.append(",date=" + String.valueOf(date));
			sb.append(",budget=" + String.valueOf(budget));
			sb.append(",revenue=" + String.valueOf(revenue));
			sb.append("]");

			return sb.toString();
		}

		/**
		 * Compare keys
		 */
		public int compareTo(row16Struct other) {

			int returnValue = -1;

			returnValue = checkNullsAndCompare(this.id, other.id);
			if (returnValue != 0) {
				return returnValue;
			}

			return returnValue;
		}

		private int checkNullsAndCompare(Object object1, Object object2) {
			int returnValue = 0;
			if (object1 instanceof Comparable && object2 instanceof Comparable) {
				returnValue = ((Comparable) object1).compareTo(object2);
			} else if (object1 != null && object2 != null) {
				returnValue = compareStrings(object1.toString(), object2.toString());
			} else if (object1 == null && object2 != null) {
				returnValue = 1;
			} else if (object1 != null && object2 == null) {
				returnValue = -1;
			} else {
				returnValue = 0;
			}

			return returnValue;
		}

		private int compareStrings(String string1, String string2) {
			return string1.compareTo(string2);
		}

	}

	public static class OnRowsEndStructtSortRow_3
			implements routines.system.IPersistableRow<OnRowsEndStructtSortRow_3> {
		final static byte[] commonByteArrayLock_MYFIRSTJOB_TP_MAJ = new byte[0];
		static byte[] commonByteArray_MYFIRSTJOB_TP_MAJ = new byte[0];
		protected static final int DEFAULT_HASHCODE = 1;
		protected static final int PRIME = 31;
		protected int hashCode = DEFAULT_HASHCODE;
		public boolean hashCodeDirty = true;

		public String loopKey;

		public Integer id;

		public Integer getId() {
			return this.id;
		}

		public String title;

		public String getTitle() {
			return this.title;
		}

		public java.util.Date date;

		public java.util.Date getDate() {
			return this.date;
		}

		public Integer budget;

		public Integer getBudget() {
			return this.budget;
		}

		public Long revenue;

		public Long getRevenue() {
			return this.revenue;
		}

		@Override
		public int hashCode() {
			if (this.hashCodeDirty) {
				final int prime = PRIME;
				int result = DEFAULT_HASHCODE;

				result = prime * result + ((this.id == null) ? 0 : this.id.hashCode());

				this.hashCode = result;
				this.hashCodeDirty = false;
			}
			return this.hashCode;
		}

		@Override
		public boolean equals(Object obj) {
			if (this == obj)
				return true;
			if (obj == null)
				return false;
			if (getClass() != obj.getClass())
				return false;
			final OnRowsEndStructtSortRow_3 other = (OnRowsEndStructtSortRow_3) obj;

			if (this.id == null) {
				if (other.id != null)
					return false;

			} else if (!this.id.equals(other.id))

				return false;

			return true;
		}

		public void copyDataTo(OnRowsEndStructtSortRow_3 other) {

			other.id = this.id;
			other.title = this.title;
			other.date = this.date;
			other.budget = this.budget;
			other.revenue = this.revenue;

		}

		public void copyKeysDataTo(OnRowsEndStructtSortRow_3 other) {

			other.id = this.id;

		}

		private Integer readInteger(ObjectInputStream dis) throws IOException {
			Integer intReturn;
			int length = 0;
			length = dis.readByte();
			if (length == -1) {
				intReturn = null;
			} else {
				intReturn = dis.readInt();
			}
			return intReturn;
		}

		private Integer readInteger(org.jboss.marshalling.Unmarshaller dis) throws IOException {
			Integer intReturn;
			int length = 0;
			length = dis.readByte();
			if (length == -1) {
				intReturn = null;
			} else {
				intReturn = dis.readInt();
			}
			return intReturn;
		}

		private void writeInteger(Integer intNum, ObjectOutputStream dos) throws IOException {
			if (intNum == null) {
				dos.writeByte(-1);
			} else {
				dos.writeByte(0);
				dos.writeInt(intNum);
			}
		}

		private void writeInteger(Integer intNum, org.jboss.marshalling.Marshaller marshaller) throws IOException {
			if (intNum == null) {
				marshaller.writeByte(-1);
			} else {
				marshaller.writeByte(0);
				marshaller.writeInt(intNum);
			}
		}

		private String readString(ObjectInputStream dis) throws IOException {
			String strReturn = null;
			int length = 0;
			length = dis.readInt();
			if (length == -1) {
				strReturn = null;
			} else {
				if (length > commonByteArray_MYFIRSTJOB_TP_MAJ.length) {
					if (length < 1024 && commonByteArray_MYFIRSTJOB_TP_MAJ.length == 0) {
						commonByteArray_MYFIRSTJOB_TP_MAJ = new byte[1024];
					} else {
						commonByteArray_MYFIRSTJOB_TP_MAJ = new byte[2 * length];
					}
				}
				dis.readFully(commonByteArray_MYFIRSTJOB_TP_MAJ, 0, length);
				strReturn = new String(commonByteArray_MYFIRSTJOB_TP_MAJ, 0, length, utf8Charset);
			}
			return strReturn;
		}

		private String readString(org.jboss.marshalling.Unmarshaller unmarshaller) throws IOException {
			String strReturn = null;
			int length = 0;
			length = unmarshaller.readInt();
			if (length == -1) {
				strReturn = null;
			} else {
				if (length > commonByteArray_MYFIRSTJOB_TP_MAJ.length) {
					if (length < 1024 && commonByteArray_MYFIRSTJOB_TP_MAJ.length == 0) {
						commonByteArray_MYFIRSTJOB_TP_MAJ = new byte[1024];
					} else {
						commonByteArray_MYFIRSTJOB_TP_MAJ = new byte[2 * length];
					}
				}
				unmarshaller.readFully(commonByteArray_MYFIRSTJOB_TP_MAJ, 0, length);
				strReturn = new String(commonByteArray_MYFIRSTJOB_TP_MAJ, 0, length, utf8Charset);
			}
			return strReturn;
		}

		private void writeString(String str, ObjectOutputStream dos) throws IOException {
			if (str == null) {
				dos.writeInt(-1);
			} else {
				byte[] byteArray = str.getBytes(utf8Charset);
				dos.writeInt(byteArray.length);
				dos.write(byteArray);
			}
		}

		private void writeString(String str, org.jboss.marshalling.Marshaller marshaller) throws IOException {
			if (str == null) {
				marshaller.writeInt(-1);
			} else {
				byte[] byteArray = str.getBytes(utf8Charset);
				marshaller.writeInt(byteArray.length);
				marshaller.write(byteArray);
			}
		}

		private java.util.Date readDate(ObjectInputStream dis) throws IOException {
			java.util.Date dateReturn = null;
			int length = 0;
			length = dis.readByte();
			if (length == -1) {
				dateReturn = null;
			} else {
				dateReturn = new Date(dis.readLong());
			}
			return dateReturn;
		}

		private java.util.Date readDate(org.jboss.marshalling.Unmarshaller unmarshaller) throws IOException {
			java.util.Date dateReturn = null;
			int length = 0;
			length = unmarshaller.readByte();
			if (length == -1) {
				dateReturn = null;
			} else {
				dateReturn = new Date(unmarshaller.readLong());
			}
			return dateReturn;
		}

		private void writeDate(java.util.Date date1, ObjectOutputStream dos) throws IOException {
			if (date1 == null) {
				dos.writeByte(-1);
			} else {
				dos.writeByte(0);
				dos.writeLong(date1.getTime());
			}
		}

		private void writeDate(java.util.Date date1, org.jboss.marshalling.Marshaller marshaller) throws IOException {
			if (date1 == null) {
				marshaller.writeByte(-1);
			} else {
				marshaller.writeByte(0);
				marshaller.writeLong(date1.getTime());
			}
		}

		public void readData(ObjectInputStream dis) {

			synchronized (commonByteArrayLock_MYFIRSTJOB_TP_MAJ) {

				try {

					int length = 0;

					this.id = readInteger(dis);

					this.title = readString(dis);

					this.date = readDate(dis);

					this.budget = readInteger(dis);

					length = dis.readByte();
					if (length == -1) {
						this.revenue = null;
					} else {
						this.revenue = dis.readLong();
					}

				} catch (IOException e) {
					throw new RuntimeException(e);

				}

			}

		}

		public void readData(org.jboss.marshalling.Unmarshaller dis) {

			synchronized (commonByteArrayLock_MYFIRSTJOB_TP_MAJ) {

				try {

					int length = 0;

					this.id = readInteger(dis);

					this.title = readString(dis);

					this.date = readDate(dis);

					this.budget = readInteger(dis);

					length = dis.readByte();
					if (length == -1) {
						this.revenue = null;
					} else {
						this.revenue = dis.readLong();
					}

				} catch (IOException e) {
					throw new RuntimeException(e);

				}

			}

		}

		public void writeData(ObjectOutputStream dos) {
			try {

				// Integer

				writeInteger(this.id, dos);

				// String

				writeString(this.title, dos);

				// java.util.Date

				writeDate(this.date, dos);

				// Integer

				writeInteger(this.budget, dos);

				// Long

				if (this.revenue == null) {
					dos.writeByte(-1);
				} else {
					dos.writeByte(0);
					dos.writeLong(this.revenue);
				}

			} catch (IOException e) {
				throw new RuntimeException(e);
			}

		}

		public void writeData(org.jboss.marshalling.Marshaller dos) {
			try {

				// Integer

				writeInteger(this.id, dos);

				// String

				writeString(this.title, dos);

				// java.util.Date

				writeDate(this.date, dos);

				// Integer

				writeInteger(this.budget, dos);

				// Long

				if (this.revenue == null) {
					dos.writeByte(-1);
				} else {
					dos.writeByte(0);
					dos.writeLong(this.revenue);
				}

			} catch (IOException e) {
				throw new RuntimeException(e);
			}

		}

		public String toString() {

			StringBuilder sb = new StringBuilder();
			sb.append(super.toString());
			sb.append("[");
			sb.append("id=" + String.valueOf(id));
			sb.append(",title=" + title);
			sb.append(",date=" + String.valueOf(date));
			sb.append(",budget=" + String.valueOf(budget));
			sb.append(",revenue=" + String.valueOf(revenue));
			sb.append("]");

			return sb.toString();
		}

		/**
		 * Compare keys
		 */
		public int compareTo(OnRowsEndStructtSortRow_3 other) {

			int returnValue = -1;

			returnValue = checkNullsAndCompare(this.id, other.id);
			if (returnValue != 0) {
				return returnValue;
			}

			return returnValue;
		}

		private int checkNullsAndCompare(Object object1, Object object2) {
			int returnValue = 0;
			if (object1 instanceof Comparable && object2 instanceof Comparable) {
				returnValue = ((Comparable) object1).compareTo(object2);
			} else if (object1 != null && object2 != null) {
				returnValue = compareStrings(object1.toString(), object2.toString());
			} else if (object1 == null && object2 != null) {
				returnValue = 1;
			} else if (object1 != null && object2 == null) {
				returnValue = -1;
			} else {
				returnValue = 0;
			}

			return returnValue;
		}

		private int compareStrings(String string1, String string2) {
			return string1.compareTo(string2);
		}

	}

	public static class row15Struct implements routines.system.IPersistableRow<row15Struct> {
		final static byte[] commonByteArrayLock_MYFIRSTJOB_TP_MAJ = new byte[0];
		static byte[] commonByteArray_MYFIRSTJOB_TP_MAJ = new byte[0];
		protected static final int DEFAULT_HASHCODE = 1;
		protected static final int PRIME = 31;
		protected int hashCode = DEFAULT_HASHCODE;
		public boolean hashCodeDirty = true;

		public String loopKey;

		public Integer id;

		public Integer getId() {
			return this.id;
		}

		public String title;

		public String getTitle() {
			return this.title;
		}

		public java.util.Date date;

		public java.util.Date getDate() {
			return this.date;
		}

		public Integer budget;

		public Integer getBudget() {
			return this.budget;
		}

		public Long revenue;

		public Long getRevenue() {
			return this.revenue;
		}

		@Override
		public int hashCode() {
			if (this.hashCodeDirty) {
				final int prime = PRIME;
				int result = DEFAULT_HASHCODE;

				result = prime * result + ((this.id == null) ? 0 : this.id.hashCode());

				this.hashCode = result;
				this.hashCodeDirty = false;
			}
			return this.hashCode;
		}

		@Override
		public boolean equals(Object obj) {
			if (this == obj)
				return true;
			if (obj == null)
				return false;
			if (getClass() != obj.getClass())
				return false;
			final row15Struct other = (row15Struct) obj;

			if (this.id == null) {
				if (other.id != null)
					return false;

			} else if (!this.id.equals(other.id))

				return false;

			return true;
		}

		public void copyDataTo(row15Struct other) {

			other.id = this.id;
			other.title = this.title;
			other.date = this.date;
			other.budget = this.budget;
			other.revenue = this.revenue;

		}

		public void copyKeysDataTo(row15Struct other) {

			other.id = this.id;

		}

		private Integer readInteger(ObjectInputStream dis) throws IOException {
			Integer intReturn;
			int length = 0;
			length = dis.readByte();
			if (length == -1) {
				intReturn = null;
			} else {
				intReturn = dis.readInt();
			}
			return intReturn;
		}

		private Integer readInteger(org.jboss.marshalling.Unmarshaller dis) throws IOException {
			Integer intReturn;
			int length = 0;
			length = dis.readByte();
			if (length == -1) {
				intReturn = null;
			} else {
				intReturn = dis.readInt();
			}
			return intReturn;
		}

		private void writeInteger(Integer intNum, ObjectOutputStream dos) throws IOException {
			if (intNum == null) {
				dos.writeByte(-1);
			} else {
				dos.writeByte(0);
				dos.writeInt(intNum);
			}
		}

		private void writeInteger(Integer intNum, org.jboss.marshalling.Marshaller marshaller) throws IOException {
			if (intNum == null) {
				marshaller.writeByte(-1);
			} else {
				marshaller.writeByte(0);
				marshaller.writeInt(intNum);
			}
		}

		private String readString(ObjectInputStream dis) throws IOException {
			String strReturn = null;
			int length = 0;
			length = dis.readInt();
			if (length == -1) {
				strReturn = null;
			} else {
				if (length > commonByteArray_MYFIRSTJOB_TP_MAJ.length) {
					if (length < 1024 && commonByteArray_MYFIRSTJOB_TP_MAJ.length == 0) {
						commonByteArray_MYFIRSTJOB_TP_MAJ = new byte[1024];
					} else {
						commonByteArray_MYFIRSTJOB_TP_MAJ = new byte[2 * length];
					}
				}
				dis.readFully(commonByteArray_MYFIRSTJOB_TP_MAJ, 0, length);
				strReturn = new String(commonByteArray_MYFIRSTJOB_TP_MAJ, 0, length, utf8Charset);
			}
			return strReturn;
		}

		private String readString(org.jboss.marshalling.Unmarshaller unmarshaller) throws IOException {
			String strReturn = null;
			int length = 0;
			length = unmarshaller.readInt();
			if (length == -1) {
				strReturn = null;
			} else {
				if (length > commonByteArray_MYFIRSTJOB_TP_MAJ.length) {
					if (length < 1024 && commonByteArray_MYFIRSTJOB_TP_MAJ.length == 0) {
						commonByteArray_MYFIRSTJOB_TP_MAJ = new byte[1024];
					} else {
						commonByteArray_MYFIRSTJOB_TP_MAJ = new byte[2 * length];
					}
				}
				unmarshaller.readFully(commonByteArray_MYFIRSTJOB_TP_MAJ, 0, length);
				strReturn = new String(commonByteArray_MYFIRSTJOB_TP_MAJ, 0, length, utf8Charset);
			}
			return strReturn;
		}

		private void writeString(String str, ObjectOutputStream dos) throws IOException {
			if (str == null) {
				dos.writeInt(-1);
			} else {
				byte[] byteArray = str.getBytes(utf8Charset);
				dos.writeInt(byteArray.length);
				dos.write(byteArray);
			}
		}

		private void writeString(String str, org.jboss.marshalling.Marshaller marshaller) throws IOException {
			if (str == null) {
				marshaller.writeInt(-1);
			} else {
				byte[] byteArray = str.getBytes(utf8Charset);
				marshaller.writeInt(byteArray.length);
				marshaller.write(byteArray);
			}
		}

		private java.util.Date readDate(ObjectInputStream dis) throws IOException {
			java.util.Date dateReturn = null;
			int length = 0;
			length = dis.readByte();
			if (length == -1) {
				dateReturn = null;
			} else {
				dateReturn = new Date(dis.readLong());
			}
			return dateReturn;
		}

		private java.util.Date readDate(org.jboss.marshalling.Unmarshaller unmarshaller) throws IOException {
			java.util.Date dateReturn = null;
			int length = 0;
			length = unmarshaller.readByte();
			if (length == -1) {
				dateReturn = null;
			} else {
				dateReturn = new Date(unmarshaller.readLong());
			}
			return dateReturn;
		}

		private void writeDate(java.util.Date date1, ObjectOutputStream dos) throws IOException {
			if (date1 == null) {
				dos.writeByte(-1);
			} else {
				dos.writeByte(0);
				dos.writeLong(date1.getTime());
			}
		}

		private void writeDate(java.util.Date date1, org.jboss.marshalling.Marshaller marshaller) throws IOException {
			if (date1 == null) {
				marshaller.writeByte(-1);
			} else {
				marshaller.writeByte(0);
				marshaller.writeLong(date1.getTime());
			}
		}

		public void readData(ObjectInputStream dis) {

			synchronized (commonByteArrayLock_MYFIRSTJOB_TP_MAJ) {

				try {

					int length = 0;

					this.id = readInteger(dis);

					this.title = readString(dis);

					this.date = readDate(dis);

					this.budget = readInteger(dis);

					length = dis.readByte();
					if (length == -1) {
						this.revenue = null;
					} else {
						this.revenue = dis.readLong();
					}

				} catch (IOException e) {
					throw new RuntimeException(e);

				}

			}

		}

		public void readData(org.jboss.marshalling.Unmarshaller dis) {

			synchronized (commonByteArrayLock_MYFIRSTJOB_TP_MAJ) {

				try {

					int length = 0;

					this.id = readInteger(dis);

					this.title = readString(dis);

					this.date = readDate(dis);

					this.budget = readInteger(dis);

					length = dis.readByte();
					if (length == -1) {
						this.revenue = null;
					} else {
						this.revenue = dis.readLong();
					}

				} catch (IOException e) {
					throw new RuntimeException(e);

				}

			}

		}

		public void writeData(ObjectOutputStream dos) {
			try {

				// Integer

				writeInteger(this.id, dos);

				// String

				writeString(this.title, dos);

				// java.util.Date

				writeDate(this.date, dos);

				// Integer

				writeInteger(this.budget, dos);

				// Long

				if (this.revenue == null) {
					dos.writeByte(-1);
				} else {
					dos.writeByte(0);
					dos.writeLong(this.revenue);
				}

			} catch (IOException e) {
				throw new RuntimeException(e);
			}

		}

		public void writeData(org.jboss.marshalling.Marshaller dos) {
			try {

				// Integer

				writeInteger(this.id, dos);

				// String

				writeString(this.title, dos);

				// java.util.Date

				writeDate(this.date, dos);

				// Integer

				writeInteger(this.budget, dos);

				// Long

				if (this.revenue == null) {
					dos.writeByte(-1);
				} else {
					dos.writeByte(0);
					dos.writeLong(this.revenue);
				}

			} catch (IOException e) {
				throw new RuntimeException(e);
			}

		}

		public String toString() {

			StringBuilder sb = new StringBuilder();
			sb.append(super.toString());
			sb.append("[");
			sb.append("id=" + String.valueOf(id));
			sb.append(",title=" + title);
			sb.append(",date=" + String.valueOf(date));
			sb.append(",budget=" + String.valueOf(budget));
			sb.append(",revenue=" + String.valueOf(revenue));
			sb.append("]");

			return sb.toString();
		}

		/**
		 * Compare keys
		 */
		public int compareTo(row15Struct other) {

			int returnValue = -1;

			returnValue = checkNullsAndCompare(this.id, other.id);
			if (returnValue != 0) {
				return returnValue;
			}

			return returnValue;
		}

		private int checkNullsAndCompare(Object object1, Object object2) {
			int returnValue = 0;
			if (object1 instanceof Comparable && object2 instanceof Comparable) {
				returnValue = ((Comparable) object1).compareTo(object2);
			} else if (object1 != null && object2 != null) {
				returnValue = compareStrings(object1.toString(), object2.toString());
			} else if (object1 == null && object2 != null) {
				returnValue = 1;
			} else if (object1 != null && object2 == null) {
				returnValue = -1;
			} else {
				returnValue = 0;
			}

			return returnValue;
		}

		private int compareStrings(String string1, String string2) {
			return string1.compareTo(string2);
		}

	}

	public static class row13Struct implements routines.system.IPersistableRow<row13Struct> {
		final static byte[] commonByteArrayLock_MYFIRSTJOB_TP_MAJ = new byte[0];
		static byte[] commonByteArray_MYFIRSTJOB_TP_MAJ = new byte[0];
		protected static final int DEFAULT_HASHCODE = 1;
		protected static final int PRIME = 31;
		protected int hashCode = DEFAULT_HASHCODE;
		public boolean hashCodeDirty = true;

		public String loopKey;

		public Integer id;

		public Integer getId() {
			return this.id;
		}

		public String title;

		public String getTitle() {
			return this.title;
		}

		public java.util.Date date;

		public java.util.Date getDate() {
			return this.date;
		}

		public Float popularity;

		public Float getPopularity() {
			return this.popularity;
		}

		public Integer vote_count;

		public Integer getVote_count() {
			return this.vote_count;
		}

		public Float vote_average;

		public Float getVote_average() {
			return this.vote_average;
		}

		@Override
		public int hashCode() {
			if (this.hashCodeDirty) {
				final int prime = PRIME;
				int result = DEFAULT_HASHCODE;

				result = prime * result + ((this.id == null) ? 0 : this.id.hashCode());

				this.hashCode = result;
				this.hashCodeDirty = false;
			}
			return this.hashCode;
		}

		@Override
		public boolean equals(Object obj) {
			if (this == obj)
				return true;
			if (obj == null)
				return false;
			if (getClass() != obj.getClass())
				return false;
			final row13Struct other = (row13Struct) obj;

			if (this.id == null) {
				if (other.id != null)
					return false;

			} else if (!this.id.equals(other.id))

				return false;

			return true;
		}

		public void copyDataTo(row13Struct other) {

			other.id = this.id;
			other.title = this.title;
			other.date = this.date;
			other.popularity = this.popularity;
			other.vote_count = this.vote_count;
			other.vote_average = this.vote_average;

		}

		public void copyKeysDataTo(row13Struct other) {

			other.id = this.id;

		}

		private Integer readInteger(ObjectInputStream dis) throws IOException {
			Integer intReturn;
			int length = 0;
			length = dis.readByte();
			if (length == -1) {
				intReturn = null;
			} else {
				intReturn = dis.readInt();
			}
			return intReturn;
		}

		private Integer readInteger(org.jboss.marshalling.Unmarshaller dis) throws IOException {
			Integer intReturn;
			int length = 0;
			length = dis.readByte();
			if (length == -1) {
				intReturn = null;
			} else {
				intReturn = dis.readInt();
			}
			return intReturn;
		}

		private void writeInteger(Integer intNum, ObjectOutputStream dos) throws IOException {
			if (intNum == null) {
				dos.writeByte(-1);
			} else {
				dos.writeByte(0);
				dos.writeInt(intNum);
			}
		}

		private void writeInteger(Integer intNum, org.jboss.marshalling.Marshaller marshaller) throws IOException {
			if (intNum == null) {
				marshaller.writeByte(-1);
			} else {
				marshaller.writeByte(0);
				marshaller.writeInt(intNum);
			}
		}

		private String readString(ObjectInputStream dis) throws IOException {
			String strReturn = null;
			int length = 0;
			length = dis.readInt();
			if (length == -1) {
				strReturn = null;
			} else {
				if (length > commonByteArray_MYFIRSTJOB_TP_MAJ.length) {
					if (length < 1024 && commonByteArray_MYFIRSTJOB_TP_MAJ.length == 0) {
						commonByteArray_MYFIRSTJOB_TP_MAJ = new byte[1024];
					} else {
						commonByteArray_MYFIRSTJOB_TP_MAJ = new byte[2 * length];
					}
				}
				dis.readFully(commonByteArray_MYFIRSTJOB_TP_MAJ, 0, length);
				strReturn = new String(commonByteArray_MYFIRSTJOB_TP_MAJ, 0, length, utf8Charset);
			}
			return strReturn;
		}

		private String readString(org.jboss.marshalling.Unmarshaller unmarshaller) throws IOException {
			String strReturn = null;
			int length = 0;
			length = unmarshaller.readInt();
			if (length == -1) {
				strReturn = null;
			} else {
				if (length > commonByteArray_MYFIRSTJOB_TP_MAJ.length) {
					if (length < 1024 && commonByteArray_MYFIRSTJOB_TP_MAJ.length == 0) {
						commonByteArray_MYFIRSTJOB_TP_MAJ = new byte[1024];
					} else {
						commonByteArray_MYFIRSTJOB_TP_MAJ = new byte[2 * length];
					}
				}
				unmarshaller.readFully(commonByteArray_MYFIRSTJOB_TP_MAJ, 0, length);
				strReturn = new String(commonByteArray_MYFIRSTJOB_TP_MAJ, 0, length, utf8Charset);
			}
			return strReturn;
		}

		private void writeString(String str, ObjectOutputStream dos) throws IOException {
			if (str == null) {
				dos.writeInt(-1);
			} else {
				byte[] byteArray = str.getBytes(utf8Charset);
				dos.writeInt(byteArray.length);
				dos.write(byteArray);
			}
		}

		private void writeString(String str, org.jboss.marshalling.Marshaller marshaller) throws IOException {
			if (str == null) {
				marshaller.writeInt(-1);
			} else {
				byte[] byteArray = str.getBytes(utf8Charset);
				marshaller.writeInt(byteArray.length);
				marshaller.write(byteArray);
			}
		}

		private java.util.Date readDate(ObjectInputStream dis) throws IOException {
			java.util.Date dateReturn = null;
			int length = 0;
			length = dis.readByte();
			if (length == -1) {
				dateReturn = null;
			} else {
				dateReturn = new Date(dis.readLong());
			}
			return dateReturn;
		}

		private java.util.Date readDate(org.jboss.marshalling.Unmarshaller unmarshaller) throws IOException {
			java.util.Date dateReturn = null;
			int length = 0;
			length = unmarshaller.readByte();
			if (length == -1) {
				dateReturn = null;
			} else {
				dateReturn = new Date(unmarshaller.readLong());
			}
			return dateReturn;
		}

		private void writeDate(java.util.Date date1, ObjectOutputStream dos) throws IOException {
			if (date1 == null) {
				dos.writeByte(-1);
			} else {
				dos.writeByte(0);
				dos.writeLong(date1.getTime());
			}
		}

		private void writeDate(java.util.Date date1, org.jboss.marshalling.Marshaller marshaller) throws IOException {
			if (date1 == null) {
				marshaller.writeByte(-1);
			} else {
				marshaller.writeByte(0);
				marshaller.writeLong(date1.getTime());
			}
		}

		public void readData(ObjectInputStream dis) {

			synchronized (commonByteArrayLock_MYFIRSTJOB_TP_MAJ) {

				try {

					int length = 0;

					this.id = readInteger(dis);

					this.title = readString(dis);

					this.date = readDate(dis);

					length = dis.readByte();
					if (length == -1) {
						this.popularity = null;
					} else {
						this.popularity = dis.readFloat();
					}

					this.vote_count = readInteger(dis);

					length = dis.readByte();
					if (length == -1) {
						this.vote_average = null;
					} else {
						this.vote_average = dis.readFloat();
					}

				} catch (IOException e) {
					throw new RuntimeException(e);

				}

			}

		}

		public void readData(org.jboss.marshalling.Unmarshaller dis) {

			synchronized (commonByteArrayLock_MYFIRSTJOB_TP_MAJ) {

				try {

					int length = 0;

					this.id = readInteger(dis);

					this.title = readString(dis);

					this.date = readDate(dis);

					length = dis.readByte();
					if (length == -1) {
						this.popularity = null;
					} else {
						this.popularity = dis.readFloat();
					}

					this.vote_count = readInteger(dis);

					length = dis.readByte();
					if (length == -1) {
						this.vote_average = null;
					} else {
						this.vote_average = dis.readFloat();
					}

				} catch (IOException e) {
					throw new RuntimeException(e);

				}

			}

		}

		public void writeData(ObjectOutputStream dos) {
			try {

				// Integer

				writeInteger(this.id, dos);

				// String

				writeString(this.title, dos);

				// java.util.Date

				writeDate(this.date, dos);

				// Float

				if (this.popularity == null) {
					dos.writeByte(-1);
				} else {
					dos.writeByte(0);
					dos.writeFloat(this.popularity);
				}

				// Integer

				writeInteger(this.vote_count, dos);

				// Float

				if (this.vote_average == null) {
					dos.writeByte(-1);
				} else {
					dos.writeByte(0);
					dos.writeFloat(this.vote_average);
				}

			} catch (IOException e) {
				throw new RuntimeException(e);
			}

		}

		public void writeData(org.jboss.marshalling.Marshaller dos) {
			try {

				// Integer

				writeInteger(this.id, dos);

				// String

				writeString(this.title, dos);

				// java.util.Date

				writeDate(this.date, dos);

				// Float

				if (this.popularity == null) {
					dos.writeByte(-1);
				} else {
					dos.writeByte(0);
					dos.writeFloat(this.popularity);
				}

				// Integer

				writeInteger(this.vote_count, dos);

				// Float

				if (this.vote_average == null) {
					dos.writeByte(-1);
				} else {
					dos.writeByte(0);
					dos.writeFloat(this.vote_average);
				}

			} catch (IOException e) {
				throw new RuntimeException(e);
			}

		}

		public String toString() {

			StringBuilder sb = new StringBuilder();
			sb.append(super.toString());
			sb.append("[");
			sb.append("id=" + String.valueOf(id));
			sb.append(",title=" + title);
			sb.append(",date=" + String.valueOf(date));
			sb.append(",popularity=" + String.valueOf(popularity));
			sb.append(",vote_count=" + String.valueOf(vote_count));
			sb.append(",vote_average=" + String.valueOf(vote_average));
			sb.append("]");

			return sb.toString();
		}

		/**
		 * Compare keys
		 */
		public int compareTo(row13Struct other) {

			int returnValue = -1;

			returnValue = checkNullsAndCompare(this.id, other.id);
			if (returnValue != 0) {
				return returnValue;
			}

			return returnValue;
		}

		private int checkNullsAndCompare(Object object1, Object object2) {
			int returnValue = 0;
			if (object1 instanceof Comparable && object2 instanceof Comparable) {
				returnValue = ((Comparable) object1).compareTo(object2);
			} else if (object1 != null && object2 != null) {
				returnValue = compareStrings(object1.toString(), object2.toString());
			} else if (object1 == null && object2 != null) {
				returnValue = 1;
			} else if (object1 != null && object2 == null) {
				returnValue = -1;
			} else {
				returnValue = 0;
			}

			return returnValue;
		}

		private int compareStrings(String string1, String string2) {
			return string1.compareTo(string2);
		}

	}

	public static class row12Struct implements routines.system.IPersistableRow<row12Struct> {
		final static byte[] commonByteArrayLock_MYFIRSTJOB_TP_MAJ = new byte[0];
		static byte[] commonByteArray_MYFIRSTJOB_TP_MAJ = new byte[0];
		protected static final int DEFAULT_HASHCODE = 1;
		protected static final int PRIME = 31;
		protected int hashCode = DEFAULT_HASHCODE;
		public boolean hashCodeDirty = true;

		public String loopKey;

		public Integer id;

		public Integer getId() {
			return this.id;
		}

		public String title;

		public String getTitle() {
			return this.title;
		}

		public Integer budget;

		public Integer getBudget() {
			return this.budget;
		}

		public Long revenue;

		public Long getRevenue() {
			return this.revenue;
		}

		public java.util.Date date;

		public java.util.Date getDate() {
			return this.date;
		}

		@Override
		public int hashCode() {
			if (this.hashCodeDirty) {
				final int prime = PRIME;
				int result = DEFAULT_HASHCODE;

				result = prime * result + ((this.id == null) ? 0 : this.id.hashCode());

				this.hashCode = result;
				this.hashCodeDirty = false;
			}
			return this.hashCode;
		}

		@Override
		public boolean equals(Object obj) {
			if (this == obj)
				return true;
			if (obj == null)
				return false;
			if (getClass() != obj.getClass())
				return false;
			final row12Struct other = (row12Struct) obj;

			if (this.id == null) {
				if (other.id != null)
					return false;

			} else if (!this.id.equals(other.id))

				return false;

			return true;
		}

		public void copyDataTo(row12Struct other) {

			other.id = this.id;
			other.title = this.title;
			other.budget = this.budget;
			other.revenue = this.revenue;
			other.date = this.date;

		}

		public void copyKeysDataTo(row12Struct other) {

			other.id = this.id;

		}

		private Integer readInteger(ObjectInputStream dis) throws IOException {
			Integer intReturn;
			int length = 0;
			length = dis.readByte();
			if (length == -1) {
				intReturn = null;
			} else {
				intReturn = dis.readInt();
			}
			return intReturn;
		}

		private Integer readInteger(org.jboss.marshalling.Unmarshaller dis) throws IOException {
			Integer intReturn;
			int length = 0;
			length = dis.readByte();
			if (length == -1) {
				intReturn = null;
			} else {
				intReturn = dis.readInt();
			}
			return intReturn;
		}

		private void writeInteger(Integer intNum, ObjectOutputStream dos) throws IOException {
			if (intNum == null) {
				dos.writeByte(-1);
			} else {
				dos.writeByte(0);
				dos.writeInt(intNum);
			}
		}

		private void writeInteger(Integer intNum, org.jboss.marshalling.Marshaller marshaller) throws IOException {
			if (intNum == null) {
				marshaller.writeByte(-1);
			} else {
				marshaller.writeByte(0);
				marshaller.writeInt(intNum);
			}
		}

		private String readString(ObjectInputStream dis) throws IOException {
			String strReturn = null;
			int length = 0;
			length = dis.readInt();
			if (length == -1) {
				strReturn = null;
			} else {
				if (length > commonByteArray_MYFIRSTJOB_TP_MAJ.length) {
					if (length < 1024 && commonByteArray_MYFIRSTJOB_TP_MAJ.length == 0) {
						commonByteArray_MYFIRSTJOB_TP_MAJ = new byte[1024];
					} else {
						commonByteArray_MYFIRSTJOB_TP_MAJ = new byte[2 * length];
					}
				}
				dis.readFully(commonByteArray_MYFIRSTJOB_TP_MAJ, 0, length);
				strReturn = new String(commonByteArray_MYFIRSTJOB_TP_MAJ, 0, length, utf8Charset);
			}
			return strReturn;
		}

		private String readString(org.jboss.marshalling.Unmarshaller unmarshaller) throws IOException {
			String strReturn = null;
			int length = 0;
			length = unmarshaller.readInt();
			if (length == -1) {
				strReturn = null;
			} else {
				if (length > commonByteArray_MYFIRSTJOB_TP_MAJ.length) {
					if (length < 1024 && commonByteArray_MYFIRSTJOB_TP_MAJ.length == 0) {
						commonByteArray_MYFIRSTJOB_TP_MAJ = new byte[1024];
					} else {
						commonByteArray_MYFIRSTJOB_TP_MAJ = new byte[2 * length];
					}
				}
				unmarshaller.readFully(commonByteArray_MYFIRSTJOB_TP_MAJ, 0, length);
				strReturn = new String(commonByteArray_MYFIRSTJOB_TP_MAJ, 0, length, utf8Charset);
			}
			return strReturn;
		}

		private void writeString(String str, ObjectOutputStream dos) throws IOException {
			if (str == null) {
				dos.writeInt(-1);
			} else {
				byte[] byteArray = str.getBytes(utf8Charset);
				dos.writeInt(byteArray.length);
				dos.write(byteArray);
			}
		}

		private void writeString(String str, org.jboss.marshalling.Marshaller marshaller) throws IOException {
			if (str == null) {
				marshaller.writeInt(-1);
			} else {
				byte[] byteArray = str.getBytes(utf8Charset);
				marshaller.writeInt(byteArray.length);
				marshaller.write(byteArray);
			}
		}

		private java.util.Date readDate(ObjectInputStream dis) throws IOException {
			java.util.Date dateReturn = null;
			int length = 0;
			length = dis.readByte();
			if (length == -1) {
				dateReturn = null;
			} else {
				dateReturn = new Date(dis.readLong());
			}
			return dateReturn;
		}

		private java.util.Date readDate(org.jboss.marshalling.Unmarshaller unmarshaller) throws IOException {
			java.util.Date dateReturn = null;
			int length = 0;
			length = unmarshaller.readByte();
			if (length == -1) {
				dateReturn = null;
			} else {
				dateReturn = new Date(unmarshaller.readLong());
			}
			return dateReturn;
		}

		private void writeDate(java.util.Date date1, ObjectOutputStream dos) throws IOException {
			if (date1 == null) {
				dos.writeByte(-1);
			} else {
				dos.writeByte(0);
				dos.writeLong(date1.getTime());
			}
		}

		private void writeDate(java.util.Date date1, org.jboss.marshalling.Marshaller marshaller) throws IOException {
			if (date1 == null) {
				marshaller.writeByte(-1);
			} else {
				marshaller.writeByte(0);
				marshaller.writeLong(date1.getTime());
			}
		}

		public void readData(ObjectInputStream dis) {

			synchronized (commonByteArrayLock_MYFIRSTJOB_TP_MAJ) {

				try {

					int length = 0;

					this.id = readInteger(dis);

					this.title = readString(dis);

					this.budget = readInteger(dis);

					length = dis.readByte();
					if (length == -1) {
						this.revenue = null;
					} else {
						this.revenue = dis.readLong();
					}

					this.date = readDate(dis);

				} catch (IOException e) {
					throw new RuntimeException(e);

				}

			}

		}

		public void readData(org.jboss.marshalling.Unmarshaller dis) {

			synchronized (commonByteArrayLock_MYFIRSTJOB_TP_MAJ) {

				try {

					int length = 0;

					this.id = readInteger(dis);

					this.title = readString(dis);

					this.budget = readInteger(dis);

					length = dis.readByte();
					if (length == -1) {
						this.revenue = null;
					} else {
						this.revenue = dis.readLong();
					}

					this.date = readDate(dis);

				} catch (IOException e) {
					throw new RuntimeException(e);

				}

			}

		}

		public void writeData(ObjectOutputStream dos) {
			try {

				// Integer

				writeInteger(this.id, dos);

				// String

				writeString(this.title, dos);

				// Integer

				writeInteger(this.budget, dos);

				// Long

				if (this.revenue == null) {
					dos.writeByte(-1);
				} else {
					dos.writeByte(0);
					dos.writeLong(this.revenue);
				}

				// java.util.Date

				writeDate(this.date, dos);

			} catch (IOException e) {
				throw new RuntimeException(e);
			}

		}

		public void writeData(org.jboss.marshalling.Marshaller dos) {
			try {

				// Integer

				writeInteger(this.id, dos);

				// String

				writeString(this.title, dos);

				// Integer

				writeInteger(this.budget, dos);

				// Long

				if (this.revenue == null) {
					dos.writeByte(-1);
				} else {
					dos.writeByte(0);
					dos.writeLong(this.revenue);
				}

				// java.util.Date

				writeDate(this.date, dos);

			} catch (IOException e) {
				throw new RuntimeException(e);
			}

		}

		public String toString() {

			StringBuilder sb = new StringBuilder();
			sb.append(super.toString());
			sb.append("[");
			sb.append("id=" + String.valueOf(id));
			sb.append(",title=" + title);
			sb.append(",budget=" + String.valueOf(budget));
			sb.append(",revenue=" + String.valueOf(revenue));
			sb.append(",date=" + String.valueOf(date));
			sb.append("]");

			return sb.toString();
		}

		/**
		 * Compare keys
		 */
		public int compareTo(row12Struct other) {

			int returnValue = -1;

			returnValue = checkNullsAndCompare(this.id, other.id);
			if (returnValue != 0) {
				return returnValue;
			}

			return returnValue;
		}

		private int checkNullsAndCompare(Object object1, Object object2) {
			int returnValue = 0;
			if (object1 instanceof Comparable && object2 instanceof Comparable) {
				returnValue = ((Comparable) object1).compareTo(object2);
			} else if (object1 != null && object2 != null) {
				returnValue = compareStrings(object1.toString(), object2.toString());
			} else if (object1 == null && object2 != null) {
				returnValue = 1;
			} else if (object1 != null && object2 == null) {
				returnValue = -1;
			} else {
				returnValue = 0;
			}

			return returnValue;
		}

		private int compareStrings(String string1, String string2) {
			return string1.compareTo(string2);
		}

	}

	public static class OnRowsEndStructtSortRow_2
			implements routines.system.IPersistableRow<OnRowsEndStructtSortRow_2> {
		final static byte[] commonByteArrayLock_MYFIRSTJOB_TP_MAJ = new byte[0];
		static byte[] commonByteArray_MYFIRSTJOB_TP_MAJ = new byte[0];
		protected static final int DEFAULT_HASHCODE = 1;
		protected static final int PRIME = 31;
		protected int hashCode = DEFAULT_HASHCODE;
		public boolean hashCodeDirty = true;

		public String loopKey;

		public Integer id;

		public Integer getId() {
			return this.id;
		}

		public String title;

		public String getTitle() {
			return this.title;
		}

		public Integer budget;

		public Integer getBudget() {
			return this.budget;
		}

		public Long revenue;

		public Long getRevenue() {
			return this.revenue;
		}

		public java.util.Date date;

		public java.util.Date getDate() {
			return this.date;
		}

		@Override
		public int hashCode() {
			if (this.hashCodeDirty) {
				final int prime = PRIME;
				int result = DEFAULT_HASHCODE;

				result = prime * result + ((this.id == null) ? 0 : this.id.hashCode());

				this.hashCode = result;
				this.hashCodeDirty = false;
			}
			return this.hashCode;
		}

		@Override
		public boolean equals(Object obj) {
			if (this == obj)
				return true;
			if (obj == null)
				return false;
			if (getClass() != obj.getClass())
				return false;
			final OnRowsEndStructtSortRow_2 other = (OnRowsEndStructtSortRow_2) obj;

			if (this.id == null) {
				if (other.id != null)
					return false;

			} else if (!this.id.equals(other.id))

				return false;

			return true;
		}

		public void copyDataTo(OnRowsEndStructtSortRow_2 other) {

			other.id = this.id;
			other.title = this.title;
			other.budget = this.budget;
			other.revenue = this.revenue;
			other.date = this.date;

		}

		public void copyKeysDataTo(OnRowsEndStructtSortRow_2 other) {

			other.id = this.id;

		}

		private Integer readInteger(ObjectInputStream dis) throws IOException {
			Integer intReturn;
			int length = 0;
			length = dis.readByte();
			if (length == -1) {
				intReturn = null;
			} else {
				intReturn = dis.readInt();
			}
			return intReturn;
		}

		private Integer readInteger(org.jboss.marshalling.Unmarshaller dis) throws IOException {
			Integer intReturn;
			int length = 0;
			length = dis.readByte();
			if (length == -1) {
				intReturn = null;
			} else {
				intReturn = dis.readInt();
			}
			return intReturn;
		}

		private void writeInteger(Integer intNum, ObjectOutputStream dos) throws IOException {
			if (intNum == null) {
				dos.writeByte(-1);
			} else {
				dos.writeByte(0);
				dos.writeInt(intNum);
			}
		}

		private void writeInteger(Integer intNum, org.jboss.marshalling.Marshaller marshaller) throws IOException {
			if (intNum == null) {
				marshaller.writeByte(-1);
			} else {
				marshaller.writeByte(0);
				marshaller.writeInt(intNum);
			}
		}

		private String readString(ObjectInputStream dis) throws IOException {
			String strReturn = null;
			int length = 0;
			length = dis.readInt();
			if (length == -1) {
				strReturn = null;
			} else {
				if (length > commonByteArray_MYFIRSTJOB_TP_MAJ.length) {
					if (length < 1024 && commonByteArray_MYFIRSTJOB_TP_MAJ.length == 0) {
						commonByteArray_MYFIRSTJOB_TP_MAJ = new byte[1024];
					} else {
						commonByteArray_MYFIRSTJOB_TP_MAJ = new byte[2 * length];
					}
				}
				dis.readFully(commonByteArray_MYFIRSTJOB_TP_MAJ, 0, length);
				strReturn = new String(commonByteArray_MYFIRSTJOB_TP_MAJ, 0, length, utf8Charset);
			}
			return strReturn;
		}

		private String readString(org.jboss.marshalling.Unmarshaller unmarshaller) throws IOException {
			String strReturn = null;
			int length = 0;
			length = unmarshaller.readInt();
			if (length == -1) {
				strReturn = null;
			} else {
				if (length > commonByteArray_MYFIRSTJOB_TP_MAJ.length) {
					if (length < 1024 && commonByteArray_MYFIRSTJOB_TP_MAJ.length == 0) {
						commonByteArray_MYFIRSTJOB_TP_MAJ = new byte[1024];
					} else {
						commonByteArray_MYFIRSTJOB_TP_MAJ = new byte[2 * length];
					}
				}
				unmarshaller.readFully(commonByteArray_MYFIRSTJOB_TP_MAJ, 0, length);
				strReturn = new String(commonByteArray_MYFIRSTJOB_TP_MAJ, 0, length, utf8Charset);
			}
			return strReturn;
		}

		private void writeString(String str, ObjectOutputStream dos) throws IOException {
			if (str == null) {
				dos.writeInt(-1);
			} else {
				byte[] byteArray = str.getBytes(utf8Charset);
				dos.writeInt(byteArray.length);
				dos.write(byteArray);
			}
		}

		private void writeString(String str, org.jboss.marshalling.Marshaller marshaller) throws IOException {
			if (str == null) {
				marshaller.writeInt(-1);
			} else {
				byte[] byteArray = str.getBytes(utf8Charset);
				marshaller.writeInt(byteArray.length);
				marshaller.write(byteArray);
			}
		}

		private java.util.Date readDate(ObjectInputStream dis) throws IOException {
			java.util.Date dateReturn = null;
			int length = 0;
			length = dis.readByte();
			if (length == -1) {
				dateReturn = null;
			} else {
				dateReturn = new Date(dis.readLong());
			}
			return dateReturn;
		}

		private java.util.Date readDate(org.jboss.marshalling.Unmarshaller unmarshaller) throws IOException {
			java.util.Date dateReturn = null;
			int length = 0;
			length = unmarshaller.readByte();
			if (length == -1) {
				dateReturn = null;
			} else {
				dateReturn = new Date(unmarshaller.readLong());
			}
			return dateReturn;
		}

		private void writeDate(java.util.Date date1, ObjectOutputStream dos) throws IOException {
			if (date1 == null) {
				dos.writeByte(-1);
			} else {
				dos.writeByte(0);
				dos.writeLong(date1.getTime());
			}
		}

		private void writeDate(java.util.Date date1, org.jboss.marshalling.Marshaller marshaller) throws IOException {
			if (date1 == null) {
				marshaller.writeByte(-1);
			} else {
				marshaller.writeByte(0);
				marshaller.writeLong(date1.getTime());
			}
		}

		public void readData(ObjectInputStream dis) {

			synchronized (commonByteArrayLock_MYFIRSTJOB_TP_MAJ) {

				try {

					int length = 0;

					this.id = readInteger(dis);

					this.title = readString(dis);

					this.budget = readInteger(dis);

					length = dis.readByte();
					if (length == -1) {
						this.revenue = null;
					} else {
						this.revenue = dis.readLong();
					}

					this.date = readDate(dis);

				} catch (IOException e) {
					throw new RuntimeException(e);

				}

			}

		}

		public void readData(org.jboss.marshalling.Unmarshaller dis) {

			synchronized (commonByteArrayLock_MYFIRSTJOB_TP_MAJ) {

				try {

					int length = 0;

					this.id = readInteger(dis);

					this.title = readString(dis);

					this.budget = readInteger(dis);

					length = dis.readByte();
					if (length == -1) {
						this.revenue = null;
					} else {
						this.revenue = dis.readLong();
					}

					this.date = readDate(dis);

				} catch (IOException e) {
					throw new RuntimeException(e);

				}

			}

		}

		public void writeData(ObjectOutputStream dos) {
			try {

				// Integer

				writeInteger(this.id, dos);

				// String

				writeString(this.title, dos);

				// Integer

				writeInteger(this.budget, dos);

				// Long

				if (this.revenue == null) {
					dos.writeByte(-1);
				} else {
					dos.writeByte(0);
					dos.writeLong(this.revenue);
				}

				// java.util.Date

				writeDate(this.date, dos);

			} catch (IOException e) {
				throw new RuntimeException(e);
			}

		}

		public void writeData(org.jboss.marshalling.Marshaller dos) {
			try {

				// Integer

				writeInteger(this.id, dos);

				// String

				writeString(this.title, dos);

				// Integer

				writeInteger(this.budget, dos);

				// Long

				if (this.revenue == null) {
					dos.writeByte(-1);
				} else {
					dos.writeByte(0);
					dos.writeLong(this.revenue);
				}

				// java.util.Date

				writeDate(this.date, dos);

			} catch (IOException e) {
				throw new RuntimeException(e);
			}

		}

		public String toString() {

			StringBuilder sb = new StringBuilder();
			sb.append(super.toString());
			sb.append("[");
			sb.append("id=" + String.valueOf(id));
			sb.append(",title=" + title);
			sb.append(",budget=" + String.valueOf(budget));
			sb.append(",revenue=" + String.valueOf(revenue));
			sb.append(",date=" + String.valueOf(date));
			sb.append("]");

			return sb.toString();
		}

		/**
		 * Compare keys
		 */
		public int compareTo(OnRowsEndStructtSortRow_2 other) {

			int returnValue = -1;

			returnValue = checkNullsAndCompare(this.id, other.id);
			if (returnValue != 0) {
				return returnValue;
			}

			return returnValue;
		}

		private int checkNullsAndCompare(Object object1, Object object2) {
			int returnValue = 0;
			if (object1 instanceof Comparable && object2 instanceof Comparable) {
				returnValue = ((Comparable) object1).compareTo(object2);
			} else if (object1 != null && object2 != null) {
				returnValue = compareStrings(object1.toString(), object2.toString());
			} else if (object1 == null && object2 != null) {
				returnValue = 1;
			} else if (object1 != null && object2 == null) {
				returnValue = -1;
			} else {
				returnValue = 0;
			}

			return returnValue;
		}

		private int compareStrings(String string1, String string2) {
			return string1.compareTo(string2);
		}

	}

	public static class row11Struct implements routines.system.IPersistableRow<row11Struct> {
		final static byte[] commonByteArrayLock_MYFIRSTJOB_TP_MAJ = new byte[0];
		static byte[] commonByteArray_MYFIRSTJOB_TP_MAJ = new byte[0];
		protected static final int DEFAULT_HASHCODE = 1;
		protected static final int PRIME = 31;
		protected int hashCode = DEFAULT_HASHCODE;
		public boolean hashCodeDirty = true;

		public String loopKey;

		public Integer id;

		public Integer getId() {
			return this.id;
		}

		public String title;

		public String getTitle() {
			return this.title;
		}

		public Integer budget;

		public Integer getBudget() {
			return this.budget;
		}

		public Long revenue;

		public Long getRevenue() {
			return this.revenue;
		}

		public java.util.Date date;

		public java.util.Date getDate() {
			return this.date;
		}

		@Override
		public int hashCode() {
			if (this.hashCodeDirty) {
				final int prime = PRIME;
				int result = DEFAULT_HASHCODE;

				result = prime * result + ((this.id == null) ? 0 : this.id.hashCode());

				this.hashCode = result;
				this.hashCodeDirty = false;
			}
			return this.hashCode;
		}

		@Override
		public boolean equals(Object obj) {
			if (this == obj)
				return true;
			if (obj == null)
				return false;
			if (getClass() != obj.getClass())
				return false;
			final row11Struct other = (row11Struct) obj;

			if (this.id == null) {
				if (other.id != null)
					return false;

			} else if (!this.id.equals(other.id))

				return false;

			return true;
		}

		public void copyDataTo(row11Struct other) {

			other.id = this.id;
			other.title = this.title;
			other.budget = this.budget;
			other.revenue = this.revenue;
			other.date = this.date;

		}

		public void copyKeysDataTo(row11Struct other) {

			other.id = this.id;

		}

		private Integer readInteger(ObjectInputStream dis) throws IOException {
			Integer intReturn;
			int length = 0;
			length = dis.readByte();
			if (length == -1) {
				intReturn = null;
			} else {
				intReturn = dis.readInt();
			}
			return intReturn;
		}

		private Integer readInteger(org.jboss.marshalling.Unmarshaller dis) throws IOException {
			Integer intReturn;
			int length = 0;
			length = dis.readByte();
			if (length == -1) {
				intReturn = null;
			} else {
				intReturn = dis.readInt();
			}
			return intReturn;
		}

		private void writeInteger(Integer intNum, ObjectOutputStream dos) throws IOException {
			if (intNum == null) {
				dos.writeByte(-1);
			} else {
				dos.writeByte(0);
				dos.writeInt(intNum);
			}
		}

		private void writeInteger(Integer intNum, org.jboss.marshalling.Marshaller marshaller) throws IOException {
			if (intNum == null) {
				marshaller.writeByte(-1);
			} else {
				marshaller.writeByte(0);
				marshaller.writeInt(intNum);
			}
		}

		private String readString(ObjectInputStream dis) throws IOException {
			String strReturn = null;
			int length = 0;
			length = dis.readInt();
			if (length == -1) {
				strReturn = null;
			} else {
				if (length > commonByteArray_MYFIRSTJOB_TP_MAJ.length) {
					if (length < 1024 && commonByteArray_MYFIRSTJOB_TP_MAJ.length == 0) {
						commonByteArray_MYFIRSTJOB_TP_MAJ = new byte[1024];
					} else {
						commonByteArray_MYFIRSTJOB_TP_MAJ = new byte[2 * length];
					}
				}
				dis.readFully(commonByteArray_MYFIRSTJOB_TP_MAJ, 0, length);
				strReturn = new String(commonByteArray_MYFIRSTJOB_TP_MAJ, 0, length, utf8Charset);
			}
			return strReturn;
		}

		private String readString(org.jboss.marshalling.Unmarshaller unmarshaller) throws IOException {
			String strReturn = null;
			int length = 0;
			length = unmarshaller.readInt();
			if (length == -1) {
				strReturn = null;
			} else {
				if (length > commonByteArray_MYFIRSTJOB_TP_MAJ.length) {
					if (length < 1024 && commonByteArray_MYFIRSTJOB_TP_MAJ.length == 0) {
						commonByteArray_MYFIRSTJOB_TP_MAJ = new byte[1024];
					} else {
						commonByteArray_MYFIRSTJOB_TP_MAJ = new byte[2 * length];
					}
				}
				unmarshaller.readFully(commonByteArray_MYFIRSTJOB_TP_MAJ, 0, length);
				strReturn = new String(commonByteArray_MYFIRSTJOB_TP_MAJ, 0, length, utf8Charset);
			}
			return strReturn;
		}

		private void writeString(String str, ObjectOutputStream dos) throws IOException {
			if (str == null) {
				dos.writeInt(-1);
			} else {
				byte[] byteArray = str.getBytes(utf8Charset);
				dos.writeInt(byteArray.length);
				dos.write(byteArray);
			}
		}

		private void writeString(String str, org.jboss.marshalling.Marshaller marshaller) throws IOException {
			if (str == null) {
				marshaller.writeInt(-1);
			} else {
				byte[] byteArray = str.getBytes(utf8Charset);
				marshaller.writeInt(byteArray.length);
				marshaller.write(byteArray);
			}
		}

		private java.util.Date readDate(ObjectInputStream dis) throws IOException {
			java.util.Date dateReturn = null;
			int length = 0;
			length = dis.readByte();
			if (length == -1) {
				dateReturn = null;
			} else {
				dateReturn = new Date(dis.readLong());
			}
			return dateReturn;
		}

		private java.util.Date readDate(org.jboss.marshalling.Unmarshaller unmarshaller) throws IOException {
			java.util.Date dateReturn = null;
			int length = 0;
			length = unmarshaller.readByte();
			if (length == -1) {
				dateReturn = null;
			} else {
				dateReturn = new Date(unmarshaller.readLong());
			}
			return dateReturn;
		}

		private void writeDate(java.util.Date date1, ObjectOutputStream dos) throws IOException {
			if (date1 == null) {
				dos.writeByte(-1);
			} else {
				dos.writeByte(0);
				dos.writeLong(date1.getTime());
			}
		}

		private void writeDate(java.util.Date date1, org.jboss.marshalling.Marshaller marshaller) throws IOException {
			if (date1 == null) {
				marshaller.writeByte(-1);
			} else {
				marshaller.writeByte(0);
				marshaller.writeLong(date1.getTime());
			}
		}

		public void readData(ObjectInputStream dis) {

			synchronized (commonByteArrayLock_MYFIRSTJOB_TP_MAJ) {

				try {

					int length = 0;

					this.id = readInteger(dis);

					this.title = readString(dis);

					this.budget = readInteger(dis);

					length = dis.readByte();
					if (length == -1) {
						this.revenue = null;
					} else {
						this.revenue = dis.readLong();
					}

					this.date = readDate(dis);

				} catch (IOException e) {
					throw new RuntimeException(e);

				}

			}

		}

		public void readData(org.jboss.marshalling.Unmarshaller dis) {

			synchronized (commonByteArrayLock_MYFIRSTJOB_TP_MAJ) {

				try {

					int length = 0;

					this.id = readInteger(dis);

					this.title = readString(dis);

					this.budget = readInteger(dis);

					length = dis.readByte();
					if (length == -1) {
						this.revenue = null;
					} else {
						this.revenue = dis.readLong();
					}

					this.date = readDate(dis);

				} catch (IOException e) {
					throw new RuntimeException(e);

				}

			}

		}

		public void writeData(ObjectOutputStream dos) {
			try {

				// Integer

				writeInteger(this.id, dos);

				// String

				writeString(this.title, dos);

				// Integer

				writeInteger(this.budget, dos);

				// Long

				if (this.revenue == null) {
					dos.writeByte(-1);
				} else {
					dos.writeByte(0);
					dos.writeLong(this.revenue);
				}

				// java.util.Date

				writeDate(this.date, dos);

			} catch (IOException e) {
				throw new RuntimeException(e);
			}

		}

		public void writeData(org.jboss.marshalling.Marshaller dos) {
			try {

				// Integer

				writeInteger(this.id, dos);

				// String

				writeString(this.title, dos);

				// Integer

				writeInteger(this.budget, dos);

				// Long

				if (this.revenue == null) {
					dos.writeByte(-1);
				} else {
					dos.writeByte(0);
					dos.writeLong(this.revenue);
				}

				// java.util.Date

				writeDate(this.date, dos);

			} catch (IOException e) {
				throw new RuntimeException(e);
			}

		}

		public String toString() {

			StringBuilder sb = new StringBuilder();
			sb.append(super.toString());
			sb.append("[");
			sb.append("id=" + String.valueOf(id));
			sb.append(",title=" + title);
			sb.append(",budget=" + String.valueOf(budget));
			sb.append(",revenue=" + String.valueOf(revenue));
			sb.append(",date=" + String.valueOf(date));
			sb.append("]");

			return sb.toString();
		}

		/**
		 * Compare keys
		 */
		public int compareTo(row11Struct other) {

			int returnValue = -1;

			returnValue = checkNullsAndCompare(this.id, other.id);
			if (returnValue != 0) {
				return returnValue;
			}

			return returnValue;
		}

		private int checkNullsAndCompare(Object object1, Object object2) {
			int returnValue = 0;
			if (object1 instanceof Comparable && object2 instanceof Comparable) {
				returnValue = ((Comparable) object1).compareTo(object2);
			} else if (object1 != null && object2 != null) {
				returnValue = compareStrings(object1.toString(), object2.toString());
			} else if (object1 == null && object2 != null) {
				returnValue = 1;
			} else if (object1 != null && object2 == null) {
				returnValue = -1;
			} else {
				returnValue = 0;
			}

			return returnValue;
		}

		private int compareStrings(String string1, String string2) {
			return string1.compareTo(string2);
		}

	}

	public static class row10Struct implements routines.system.IPersistableRow<row10Struct> {
		final static byte[] commonByteArrayLock_MYFIRSTJOB_TP_MAJ = new byte[0];
		static byte[] commonByteArray_MYFIRSTJOB_TP_MAJ = new byte[0];
		protected static final int DEFAULT_HASHCODE = 1;
		protected static final int PRIME = 31;
		protected int hashCode = DEFAULT_HASHCODE;
		public boolean hashCodeDirty = true;

		public String loopKey;

		public Integer id;

		public Integer getId() {
			return this.id;
		}

		public String title;

		public String getTitle() {
			return this.title;
		}

		public Float popularity;

		public Float getPopularity() {
			return this.popularity;
		}

		public Integer budget;

		public Integer getBudget() {
			return this.budget;
		}

		public Long revenue;

		public Long getRevenue() {
			return this.revenue;
		}

		@Override
		public int hashCode() {
			if (this.hashCodeDirty) {
				final int prime = PRIME;
				int result = DEFAULT_HASHCODE;

				result = prime * result + ((this.id == null) ? 0 : this.id.hashCode());

				this.hashCode = result;
				this.hashCodeDirty = false;
			}
			return this.hashCode;
		}

		@Override
		public boolean equals(Object obj) {
			if (this == obj)
				return true;
			if (obj == null)
				return false;
			if (getClass() != obj.getClass())
				return false;
			final row10Struct other = (row10Struct) obj;

			if (this.id == null) {
				if (other.id != null)
					return false;

			} else if (!this.id.equals(other.id))

				return false;

			return true;
		}

		public void copyDataTo(row10Struct other) {

			other.id = this.id;
			other.title = this.title;
			other.popularity = this.popularity;
			other.budget = this.budget;
			other.revenue = this.revenue;

		}

		public void copyKeysDataTo(row10Struct other) {

			other.id = this.id;

		}

		private Integer readInteger(ObjectInputStream dis) throws IOException {
			Integer intReturn;
			int length = 0;
			length = dis.readByte();
			if (length == -1) {
				intReturn = null;
			} else {
				intReturn = dis.readInt();
			}
			return intReturn;
		}

		private Integer readInteger(org.jboss.marshalling.Unmarshaller dis) throws IOException {
			Integer intReturn;
			int length = 0;
			length = dis.readByte();
			if (length == -1) {
				intReturn = null;
			} else {
				intReturn = dis.readInt();
			}
			return intReturn;
		}

		private void writeInteger(Integer intNum, ObjectOutputStream dos) throws IOException {
			if (intNum == null) {
				dos.writeByte(-1);
			} else {
				dos.writeByte(0);
				dos.writeInt(intNum);
			}
		}

		private void writeInteger(Integer intNum, org.jboss.marshalling.Marshaller marshaller) throws IOException {
			if (intNum == null) {
				marshaller.writeByte(-1);
			} else {
				marshaller.writeByte(0);
				marshaller.writeInt(intNum);
			}
		}

		private String readString(ObjectInputStream dis) throws IOException {
			String strReturn = null;
			int length = 0;
			length = dis.readInt();
			if (length == -1) {
				strReturn = null;
			} else {
				if (length > commonByteArray_MYFIRSTJOB_TP_MAJ.length) {
					if (length < 1024 && commonByteArray_MYFIRSTJOB_TP_MAJ.length == 0) {
						commonByteArray_MYFIRSTJOB_TP_MAJ = new byte[1024];
					} else {
						commonByteArray_MYFIRSTJOB_TP_MAJ = new byte[2 * length];
					}
				}
				dis.readFully(commonByteArray_MYFIRSTJOB_TP_MAJ, 0, length);
				strReturn = new String(commonByteArray_MYFIRSTJOB_TP_MAJ, 0, length, utf8Charset);
			}
			return strReturn;
		}

		private String readString(org.jboss.marshalling.Unmarshaller unmarshaller) throws IOException {
			String strReturn = null;
			int length = 0;
			length = unmarshaller.readInt();
			if (length == -1) {
				strReturn = null;
			} else {
				if (length > commonByteArray_MYFIRSTJOB_TP_MAJ.length) {
					if (length < 1024 && commonByteArray_MYFIRSTJOB_TP_MAJ.length == 0) {
						commonByteArray_MYFIRSTJOB_TP_MAJ = new byte[1024];
					} else {
						commonByteArray_MYFIRSTJOB_TP_MAJ = new byte[2 * length];
					}
				}
				unmarshaller.readFully(commonByteArray_MYFIRSTJOB_TP_MAJ, 0, length);
				strReturn = new String(commonByteArray_MYFIRSTJOB_TP_MAJ, 0, length, utf8Charset);
			}
			return strReturn;
		}

		private void writeString(String str, ObjectOutputStream dos) throws IOException {
			if (str == null) {
				dos.writeInt(-1);
			} else {
				byte[] byteArray = str.getBytes(utf8Charset);
				dos.writeInt(byteArray.length);
				dos.write(byteArray);
			}
		}

		private void writeString(String str, org.jboss.marshalling.Marshaller marshaller) throws IOException {
			if (str == null) {
				marshaller.writeInt(-1);
			} else {
				byte[] byteArray = str.getBytes(utf8Charset);
				marshaller.writeInt(byteArray.length);
				marshaller.write(byteArray);
			}
		}

		public void readData(ObjectInputStream dis) {

			synchronized (commonByteArrayLock_MYFIRSTJOB_TP_MAJ) {

				try {

					int length = 0;

					this.id = readInteger(dis);

					this.title = readString(dis);

					length = dis.readByte();
					if (length == -1) {
						this.popularity = null;
					} else {
						this.popularity = dis.readFloat();
					}

					this.budget = readInteger(dis);

					length = dis.readByte();
					if (length == -1) {
						this.revenue = null;
					} else {
						this.revenue = dis.readLong();
					}

				} catch (IOException e) {
					throw new RuntimeException(e);

				}

			}

		}

		public void readData(org.jboss.marshalling.Unmarshaller dis) {

			synchronized (commonByteArrayLock_MYFIRSTJOB_TP_MAJ) {

				try {

					int length = 0;

					this.id = readInteger(dis);

					this.title = readString(dis);

					length = dis.readByte();
					if (length == -1) {
						this.popularity = null;
					} else {
						this.popularity = dis.readFloat();
					}

					this.budget = readInteger(dis);

					length = dis.readByte();
					if (length == -1) {
						this.revenue = null;
					} else {
						this.revenue = dis.readLong();
					}

				} catch (IOException e) {
					throw new RuntimeException(e);

				}

			}

		}

		public void writeData(ObjectOutputStream dos) {
			try {

				// Integer

				writeInteger(this.id, dos);

				// String

				writeString(this.title, dos);

				// Float

				if (this.popularity == null) {
					dos.writeByte(-1);
				} else {
					dos.writeByte(0);
					dos.writeFloat(this.popularity);
				}

				// Integer

				writeInteger(this.budget, dos);

				// Long

				if (this.revenue == null) {
					dos.writeByte(-1);
				} else {
					dos.writeByte(0);
					dos.writeLong(this.revenue);
				}

			} catch (IOException e) {
				throw new RuntimeException(e);
			}

		}

		public void writeData(org.jboss.marshalling.Marshaller dos) {
			try {

				// Integer

				writeInteger(this.id, dos);

				// String

				writeString(this.title, dos);

				// Float

				if (this.popularity == null) {
					dos.writeByte(-1);
				} else {
					dos.writeByte(0);
					dos.writeFloat(this.popularity);
				}

				// Integer

				writeInteger(this.budget, dos);

				// Long

				if (this.revenue == null) {
					dos.writeByte(-1);
				} else {
					dos.writeByte(0);
					dos.writeLong(this.revenue);
				}

			} catch (IOException e) {
				throw new RuntimeException(e);
			}

		}

		public String toString() {

			StringBuilder sb = new StringBuilder();
			sb.append(super.toString());
			sb.append("[");
			sb.append("id=" + String.valueOf(id));
			sb.append(",title=" + title);
			sb.append(",popularity=" + String.valueOf(popularity));
			sb.append(",budget=" + String.valueOf(budget));
			sb.append(",revenue=" + String.valueOf(revenue));
			sb.append("]");

			return sb.toString();
		}

		/**
		 * Compare keys
		 */
		public int compareTo(row10Struct other) {

			int returnValue = -1;

			returnValue = checkNullsAndCompare(this.id, other.id);
			if (returnValue != 0) {
				return returnValue;
			}

			return returnValue;
		}

		private int checkNullsAndCompare(Object object1, Object object2) {
			int returnValue = 0;
			if (object1 instanceof Comparable && object2 instanceof Comparable) {
				returnValue = ((Comparable) object1).compareTo(object2);
			} else if (object1 != null && object2 != null) {
				returnValue = compareStrings(object1.toString(), object2.toString());
			} else if (object1 == null && object2 != null) {
				returnValue = 1;
			} else if (object1 != null && object2 == null) {
				returnValue = -1;
			} else {
				returnValue = 0;
			}

			return returnValue;
		}

		private int compareStrings(String string1, String string2) {
			return string1.compareTo(string2);
		}

	}

	public static class OnRowsEndStructtSortRow_1
			implements routines.system.IPersistableRow<OnRowsEndStructtSortRow_1> {
		final static byte[] commonByteArrayLock_MYFIRSTJOB_TP_MAJ = new byte[0];
		static byte[] commonByteArray_MYFIRSTJOB_TP_MAJ = new byte[0];
		protected static final int DEFAULT_HASHCODE = 1;
		protected static final int PRIME = 31;
		protected int hashCode = DEFAULT_HASHCODE;
		public boolean hashCodeDirty = true;

		public String loopKey;

		public Integer id;

		public Integer getId() {
			return this.id;
		}

		public String title;

		public String getTitle() {
			return this.title;
		}

		public Float popularity;

		public Float getPopularity() {
			return this.popularity;
		}

		public Integer budget;

		public Integer getBudget() {
			return this.budget;
		}

		public Long revenue;

		public Long getRevenue() {
			return this.revenue;
		}

		@Override
		public int hashCode() {
			if (this.hashCodeDirty) {
				final int prime = PRIME;
				int result = DEFAULT_HASHCODE;

				result = prime * result + ((this.id == null) ? 0 : this.id.hashCode());

				this.hashCode = result;
				this.hashCodeDirty = false;
			}
			return this.hashCode;
		}

		@Override
		public boolean equals(Object obj) {
			if (this == obj)
				return true;
			if (obj == null)
				return false;
			if (getClass() != obj.getClass())
				return false;
			final OnRowsEndStructtSortRow_1 other = (OnRowsEndStructtSortRow_1) obj;

			if (this.id == null) {
				if (other.id != null)
					return false;

			} else if (!this.id.equals(other.id))

				return false;

			return true;
		}

		public void copyDataTo(OnRowsEndStructtSortRow_1 other) {

			other.id = this.id;
			other.title = this.title;
			other.popularity = this.popularity;
			other.budget = this.budget;
			other.revenue = this.revenue;

		}

		public void copyKeysDataTo(OnRowsEndStructtSortRow_1 other) {

			other.id = this.id;

		}

		private Integer readInteger(ObjectInputStream dis) throws IOException {
			Integer intReturn;
			int length = 0;
			length = dis.readByte();
			if (length == -1) {
				intReturn = null;
			} else {
				intReturn = dis.readInt();
			}
			return intReturn;
		}

		private Integer readInteger(org.jboss.marshalling.Unmarshaller dis) throws IOException {
			Integer intReturn;
			int length = 0;
			length = dis.readByte();
			if (length == -1) {
				intReturn = null;
			} else {
				intReturn = dis.readInt();
			}
			return intReturn;
		}

		private void writeInteger(Integer intNum, ObjectOutputStream dos) throws IOException {
			if (intNum == null) {
				dos.writeByte(-1);
			} else {
				dos.writeByte(0);
				dos.writeInt(intNum);
			}
		}

		private void writeInteger(Integer intNum, org.jboss.marshalling.Marshaller marshaller) throws IOException {
			if (intNum == null) {
				marshaller.writeByte(-1);
			} else {
				marshaller.writeByte(0);
				marshaller.writeInt(intNum);
			}
		}

		private String readString(ObjectInputStream dis) throws IOException {
			String strReturn = null;
			int length = 0;
			length = dis.readInt();
			if (length == -1) {
				strReturn = null;
			} else {
				if (length > commonByteArray_MYFIRSTJOB_TP_MAJ.length) {
					if (length < 1024 && commonByteArray_MYFIRSTJOB_TP_MAJ.length == 0) {
						commonByteArray_MYFIRSTJOB_TP_MAJ = new byte[1024];
					} else {
						commonByteArray_MYFIRSTJOB_TP_MAJ = new byte[2 * length];
					}
				}
				dis.readFully(commonByteArray_MYFIRSTJOB_TP_MAJ, 0, length);
				strReturn = new String(commonByteArray_MYFIRSTJOB_TP_MAJ, 0, length, utf8Charset);
			}
			return strReturn;
		}

		private String readString(org.jboss.marshalling.Unmarshaller unmarshaller) throws IOException {
			String strReturn = null;
			int length = 0;
			length = unmarshaller.readInt();
			if (length == -1) {
				strReturn = null;
			} else {
				if (length > commonByteArray_MYFIRSTJOB_TP_MAJ.length) {
					if (length < 1024 && commonByteArray_MYFIRSTJOB_TP_MAJ.length == 0) {
						commonByteArray_MYFIRSTJOB_TP_MAJ = new byte[1024];
					} else {
						commonByteArray_MYFIRSTJOB_TP_MAJ = new byte[2 * length];
					}
				}
				unmarshaller.readFully(commonByteArray_MYFIRSTJOB_TP_MAJ, 0, length);
				strReturn = new String(commonByteArray_MYFIRSTJOB_TP_MAJ, 0, length, utf8Charset);
			}
			return strReturn;
		}

		private void writeString(String str, ObjectOutputStream dos) throws IOException {
			if (str == null) {
				dos.writeInt(-1);
			} else {
				byte[] byteArray = str.getBytes(utf8Charset);
				dos.writeInt(byteArray.length);
				dos.write(byteArray);
			}
		}

		private void writeString(String str, org.jboss.marshalling.Marshaller marshaller) throws IOException {
			if (str == null) {
				marshaller.writeInt(-1);
			} else {
				byte[] byteArray = str.getBytes(utf8Charset);
				marshaller.writeInt(byteArray.length);
				marshaller.write(byteArray);
			}
		}

		public void readData(ObjectInputStream dis) {

			synchronized (commonByteArrayLock_MYFIRSTJOB_TP_MAJ) {

				try {

					int length = 0;

					this.id = readInteger(dis);

					this.title = readString(dis);

					length = dis.readByte();
					if (length == -1) {
						this.popularity = null;
					} else {
						this.popularity = dis.readFloat();
					}

					this.budget = readInteger(dis);

					length = dis.readByte();
					if (length == -1) {
						this.revenue = null;
					} else {
						this.revenue = dis.readLong();
					}

				} catch (IOException e) {
					throw new RuntimeException(e);

				}

			}

		}

		public void readData(org.jboss.marshalling.Unmarshaller dis) {

			synchronized (commonByteArrayLock_MYFIRSTJOB_TP_MAJ) {

				try {

					int length = 0;

					this.id = readInteger(dis);

					this.title = readString(dis);

					length = dis.readByte();
					if (length == -1) {
						this.popularity = null;
					} else {
						this.popularity = dis.readFloat();
					}

					this.budget = readInteger(dis);

					length = dis.readByte();
					if (length == -1) {
						this.revenue = null;
					} else {
						this.revenue = dis.readLong();
					}

				} catch (IOException e) {
					throw new RuntimeException(e);

				}

			}

		}

		public void writeData(ObjectOutputStream dos) {
			try {

				// Integer

				writeInteger(this.id, dos);

				// String

				writeString(this.title, dos);

				// Float

				if (this.popularity == null) {
					dos.writeByte(-1);
				} else {
					dos.writeByte(0);
					dos.writeFloat(this.popularity);
				}

				// Integer

				writeInteger(this.budget, dos);

				// Long

				if (this.revenue == null) {
					dos.writeByte(-1);
				} else {
					dos.writeByte(0);
					dos.writeLong(this.revenue);
				}

			} catch (IOException e) {
				throw new RuntimeException(e);
			}

		}

		public void writeData(org.jboss.marshalling.Marshaller dos) {
			try {

				// Integer

				writeInteger(this.id, dos);

				// String

				writeString(this.title, dos);

				// Float

				if (this.popularity == null) {
					dos.writeByte(-1);
				} else {
					dos.writeByte(0);
					dos.writeFloat(this.popularity);
				}

				// Integer

				writeInteger(this.budget, dos);

				// Long

				if (this.revenue == null) {
					dos.writeByte(-1);
				} else {
					dos.writeByte(0);
					dos.writeLong(this.revenue);
				}

			} catch (IOException e) {
				throw new RuntimeException(e);
			}

		}

		public String toString() {

			StringBuilder sb = new StringBuilder();
			sb.append(super.toString());
			sb.append("[");
			sb.append("id=" + String.valueOf(id));
			sb.append(",title=" + title);
			sb.append(",popularity=" + String.valueOf(popularity));
			sb.append(",budget=" + String.valueOf(budget));
			sb.append(",revenue=" + String.valueOf(revenue));
			sb.append("]");

			return sb.toString();
		}

		/**
		 * Compare keys
		 */
		public int compareTo(OnRowsEndStructtSortRow_1 other) {

			int returnValue = -1;

			returnValue = checkNullsAndCompare(this.id, other.id);
			if (returnValue != 0) {
				return returnValue;
			}

			return returnValue;
		}

		private int checkNullsAndCompare(Object object1, Object object2) {
			int returnValue = 0;
			if (object1 instanceof Comparable && object2 instanceof Comparable) {
				returnValue = ((Comparable) object1).compareTo(object2);
			} else if (object1 != null && object2 != null) {
				returnValue = compareStrings(object1.toString(), object2.toString());
			} else if (object1 == null && object2 != null) {
				returnValue = 1;
			} else if (object1 != null && object2 == null) {
				returnValue = -1;
			} else {
				returnValue = 0;
			}

			return returnValue;
		}

		private int compareStrings(String string1, String string2) {
			return string1.compareTo(string2);
		}

	}

	public static class row9Struct implements routines.system.IPersistableRow<row9Struct> {
		final static byte[] commonByteArrayLock_MYFIRSTJOB_TP_MAJ = new byte[0];
		static byte[] commonByteArray_MYFIRSTJOB_TP_MAJ = new byte[0];
		protected static final int DEFAULT_HASHCODE = 1;
		protected static final int PRIME = 31;
		protected int hashCode = DEFAULT_HASHCODE;
		public boolean hashCodeDirty = true;

		public String loopKey;

		public Integer id;

		public Integer getId() {
			return this.id;
		}

		public String title;

		public String getTitle() {
			return this.title;
		}

		public Float popularity;

		public Float getPopularity() {
			return this.popularity;
		}

		public Integer budget;

		public Integer getBudget() {
			return this.budget;
		}

		public Long revenue;

		public Long getRevenue() {
			return this.revenue;
		}

		@Override
		public int hashCode() {
			if (this.hashCodeDirty) {
				final int prime = PRIME;
				int result = DEFAULT_HASHCODE;

				result = prime * result + ((this.id == null) ? 0 : this.id.hashCode());

				this.hashCode = result;
				this.hashCodeDirty = false;
			}
			return this.hashCode;
		}

		@Override
		public boolean equals(Object obj) {
			if (this == obj)
				return true;
			if (obj == null)
				return false;
			if (getClass() != obj.getClass())
				return false;
			final row9Struct other = (row9Struct) obj;

			if (this.id == null) {
				if (other.id != null)
					return false;

			} else if (!this.id.equals(other.id))

				return false;

			return true;
		}

		public void copyDataTo(row9Struct other) {

			other.id = this.id;
			other.title = this.title;
			other.popularity = this.popularity;
			other.budget = this.budget;
			other.revenue = this.revenue;

		}

		public void copyKeysDataTo(row9Struct other) {

			other.id = this.id;

		}

		private Integer readInteger(ObjectInputStream dis) throws IOException {
			Integer intReturn;
			int length = 0;
			length = dis.readByte();
			if (length == -1) {
				intReturn = null;
			} else {
				intReturn = dis.readInt();
			}
			return intReturn;
		}

		private Integer readInteger(org.jboss.marshalling.Unmarshaller dis) throws IOException {
			Integer intReturn;
			int length = 0;
			length = dis.readByte();
			if (length == -1) {
				intReturn = null;
			} else {
				intReturn = dis.readInt();
			}
			return intReturn;
		}

		private void writeInteger(Integer intNum, ObjectOutputStream dos) throws IOException {
			if (intNum == null) {
				dos.writeByte(-1);
			} else {
				dos.writeByte(0);
				dos.writeInt(intNum);
			}
		}

		private void writeInteger(Integer intNum, org.jboss.marshalling.Marshaller marshaller) throws IOException {
			if (intNum == null) {
				marshaller.writeByte(-1);
			} else {
				marshaller.writeByte(0);
				marshaller.writeInt(intNum);
			}
		}

		private String readString(ObjectInputStream dis) throws IOException {
			String strReturn = null;
			int length = 0;
			length = dis.readInt();
			if (length == -1) {
				strReturn = null;
			} else {
				if (length > commonByteArray_MYFIRSTJOB_TP_MAJ.length) {
					if (length < 1024 && commonByteArray_MYFIRSTJOB_TP_MAJ.length == 0) {
						commonByteArray_MYFIRSTJOB_TP_MAJ = new byte[1024];
					} else {
						commonByteArray_MYFIRSTJOB_TP_MAJ = new byte[2 * length];
					}
				}
				dis.readFully(commonByteArray_MYFIRSTJOB_TP_MAJ, 0, length);
				strReturn = new String(commonByteArray_MYFIRSTJOB_TP_MAJ, 0, length, utf8Charset);
			}
			return strReturn;
		}

		private String readString(org.jboss.marshalling.Unmarshaller unmarshaller) throws IOException {
			String strReturn = null;
			int length = 0;
			length = unmarshaller.readInt();
			if (length == -1) {
				strReturn = null;
			} else {
				if (length > commonByteArray_MYFIRSTJOB_TP_MAJ.length) {
					if (length < 1024 && commonByteArray_MYFIRSTJOB_TP_MAJ.length == 0) {
						commonByteArray_MYFIRSTJOB_TP_MAJ = new byte[1024];
					} else {
						commonByteArray_MYFIRSTJOB_TP_MAJ = new byte[2 * length];
					}
				}
				unmarshaller.readFully(commonByteArray_MYFIRSTJOB_TP_MAJ, 0, length);
				strReturn = new String(commonByteArray_MYFIRSTJOB_TP_MAJ, 0, length, utf8Charset);
			}
			return strReturn;
		}

		private void writeString(String str, ObjectOutputStream dos) throws IOException {
			if (str == null) {
				dos.writeInt(-1);
			} else {
				byte[] byteArray = str.getBytes(utf8Charset);
				dos.writeInt(byteArray.length);
				dos.write(byteArray);
			}
		}

		private void writeString(String str, org.jboss.marshalling.Marshaller marshaller) throws IOException {
			if (str == null) {
				marshaller.writeInt(-1);
			} else {
				byte[] byteArray = str.getBytes(utf8Charset);
				marshaller.writeInt(byteArray.length);
				marshaller.write(byteArray);
			}
		}

		public void readData(ObjectInputStream dis) {

			synchronized (commonByteArrayLock_MYFIRSTJOB_TP_MAJ) {

				try {

					int length = 0;

					this.id = readInteger(dis);

					this.title = readString(dis);

					length = dis.readByte();
					if (length == -1) {
						this.popularity = null;
					} else {
						this.popularity = dis.readFloat();
					}

					this.budget = readInteger(dis);

					length = dis.readByte();
					if (length == -1) {
						this.revenue = null;
					} else {
						this.revenue = dis.readLong();
					}

				} catch (IOException e) {
					throw new RuntimeException(e);

				}

			}

		}

		public void readData(org.jboss.marshalling.Unmarshaller dis) {

			synchronized (commonByteArrayLock_MYFIRSTJOB_TP_MAJ) {

				try {

					int length = 0;

					this.id = readInteger(dis);

					this.title = readString(dis);

					length = dis.readByte();
					if (length == -1) {
						this.popularity = null;
					} else {
						this.popularity = dis.readFloat();
					}

					this.budget = readInteger(dis);

					length = dis.readByte();
					if (length == -1) {
						this.revenue = null;
					} else {
						this.revenue = dis.readLong();
					}

				} catch (IOException e) {
					throw new RuntimeException(e);

				}

			}

		}

		public void writeData(ObjectOutputStream dos) {
			try {

				// Integer

				writeInteger(this.id, dos);

				// String

				writeString(this.title, dos);

				// Float

				if (this.popularity == null) {
					dos.writeByte(-1);
				} else {
					dos.writeByte(0);
					dos.writeFloat(this.popularity);
				}

				// Integer

				writeInteger(this.budget, dos);

				// Long

				if (this.revenue == null) {
					dos.writeByte(-1);
				} else {
					dos.writeByte(0);
					dos.writeLong(this.revenue);
				}

			} catch (IOException e) {
				throw new RuntimeException(e);
			}

		}

		public void writeData(org.jboss.marshalling.Marshaller dos) {
			try {

				// Integer

				writeInteger(this.id, dos);

				// String

				writeString(this.title, dos);

				// Float

				if (this.popularity == null) {
					dos.writeByte(-1);
				} else {
					dos.writeByte(0);
					dos.writeFloat(this.popularity);
				}

				// Integer

				writeInteger(this.budget, dos);

				// Long

				if (this.revenue == null) {
					dos.writeByte(-1);
				} else {
					dos.writeByte(0);
					dos.writeLong(this.revenue);
				}

			} catch (IOException e) {
				throw new RuntimeException(e);
			}

		}

		public String toString() {

			StringBuilder sb = new StringBuilder();
			sb.append(super.toString());
			sb.append("[");
			sb.append("id=" + String.valueOf(id));
			sb.append(",title=" + title);
			sb.append(",popularity=" + String.valueOf(popularity));
			sb.append(",budget=" + String.valueOf(budget));
			sb.append(",revenue=" + String.valueOf(revenue));
			sb.append("]");

			return sb.toString();
		}

		/**
		 * Compare keys
		 */
		public int compareTo(row9Struct other) {

			int returnValue = -1;

			returnValue = checkNullsAndCompare(this.id, other.id);
			if (returnValue != 0) {
				return returnValue;
			}

			return returnValue;
		}

		private int checkNullsAndCompare(Object object1, Object object2) {
			int returnValue = 0;
			if (object1 instanceof Comparable && object2 instanceof Comparable) {
				returnValue = ((Comparable) object1).compareTo(object2);
			} else if (object1 != null && object2 != null) {
				returnValue = compareStrings(object1.toString(), object2.toString());
			} else if (object1 == null && object2 != null) {
				returnValue = 1;
			} else if (object1 != null && object2 == null) {
				returnValue = -1;
			} else {
				returnValue = 0;
			}

			return returnValue;
		}

		private int compareStrings(String string1, String string2) {
			return string1.compareTo(string2);
		}

	}

	public static class Joint_rev_budg_opStruct implements routines.system.IPersistableRow<Joint_rev_budg_opStruct> {
		final static byte[] commonByteArrayLock_MYFIRSTJOB_TP_MAJ = new byte[0];
		static byte[] commonByteArray_MYFIRSTJOB_TP_MAJ = new byte[0];
		protected static final int DEFAULT_HASHCODE = 1;
		protected static final int PRIME = 31;
		protected int hashCode = DEFAULT_HASHCODE;
		public boolean hashCodeDirty = true;

		public String loopKey;

		public Integer id;

		public Integer getId() {
			return this.id;
		}

		public String title;

		public String getTitle() {
			return this.title;
		}

		public Float popularity;

		public Float getPopularity() {
			return this.popularity;
		}

		public Integer budget;

		public Integer getBudget() {
			return this.budget;
		}

		public Long revenue;

		public Long getRevenue() {
			return this.revenue;
		}

		@Override
		public int hashCode() {
			if (this.hashCodeDirty) {
				final int prime = PRIME;
				int result = DEFAULT_HASHCODE;

				result = prime * result + ((this.id == null) ? 0 : this.id.hashCode());

				this.hashCode = result;
				this.hashCodeDirty = false;
			}
			return this.hashCode;
		}

		@Override
		public boolean equals(Object obj) {
			if (this == obj)
				return true;
			if (obj == null)
				return false;
			if (getClass() != obj.getClass())
				return false;
			final Joint_rev_budg_opStruct other = (Joint_rev_budg_opStruct) obj;

			if (this.id == null) {
				if (other.id != null)
					return false;

			} else if (!this.id.equals(other.id))

				return false;

			return true;
		}

		public void copyDataTo(Joint_rev_budg_opStruct other) {

			other.id = this.id;
			other.title = this.title;
			other.popularity = this.popularity;
			other.budget = this.budget;
			other.revenue = this.revenue;

		}

		public void copyKeysDataTo(Joint_rev_budg_opStruct other) {

			other.id = this.id;

		}

		private Integer readInteger(ObjectInputStream dis) throws IOException {
			Integer intReturn;
			int length = 0;
			length = dis.readByte();
			if (length == -1) {
				intReturn = null;
			} else {
				intReturn = dis.readInt();
			}
			return intReturn;
		}

		private Integer readInteger(org.jboss.marshalling.Unmarshaller dis) throws IOException {
			Integer intReturn;
			int length = 0;
			length = dis.readByte();
			if (length == -1) {
				intReturn = null;
			} else {
				intReturn = dis.readInt();
			}
			return intReturn;
		}

		private void writeInteger(Integer intNum, ObjectOutputStream dos) throws IOException {
			if (intNum == null) {
				dos.writeByte(-1);
			} else {
				dos.writeByte(0);
				dos.writeInt(intNum);
			}
		}

		private void writeInteger(Integer intNum, org.jboss.marshalling.Marshaller marshaller) throws IOException {
			if (intNum == null) {
				marshaller.writeByte(-1);
			} else {
				marshaller.writeByte(0);
				marshaller.writeInt(intNum);
			}
		}

		private String readString(ObjectInputStream dis) throws IOException {
			String strReturn = null;
			int length = 0;
			length = dis.readInt();
			if (length == -1) {
				strReturn = null;
			} else {
				if (length > commonByteArray_MYFIRSTJOB_TP_MAJ.length) {
					if (length < 1024 && commonByteArray_MYFIRSTJOB_TP_MAJ.length == 0) {
						commonByteArray_MYFIRSTJOB_TP_MAJ = new byte[1024];
					} else {
						commonByteArray_MYFIRSTJOB_TP_MAJ = new byte[2 * length];
					}
				}
				dis.readFully(commonByteArray_MYFIRSTJOB_TP_MAJ, 0, length);
				strReturn = new String(commonByteArray_MYFIRSTJOB_TP_MAJ, 0, length, utf8Charset);
			}
			return strReturn;
		}

		private String readString(org.jboss.marshalling.Unmarshaller unmarshaller) throws IOException {
			String strReturn = null;
			int length = 0;
			length = unmarshaller.readInt();
			if (length == -1) {
				strReturn = null;
			} else {
				if (length > commonByteArray_MYFIRSTJOB_TP_MAJ.length) {
					if (length < 1024 && commonByteArray_MYFIRSTJOB_TP_MAJ.length == 0) {
						commonByteArray_MYFIRSTJOB_TP_MAJ = new byte[1024];
					} else {
						commonByteArray_MYFIRSTJOB_TP_MAJ = new byte[2 * length];
					}
				}
				unmarshaller.readFully(commonByteArray_MYFIRSTJOB_TP_MAJ, 0, length);
				strReturn = new String(commonByteArray_MYFIRSTJOB_TP_MAJ, 0, length, utf8Charset);
			}
			return strReturn;
		}

		private void writeString(String str, ObjectOutputStream dos) throws IOException {
			if (str == null) {
				dos.writeInt(-1);
			} else {
				byte[] byteArray = str.getBytes(utf8Charset);
				dos.writeInt(byteArray.length);
				dos.write(byteArray);
			}
		}

		private void writeString(String str, org.jboss.marshalling.Marshaller marshaller) throws IOException {
			if (str == null) {
				marshaller.writeInt(-1);
			} else {
				byte[] byteArray = str.getBytes(utf8Charset);
				marshaller.writeInt(byteArray.length);
				marshaller.write(byteArray);
			}
		}

		public void readData(ObjectInputStream dis) {

			synchronized (commonByteArrayLock_MYFIRSTJOB_TP_MAJ) {

				try {

					int length = 0;

					this.id = readInteger(dis);

					this.title = readString(dis);

					length = dis.readByte();
					if (length == -1) {
						this.popularity = null;
					} else {
						this.popularity = dis.readFloat();
					}

					this.budget = readInteger(dis);

					length = dis.readByte();
					if (length == -1) {
						this.revenue = null;
					} else {
						this.revenue = dis.readLong();
					}

				} catch (IOException e) {
					throw new RuntimeException(e);

				}

			}

		}

		public void readData(org.jboss.marshalling.Unmarshaller dis) {

			synchronized (commonByteArrayLock_MYFIRSTJOB_TP_MAJ) {

				try {

					int length = 0;

					this.id = readInteger(dis);

					this.title = readString(dis);

					length = dis.readByte();
					if (length == -1) {
						this.popularity = null;
					} else {
						this.popularity = dis.readFloat();
					}

					this.budget = readInteger(dis);

					length = dis.readByte();
					if (length == -1) {
						this.revenue = null;
					} else {
						this.revenue = dis.readLong();
					}

				} catch (IOException e) {
					throw new RuntimeException(e);

				}

			}

		}

		public void writeData(ObjectOutputStream dos) {
			try {

				// Integer

				writeInteger(this.id, dos);

				// String

				writeString(this.title, dos);

				// Float

				if (this.popularity == null) {
					dos.writeByte(-1);
				} else {
					dos.writeByte(0);
					dos.writeFloat(this.popularity);
				}

				// Integer

				writeInteger(this.budget, dos);

				// Long

				if (this.revenue == null) {
					dos.writeByte(-1);
				} else {
					dos.writeByte(0);
					dos.writeLong(this.revenue);
				}

			} catch (IOException e) {
				throw new RuntimeException(e);
			}

		}

		public void writeData(org.jboss.marshalling.Marshaller dos) {
			try {

				// Integer

				writeInteger(this.id, dos);

				// String

				writeString(this.title, dos);

				// Float

				if (this.popularity == null) {
					dos.writeByte(-1);
				} else {
					dos.writeByte(0);
					dos.writeFloat(this.popularity);
				}

				// Integer

				writeInteger(this.budget, dos);

				// Long

				if (this.revenue == null) {
					dos.writeByte(-1);
				} else {
					dos.writeByte(0);
					dos.writeLong(this.revenue);
				}

			} catch (IOException e) {
				throw new RuntimeException(e);
			}

		}

		public String toString() {

			StringBuilder sb = new StringBuilder();
			sb.append(super.toString());
			sb.append("[");
			sb.append("id=" + String.valueOf(id));
			sb.append(",title=" + title);
			sb.append(",popularity=" + String.valueOf(popularity));
			sb.append(",budget=" + String.valueOf(budget));
			sb.append(",revenue=" + String.valueOf(revenue));
			sb.append("]");

			return sb.toString();
		}

		/**
		 * Compare keys
		 */
		public int compareTo(Joint_rev_budg_opStruct other) {

			int returnValue = -1;

			returnValue = checkNullsAndCompare(this.id, other.id);
			if (returnValue != 0) {
				return returnValue;
			}

			return returnValue;
		}

		private int checkNullsAndCompare(Object object1, Object object2) {
			int returnValue = 0;
			if (object1 instanceof Comparable && object2 instanceof Comparable) {
				returnValue = ((Comparable) object1).compareTo(object2);
			} else if (object1 != null && object2 != null) {
				returnValue = compareStrings(object1.toString(), object2.toString());
			} else if (object1 == null && object2 != null) {
				returnValue = 1;
			} else if (object1 != null && object2 == null) {
				returnValue = -1;
			} else {
				returnValue = 0;
			}

			return returnValue;
		}

		private int compareStrings(String string1, String string2) {
			return string1.compareTo(string2);
		}

	}

	public static class Joint_rev_budget_dateStruct
			implements routines.system.IPersistableRow<Joint_rev_budget_dateStruct> {
		final static byte[] commonByteArrayLock_MYFIRSTJOB_TP_MAJ = new byte[0];
		static byte[] commonByteArray_MYFIRSTJOB_TP_MAJ = new byte[0];
		protected static final int DEFAULT_HASHCODE = 1;
		protected static final int PRIME = 31;
		protected int hashCode = DEFAULT_HASHCODE;
		public boolean hashCodeDirty = true;

		public String loopKey;

		public Integer id;

		public Integer getId() {
			return this.id;
		}

		public String title;

		public String getTitle() {
			return this.title;
		}

		public Integer budget;

		public Integer getBudget() {
			return this.budget;
		}

		public Long revenue;

		public Long getRevenue() {
			return this.revenue;
		}

		public java.util.Date date;

		public java.util.Date getDate() {
			return this.date;
		}

		@Override
		public int hashCode() {
			if (this.hashCodeDirty) {
				final int prime = PRIME;
				int result = DEFAULT_HASHCODE;

				result = prime * result + ((this.id == null) ? 0 : this.id.hashCode());

				this.hashCode = result;
				this.hashCodeDirty = false;
			}
			return this.hashCode;
		}

		@Override
		public boolean equals(Object obj) {
			if (this == obj)
				return true;
			if (obj == null)
				return false;
			if (getClass() != obj.getClass())
				return false;
			final Joint_rev_budget_dateStruct other = (Joint_rev_budget_dateStruct) obj;

			if (this.id == null) {
				if (other.id != null)
					return false;

			} else if (!this.id.equals(other.id))

				return false;

			return true;
		}

		public void copyDataTo(Joint_rev_budget_dateStruct other) {

			other.id = this.id;
			other.title = this.title;
			other.budget = this.budget;
			other.revenue = this.revenue;
			other.date = this.date;

		}

		public void copyKeysDataTo(Joint_rev_budget_dateStruct other) {

			other.id = this.id;

		}

		private Integer readInteger(ObjectInputStream dis) throws IOException {
			Integer intReturn;
			int length = 0;
			length = dis.readByte();
			if (length == -1) {
				intReturn = null;
			} else {
				intReturn = dis.readInt();
			}
			return intReturn;
		}

		private Integer readInteger(org.jboss.marshalling.Unmarshaller dis) throws IOException {
			Integer intReturn;
			int length = 0;
			length = dis.readByte();
			if (length == -1) {
				intReturn = null;
			} else {
				intReturn = dis.readInt();
			}
			return intReturn;
		}

		private void writeInteger(Integer intNum, ObjectOutputStream dos) throws IOException {
			if (intNum == null) {
				dos.writeByte(-1);
			} else {
				dos.writeByte(0);
				dos.writeInt(intNum);
			}
		}

		private void writeInteger(Integer intNum, org.jboss.marshalling.Marshaller marshaller) throws IOException {
			if (intNum == null) {
				marshaller.writeByte(-1);
			} else {
				marshaller.writeByte(0);
				marshaller.writeInt(intNum);
			}
		}

		private String readString(ObjectInputStream dis) throws IOException {
			String strReturn = null;
			int length = 0;
			length = dis.readInt();
			if (length == -1) {
				strReturn = null;
			} else {
				if (length > commonByteArray_MYFIRSTJOB_TP_MAJ.length) {
					if (length < 1024 && commonByteArray_MYFIRSTJOB_TP_MAJ.length == 0) {
						commonByteArray_MYFIRSTJOB_TP_MAJ = new byte[1024];
					} else {
						commonByteArray_MYFIRSTJOB_TP_MAJ = new byte[2 * length];
					}
				}
				dis.readFully(commonByteArray_MYFIRSTJOB_TP_MAJ, 0, length);
				strReturn = new String(commonByteArray_MYFIRSTJOB_TP_MAJ, 0, length, utf8Charset);
			}
			return strReturn;
		}

		private String readString(org.jboss.marshalling.Unmarshaller unmarshaller) throws IOException {
			String strReturn = null;
			int length = 0;
			length = unmarshaller.readInt();
			if (length == -1) {
				strReturn = null;
			} else {
				if (length > commonByteArray_MYFIRSTJOB_TP_MAJ.length) {
					if (length < 1024 && commonByteArray_MYFIRSTJOB_TP_MAJ.length == 0) {
						commonByteArray_MYFIRSTJOB_TP_MAJ = new byte[1024];
					} else {
						commonByteArray_MYFIRSTJOB_TP_MAJ = new byte[2 * length];
					}
				}
				unmarshaller.readFully(commonByteArray_MYFIRSTJOB_TP_MAJ, 0, length);
				strReturn = new String(commonByteArray_MYFIRSTJOB_TP_MAJ, 0, length, utf8Charset);
			}
			return strReturn;
		}

		private void writeString(String str, ObjectOutputStream dos) throws IOException {
			if (str == null) {
				dos.writeInt(-1);
			} else {
				byte[] byteArray = str.getBytes(utf8Charset);
				dos.writeInt(byteArray.length);
				dos.write(byteArray);
			}
		}

		private void writeString(String str, org.jboss.marshalling.Marshaller marshaller) throws IOException {
			if (str == null) {
				marshaller.writeInt(-1);
			} else {
				byte[] byteArray = str.getBytes(utf8Charset);
				marshaller.writeInt(byteArray.length);
				marshaller.write(byteArray);
			}
		}

		private java.util.Date readDate(ObjectInputStream dis) throws IOException {
			java.util.Date dateReturn = null;
			int length = 0;
			length = dis.readByte();
			if (length == -1) {
				dateReturn = null;
			} else {
				dateReturn = new Date(dis.readLong());
			}
			return dateReturn;
		}

		private java.util.Date readDate(org.jboss.marshalling.Unmarshaller unmarshaller) throws IOException {
			java.util.Date dateReturn = null;
			int length = 0;
			length = unmarshaller.readByte();
			if (length == -1) {
				dateReturn = null;
			} else {
				dateReturn = new Date(unmarshaller.readLong());
			}
			return dateReturn;
		}

		private void writeDate(java.util.Date date1, ObjectOutputStream dos) throws IOException {
			if (date1 == null) {
				dos.writeByte(-1);
			} else {
				dos.writeByte(0);
				dos.writeLong(date1.getTime());
			}
		}

		private void writeDate(java.util.Date date1, org.jboss.marshalling.Marshaller marshaller) throws IOException {
			if (date1 == null) {
				marshaller.writeByte(-1);
			} else {
				marshaller.writeByte(0);
				marshaller.writeLong(date1.getTime());
			}
		}

		public void readData(ObjectInputStream dis) {

			synchronized (commonByteArrayLock_MYFIRSTJOB_TP_MAJ) {

				try {

					int length = 0;

					this.id = readInteger(dis);

					this.title = readString(dis);

					this.budget = readInteger(dis);

					length = dis.readByte();
					if (length == -1) {
						this.revenue = null;
					} else {
						this.revenue = dis.readLong();
					}

					this.date = readDate(dis);

				} catch (IOException e) {
					throw new RuntimeException(e);

				}

			}

		}

		public void readData(org.jboss.marshalling.Unmarshaller dis) {

			synchronized (commonByteArrayLock_MYFIRSTJOB_TP_MAJ) {

				try {

					int length = 0;

					this.id = readInteger(dis);

					this.title = readString(dis);

					this.budget = readInteger(dis);

					length = dis.readByte();
					if (length == -1) {
						this.revenue = null;
					} else {
						this.revenue = dis.readLong();
					}

					this.date = readDate(dis);

				} catch (IOException e) {
					throw new RuntimeException(e);

				}

			}

		}

		public void writeData(ObjectOutputStream dos) {
			try {

				// Integer

				writeInteger(this.id, dos);

				// String

				writeString(this.title, dos);

				// Integer

				writeInteger(this.budget, dos);

				// Long

				if (this.revenue == null) {
					dos.writeByte(-1);
				} else {
					dos.writeByte(0);
					dos.writeLong(this.revenue);
				}

				// java.util.Date

				writeDate(this.date, dos);

			} catch (IOException e) {
				throw new RuntimeException(e);
			}

		}

		public void writeData(org.jboss.marshalling.Marshaller dos) {
			try {

				// Integer

				writeInteger(this.id, dos);

				// String

				writeString(this.title, dos);

				// Integer

				writeInteger(this.budget, dos);

				// Long

				if (this.revenue == null) {
					dos.writeByte(-1);
				} else {
					dos.writeByte(0);
					dos.writeLong(this.revenue);
				}

				// java.util.Date

				writeDate(this.date, dos);

			} catch (IOException e) {
				throw new RuntimeException(e);
			}

		}

		public String toString() {

			StringBuilder sb = new StringBuilder();
			sb.append(super.toString());
			sb.append("[");
			sb.append("id=" + String.valueOf(id));
			sb.append(",title=" + title);
			sb.append(",budget=" + String.valueOf(budget));
			sb.append(",revenue=" + String.valueOf(revenue));
			sb.append(",date=" + String.valueOf(date));
			sb.append("]");

			return sb.toString();
		}

		/**
		 * Compare keys
		 */
		public int compareTo(Joint_rev_budget_dateStruct other) {

			int returnValue = -1;

			returnValue = checkNullsAndCompare(this.id, other.id);
			if (returnValue != 0) {
				return returnValue;
			}

			return returnValue;
		}

		private int checkNullsAndCompare(Object object1, Object object2) {
			int returnValue = 0;
			if (object1 instanceof Comparable && object2 instanceof Comparable) {
				returnValue = ((Comparable) object1).compareTo(object2);
			} else if (object1 != null && object2 != null) {
				returnValue = compareStrings(object1.toString(), object2.toString());
			} else if (object1 == null && object2 != null) {
				returnValue = 1;
			} else if (object1 != null && object2 == null) {
				returnValue = -1;
			} else {
				returnValue = 0;
			}

			return returnValue;
		}

		private int compareStrings(String string1, String string2) {
			return string1.compareTo(string2);
		}

	}

	public static class RatingXmlStruct implements routines.system.IPersistableRow<RatingXmlStruct> {
		final static byte[] commonByteArrayLock_MYFIRSTJOB_TP_MAJ = new byte[0];
		static byte[] commonByteArray_MYFIRSTJOB_TP_MAJ = new byte[0];
		protected static final int DEFAULT_HASHCODE = 1;
		protected static final int PRIME = 31;
		protected int hashCode = DEFAULT_HASHCODE;
		public boolean hashCodeDirty = true;

		public String loopKey;

		public Integer id;

		public Integer getId() {
			return this.id;
		}

		public String title;

		public String getTitle() {
			return this.title;
		}

		public java.util.Date date;

		public java.util.Date getDate() {
			return this.date;
		}

		public Float popularity;

		public Float getPopularity() {
			return this.popularity;
		}

		public Integer vote_count;

		public Integer getVote_count() {
			return this.vote_count;
		}

		public Float vote_average;

		public Float getVote_average() {
			return this.vote_average;
		}

		@Override
		public int hashCode() {
			if (this.hashCodeDirty) {
				final int prime = PRIME;
				int result = DEFAULT_HASHCODE;

				result = prime * result + ((this.id == null) ? 0 : this.id.hashCode());

				this.hashCode = result;
				this.hashCodeDirty = false;
			}
			return this.hashCode;
		}

		@Override
		public boolean equals(Object obj) {
			if (this == obj)
				return true;
			if (obj == null)
				return false;
			if (getClass() != obj.getClass())
				return false;
			final RatingXmlStruct other = (RatingXmlStruct) obj;

			if (this.id == null) {
				if (other.id != null)
					return false;

			} else if (!this.id.equals(other.id))

				return false;

			return true;
		}

		public void copyDataTo(RatingXmlStruct other) {

			other.id = this.id;
			other.title = this.title;
			other.date = this.date;
			other.popularity = this.popularity;
			other.vote_count = this.vote_count;
			other.vote_average = this.vote_average;

		}

		public void copyKeysDataTo(RatingXmlStruct other) {

			other.id = this.id;

		}

		private Integer readInteger(ObjectInputStream dis) throws IOException {
			Integer intReturn;
			int length = 0;
			length = dis.readByte();
			if (length == -1) {
				intReturn = null;
			} else {
				intReturn = dis.readInt();
			}
			return intReturn;
		}

		private Integer readInteger(org.jboss.marshalling.Unmarshaller dis) throws IOException {
			Integer intReturn;
			int length = 0;
			length = dis.readByte();
			if (length == -1) {
				intReturn = null;
			} else {
				intReturn = dis.readInt();
			}
			return intReturn;
		}

		private void writeInteger(Integer intNum, ObjectOutputStream dos) throws IOException {
			if (intNum == null) {
				dos.writeByte(-1);
			} else {
				dos.writeByte(0);
				dos.writeInt(intNum);
			}
		}

		private void writeInteger(Integer intNum, org.jboss.marshalling.Marshaller marshaller) throws IOException {
			if (intNum == null) {
				marshaller.writeByte(-1);
			} else {
				marshaller.writeByte(0);
				marshaller.writeInt(intNum);
			}
		}

		private String readString(ObjectInputStream dis) throws IOException {
			String strReturn = null;
			int length = 0;
			length = dis.readInt();
			if (length == -1) {
				strReturn = null;
			} else {
				if (length > commonByteArray_MYFIRSTJOB_TP_MAJ.length) {
					if (length < 1024 && commonByteArray_MYFIRSTJOB_TP_MAJ.length == 0) {
						commonByteArray_MYFIRSTJOB_TP_MAJ = new byte[1024];
					} else {
						commonByteArray_MYFIRSTJOB_TP_MAJ = new byte[2 * length];
					}
				}
				dis.readFully(commonByteArray_MYFIRSTJOB_TP_MAJ, 0, length);
				strReturn = new String(commonByteArray_MYFIRSTJOB_TP_MAJ, 0, length, utf8Charset);
			}
			return strReturn;
		}

		private String readString(org.jboss.marshalling.Unmarshaller unmarshaller) throws IOException {
			String strReturn = null;
			int length = 0;
			length = unmarshaller.readInt();
			if (length == -1) {
				strReturn = null;
			} else {
				if (length > commonByteArray_MYFIRSTJOB_TP_MAJ.length) {
					if (length < 1024 && commonByteArray_MYFIRSTJOB_TP_MAJ.length == 0) {
						commonByteArray_MYFIRSTJOB_TP_MAJ = new byte[1024];
					} else {
						commonByteArray_MYFIRSTJOB_TP_MAJ = new byte[2 * length];
					}
				}
				unmarshaller.readFully(commonByteArray_MYFIRSTJOB_TP_MAJ, 0, length);
				strReturn = new String(commonByteArray_MYFIRSTJOB_TP_MAJ, 0, length, utf8Charset);
			}
			return strReturn;
		}

		private void writeString(String str, ObjectOutputStream dos) throws IOException {
			if (str == null) {
				dos.writeInt(-1);
			} else {
				byte[] byteArray = str.getBytes(utf8Charset);
				dos.writeInt(byteArray.length);
				dos.write(byteArray);
			}
		}

		private void writeString(String str, org.jboss.marshalling.Marshaller marshaller) throws IOException {
			if (str == null) {
				marshaller.writeInt(-1);
			} else {
				byte[] byteArray = str.getBytes(utf8Charset);
				marshaller.writeInt(byteArray.length);
				marshaller.write(byteArray);
			}
		}

		private java.util.Date readDate(ObjectInputStream dis) throws IOException {
			java.util.Date dateReturn = null;
			int length = 0;
			length = dis.readByte();
			if (length == -1) {
				dateReturn = null;
			} else {
				dateReturn = new Date(dis.readLong());
			}
			return dateReturn;
		}

		private java.util.Date readDate(org.jboss.marshalling.Unmarshaller unmarshaller) throws IOException {
			java.util.Date dateReturn = null;
			int length = 0;
			length = unmarshaller.readByte();
			if (length == -1) {
				dateReturn = null;
			} else {
				dateReturn = new Date(unmarshaller.readLong());
			}
			return dateReturn;
		}

		private void writeDate(java.util.Date date1, ObjectOutputStream dos) throws IOException {
			if (date1 == null) {
				dos.writeByte(-1);
			} else {
				dos.writeByte(0);
				dos.writeLong(date1.getTime());
			}
		}

		private void writeDate(java.util.Date date1, org.jboss.marshalling.Marshaller marshaller) throws IOException {
			if (date1 == null) {
				marshaller.writeByte(-1);
			} else {
				marshaller.writeByte(0);
				marshaller.writeLong(date1.getTime());
			}
		}

		public void readData(ObjectInputStream dis) {

			synchronized (commonByteArrayLock_MYFIRSTJOB_TP_MAJ) {

				try {

					int length = 0;

					this.id = readInteger(dis);

					this.title = readString(dis);

					this.date = readDate(dis);

					length = dis.readByte();
					if (length == -1) {
						this.popularity = null;
					} else {
						this.popularity = dis.readFloat();
					}

					this.vote_count = readInteger(dis);

					length = dis.readByte();
					if (length == -1) {
						this.vote_average = null;
					} else {
						this.vote_average = dis.readFloat();
					}

				} catch (IOException e) {
					throw new RuntimeException(e);

				}

			}

		}

		public void readData(org.jboss.marshalling.Unmarshaller dis) {

			synchronized (commonByteArrayLock_MYFIRSTJOB_TP_MAJ) {

				try {

					int length = 0;

					this.id = readInteger(dis);

					this.title = readString(dis);

					this.date = readDate(dis);

					length = dis.readByte();
					if (length == -1) {
						this.popularity = null;
					} else {
						this.popularity = dis.readFloat();
					}

					this.vote_count = readInteger(dis);

					length = dis.readByte();
					if (length == -1) {
						this.vote_average = null;
					} else {
						this.vote_average = dis.readFloat();
					}

				} catch (IOException e) {
					throw new RuntimeException(e);

				}

			}

		}

		public void writeData(ObjectOutputStream dos) {
			try {

				// Integer

				writeInteger(this.id, dos);

				// String

				writeString(this.title, dos);

				// java.util.Date

				writeDate(this.date, dos);

				// Float

				if (this.popularity == null) {
					dos.writeByte(-1);
				} else {
					dos.writeByte(0);
					dos.writeFloat(this.popularity);
				}

				// Integer

				writeInteger(this.vote_count, dos);

				// Float

				if (this.vote_average == null) {
					dos.writeByte(-1);
				} else {
					dos.writeByte(0);
					dos.writeFloat(this.vote_average);
				}

			} catch (IOException e) {
				throw new RuntimeException(e);
			}

		}

		public void writeData(org.jboss.marshalling.Marshaller dos) {
			try {

				// Integer

				writeInteger(this.id, dos);

				// String

				writeString(this.title, dos);

				// java.util.Date

				writeDate(this.date, dos);

				// Float

				if (this.popularity == null) {
					dos.writeByte(-1);
				} else {
					dos.writeByte(0);
					dos.writeFloat(this.popularity);
				}

				// Integer

				writeInteger(this.vote_count, dos);

				// Float

				if (this.vote_average == null) {
					dos.writeByte(-1);
				} else {
					dos.writeByte(0);
					dos.writeFloat(this.vote_average);
				}

			} catch (IOException e) {
				throw new RuntimeException(e);
			}

		}

		public String toString() {

			StringBuilder sb = new StringBuilder();
			sb.append(super.toString());
			sb.append("[");
			sb.append("id=" + String.valueOf(id));
			sb.append(",title=" + title);
			sb.append(",date=" + String.valueOf(date));
			sb.append(",popularity=" + String.valueOf(popularity));
			sb.append(",vote_count=" + String.valueOf(vote_count));
			sb.append(",vote_average=" + String.valueOf(vote_average));
			sb.append("]");

			return sb.toString();
		}

		/**
		 * Compare keys
		 */
		public int compareTo(RatingXmlStruct other) {

			int returnValue = -1;

			returnValue = checkNullsAndCompare(this.id, other.id);
			if (returnValue != 0) {
				return returnValue;
			}

			return returnValue;
		}

		private int checkNullsAndCompare(Object object1, Object object2) {
			int returnValue = 0;
			if (object1 instanceof Comparable && object2 instanceof Comparable) {
				returnValue = ((Comparable) object1).compareTo(object2);
			} else if (object1 != null && object2 != null) {
				returnValue = compareStrings(object1.toString(), object2.toString());
			} else if (object1 == null && object2 != null) {
				returnValue = 1;
			} else if (object1 != null && object2 == null) {
				returnValue = -1;
			} else {
				returnValue = 0;
			}

			return returnValue;
		}

		private int compareStrings(String string1, String string2) {
			return string1.compareTo(string2);
		}

	}

	public static class Joint_rev_budget_date2Struct
			implements routines.system.IPersistableRow<Joint_rev_budget_date2Struct> {
		final static byte[] commonByteArrayLock_MYFIRSTJOB_TP_MAJ = new byte[0];
		static byte[] commonByteArray_MYFIRSTJOB_TP_MAJ = new byte[0];
		protected static final int DEFAULT_HASHCODE = 1;
		protected static final int PRIME = 31;
		protected int hashCode = DEFAULT_HASHCODE;
		public boolean hashCodeDirty = true;

		public String loopKey;

		public Integer id;

		public Integer getId() {
			return this.id;
		}

		public String title;

		public String getTitle() {
			return this.title;
		}

		public java.util.Date date;

		public java.util.Date getDate() {
			return this.date;
		}

		public Integer budget;

		public Integer getBudget() {
			return this.budget;
		}

		public Long revenue;

		public Long getRevenue() {
			return this.revenue;
		}

		@Override
		public int hashCode() {
			if (this.hashCodeDirty) {
				final int prime = PRIME;
				int result = DEFAULT_HASHCODE;

				result = prime * result + ((this.id == null) ? 0 : this.id.hashCode());

				this.hashCode = result;
				this.hashCodeDirty = false;
			}
			return this.hashCode;
		}

		@Override
		public boolean equals(Object obj) {
			if (this == obj)
				return true;
			if (obj == null)
				return false;
			if (getClass() != obj.getClass())
				return false;
			final Joint_rev_budget_date2Struct other = (Joint_rev_budget_date2Struct) obj;

			if (this.id == null) {
				if (other.id != null)
					return false;

			} else if (!this.id.equals(other.id))

				return false;

			return true;
		}

		public void copyDataTo(Joint_rev_budget_date2Struct other) {

			other.id = this.id;
			other.title = this.title;
			other.date = this.date;
			other.budget = this.budget;
			other.revenue = this.revenue;

		}

		public void copyKeysDataTo(Joint_rev_budget_date2Struct other) {

			other.id = this.id;

		}

		private Integer readInteger(ObjectInputStream dis) throws IOException {
			Integer intReturn;
			int length = 0;
			length = dis.readByte();
			if (length == -1) {
				intReturn = null;
			} else {
				intReturn = dis.readInt();
			}
			return intReturn;
		}

		private Integer readInteger(org.jboss.marshalling.Unmarshaller dis) throws IOException {
			Integer intReturn;
			int length = 0;
			length = dis.readByte();
			if (length == -1) {
				intReturn = null;
			} else {
				intReturn = dis.readInt();
			}
			return intReturn;
		}

		private void writeInteger(Integer intNum, ObjectOutputStream dos) throws IOException {
			if (intNum == null) {
				dos.writeByte(-1);
			} else {
				dos.writeByte(0);
				dos.writeInt(intNum);
			}
		}

		private void writeInteger(Integer intNum, org.jboss.marshalling.Marshaller marshaller) throws IOException {
			if (intNum == null) {
				marshaller.writeByte(-1);
			} else {
				marshaller.writeByte(0);
				marshaller.writeInt(intNum);
			}
		}

		private String readString(ObjectInputStream dis) throws IOException {
			String strReturn = null;
			int length = 0;
			length = dis.readInt();
			if (length == -1) {
				strReturn = null;
			} else {
				if (length > commonByteArray_MYFIRSTJOB_TP_MAJ.length) {
					if (length < 1024 && commonByteArray_MYFIRSTJOB_TP_MAJ.length == 0) {
						commonByteArray_MYFIRSTJOB_TP_MAJ = new byte[1024];
					} else {
						commonByteArray_MYFIRSTJOB_TP_MAJ = new byte[2 * length];
					}
				}
				dis.readFully(commonByteArray_MYFIRSTJOB_TP_MAJ, 0, length);
				strReturn = new String(commonByteArray_MYFIRSTJOB_TP_MAJ, 0, length, utf8Charset);
			}
			return strReturn;
		}

		private String readString(org.jboss.marshalling.Unmarshaller unmarshaller) throws IOException {
			String strReturn = null;
			int length = 0;
			length = unmarshaller.readInt();
			if (length == -1) {
				strReturn = null;
			} else {
				if (length > commonByteArray_MYFIRSTJOB_TP_MAJ.length) {
					if (length < 1024 && commonByteArray_MYFIRSTJOB_TP_MAJ.length == 0) {
						commonByteArray_MYFIRSTJOB_TP_MAJ = new byte[1024];
					} else {
						commonByteArray_MYFIRSTJOB_TP_MAJ = new byte[2 * length];
					}
				}
				unmarshaller.readFully(commonByteArray_MYFIRSTJOB_TP_MAJ, 0, length);
				strReturn = new String(commonByteArray_MYFIRSTJOB_TP_MAJ, 0, length, utf8Charset);
			}
			return strReturn;
		}

		private void writeString(String str, ObjectOutputStream dos) throws IOException {
			if (str == null) {
				dos.writeInt(-1);
			} else {
				byte[] byteArray = str.getBytes(utf8Charset);
				dos.writeInt(byteArray.length);
				dos.write(byteArray);
			}
		}

		private void writeString(String str, org.jboss.marshalling.Marshaller marshaller) throws IOException {
			if (str == null) {
				marshaller.writeInt(-1);
			} else {
				byte[] byteArray = str.getBytes(utf8Charset);
				marshaller.writeInt(byteArray.length);
				marshaller.write(byteArray);
			}
		}

		private java.util.Date readDate(ObjectInputStream dis) throws IOException {
			java.util.Date dateReturn = null;
			int length = 0;
			length = dis.readByte();
			if (length == -1) {
				dateReturn = null;
			} else {
				dateReturn = new Date(dis.readLong());
			}
			return dateReturn;
		}

		private java.util.Date readDate(org.jboss.marshalling.Unmarshaller unmarshaller) throws IOException {
			java.util.Date dateReturn = null;
			int length = 0;
			length = unmarshaller.readByte();
			if (length == -1) {
				dateReturn = null;
			} else {
				dateReturn = new Date(unmarshaller.readLong());
			}
			return dateReturn;
		}

		private void writeDate(java.util.Date date1, ObjectOutputStream dos) throws IOException {
			if (date1 == null) {
				dos.writeByte(-1);
			} else {
				dos.writeByte(0);
				dos.writeLong(date1.getTime());
			}
		}

		private void writeDate(java.util.Date date1, org.jboss.marshalling.Marshaller marshaller) throws IOException {
			if (date1 == null) {
				marshaller.writeByte(-1);
			} else {
				marshaller.writeByte(0);
				marshaller.writeLong(date1.getTime());
			}
		}

		public void readData(ObjectInputStream dis) {

			synchronized (commonByteArrayLock_MYFIRSTJOB_TP_MAJ) {

				try {

					int length = 0;

					this.id = readInteger(dis);

					this.title = readString(dis);

					this.date = readDate(dis);

					this.budget = readInteger(dis);

					length = dis.readByte();
					if (length == -1) {
						this.revenue = null;
					} else {
						this.revenue = dis.readLong();
					}

				} catch (IOException e) {
					throw new RuntimeException(e);

				}

			}

		}

		public void readData(org.jboss.marshalling.Unmarshaller dis) {

			synchronized (commonByteArrayLock_MYFIRSTJOB_TP_MAJ) {

				try {

					int length = 0;

					this.id = readInteger(dis);

					this.title = readString(dis);

					this.date = readDate(dis);

					this.budget = readInteger(dis);

					length = dis.readByte();
					if (length == -1) {
						this.revenue = null;
					} else {
						this.revenue = dis.readLong();
					}

				} catch (IOException e) {
					throw new RuntimeException(e);

				}

			}

		}

		public void writeData(ObjectOutputStream dos) {
			try {

				// Integer

				writeInteger(this.id, dos);

				// String

				writeString(this.title, dos);

				// java.util.Date

				writeDate(this.date, dos);

				// Integer

				writeInteger(this.budget, dos);

				// Long

				if (this.revenue == null) {
					dos.writeByte(-1);
				} else {
					dos.writeByte(0);
					dos.writeLong(this.revenue);
				}

			} catch (IOException e) {
				throw new RuntimeException(e);
			}

		}

		public void writeData(org.jboss.marshalling.Marshaller dos) {
			try {

				// Integer

				writeInteger(this.id, dos);

				// String

				writeString(this.title, dos);

				// java.util.Date

				writeDate(this.date, dos);

				// Integer

				writeInteger(this.budget, dos);

				// Long

				if (this.revenue == null) {
					dos.writeByte(-1);
				} else {
					dos.writeByte(0);
					dos.writeLong(this.revenue);
				}

			} catch (IOException e) {
				throw new RuntimeException(e);
			}

		}

		public String toString() {

			StringBuilder sb = new StringBuilder();
			sb.append(super.toString());
			sb.append("[");
			sb.append("id=" + String.valueOf(id));
			sb.append(",title=" + title);
			sb.append(",date=" + String.valueOf(date));
			sb.append(",budget=" + String.valueOf(budget));
			sb.append(",revenue=" + String.valueOf(revenue));
			sb.append("]");

			return sb.toString();
		}

		/**
		 * Compare keys
		 */
		public int compareTo(Joint_rev_budget_date2Struct other) {

			int returnValue = -1;

			returnValue = checkNullsAndCompare(this.id, other.id);
			if (returnValue != 0) {
				return returnValue;
			}

			return returnValue;
		}

		private int checkNullsAndCompare(Object object1, Object object2) {
			int returnValue = 0;
			if (object1 instanceof Comparable && object2 instanceof Comparable) {
				returnValue = ((Comparable) object1).compareTo(object2);
			} else if (object1 != null && object2 != null) {
				returnValue = compareStrings(object1.toString(), object2.toString());
			} else if (object1 == null && object2 != null) {
				returnValue = 1;
			} else if (object1 != null && object2 == null) {
				returnValue = -1;
			} else {
				returnValue = 0;
			}

			return returnValue;
		}

		private int compareStrings(String string1, String string2) {
			return string1.compareTo(string2);
		}

	}

	public static class JointSheet2Struct implements routines.system.IPersistableRow<JointSheet2Struct> {
		final static byte[] commonByteArrayLock_MYFIRSTJOB_TP_MAJ = new byte[0];
		static byte[] commonByteArray_MYFIRSTJOB_TP_MAJ = new byte[0];
		protected static final int DEFAULT_HASHCODE = 1;
		protected static final int PRIME = 31;
		protected int hashCode = DEFAULT_HASHCODE;
		public boolean hashCodeDirty = true;

		public String loopKey;

		public Integer id;

		public Integer getId() {
			return this.id;
		}

		public String title;

		public String getTitle() {
			return this.title;
		}

		public java.util.Date date;

		public java.util.Date getDate() {
			return this.date;
		}

		public Integer budget;

		public Integer getBudget() {
			return this.budget;
		}

		public Long revenue;

		public Long getRevenue() {
			return this.revenue;
		}

		@Override
		public int hashCode() {
			if (this.hashCodeDirty) {
				final int prime = PRIME;
				int result = DEFAULT_HASHCODE;

				result = prime * result + ((this.id == null) ? 0 : this.id.hashCode());

				this.hashCode = result;
				this.hashCodeDirty = false;
			}
			return this.hashCode;
		}

		@Override
		public boolean equals(Object obj) {
			if (this == obj)
				return true;
			if (obj == null)
				return false;
			if (getClass() != obj.getClass())
				return false;
			final JointSheet2Struct other = (JointSheet2Struct) obj;

			if (this.id == null) {
				if (other.id != null)
					return false;

			} else if (!this.id.equals(other.id))

				return false;

			return true;
		}

		public void copyDataTo(JointSheet2Struct other) {

			other.id = this.id;
			other.title = this.title;
			other.date = this.date;
			other.budget = this.budget;
			other.revenue = this.revenue;

		}

		public void copyKeysDataTo(JointSheet2Struct other) {

			other.id = this.id;

		}

		private Integer readInteger(ObjectInputStream dis) throws IOException {
			Integer intReturn;
			int length = 0;
			length = dis.readByte();
			if (length == -1) {
				intReturn = null;
			} else {
				intReturn = dis.readInt();
			}
			return intReturn;
		}

		private Integer readInteger(org.jboss.marshalling.Unmarshaller dis) throws IOException {
			Integer intReturn;
			int length = 0;
			length = dis.readByte();
			if (length == -1) {
				intReturn = null;
			} else {
				intReturn = dis.readInt();
			}
			return intReturn;
		}

		private void writeInteger(Integer intNum, ObjectOutputStream dos) throws IOException {
			if (intNum == null) {
				dos.writeByte(-1);
			} else {
				dos.writeByte(0);
				dos.writeInt(intNum);
			}
		}

		private void writeInteger(Integer intNum, org.jboss.marshalling.Marshaller marshaller) throws IOException {
			if (intNum == null) {
				marshaller.writeByte(-1);
			} else {
				marshaller.writeByte(0);
				marshaller.writeInt(intNum);
			}
		}

		private String readString(ObjectInputStream dis) throws IOException {
			String strReturn = null;
			int length = 0;
			length = dis.readInt();
			if (length == -1) {
				strReturn = null;
			} else {
				if (length > commonByteArray_MYFIRSTJOB_TP_MAJ.length) {
					if (length < 1024 && commonByteArray_MYFIRSTJOB_TP_MAJ.length == 0) {
						commonByteArray_MYFIRSTJOB_TP_MAJ = new byte[1024];
					} else {
						commonByteArray_MYFIRSTJOB_TP_MAJ = new byte[2 * length];
					}
				}
				dis.readFully(commonByteArray_MYFIRSTJOB_TP_MAJ, 0, length);
				strReturn = new String(commonByteArray_MYFIRSTJOB_TP_MAJ, 0, length, utf8Charset);
			}
			return strReturn;
		}

		private String readString(org.jboss.marshalling.Unmarshaller unmarshaller) throws IOException {
			String strReturn = null;
			int length = 0;
			length = unmarshaller.readInt();
			if (length == -1) {
				strReturn = null;
			} else {
				if (length > commonByteArray_MYFIRSTJOB_TP_MAJ.length) {
					if (length < 1024 && commonByteArray_MYFIRSTJOB_TP_MAJ.length == 0) {
						commonByteArray_MYFIRSTJOB_TP_MAJ = new byte[1024];
					} else {
						commonByteArray_MYFIRSTJOB_TP_MAJ = new byte[2 * length];
					}
				}
				unmarshaller.readFully(commonByteArray_MYFIRSTJOB_TP_MAJ, 0, length);
				strReturn = new String(commonByteArray_MYFIRSTJOB_TP_MAJ, 0, length, utf8Charset);
			}
			return strReturn;
		}

		private void writeString(String str, ObjectOutputStream dos) throws IOException {
			if (str == null) {
				dos.writeInt(-1);
			} else {
				byte[] byteArray = str.getBytes(utf8Charset);
				dos.writeInt(byteArray.length);
				dos.write(byteArray);
			}
		}

		private void writeString(String str, org.jboss.marshalling.Marshaller marshaller) throws IOException {
			if (str == null) {
				marshaller.writeInt(-1);
			} else {
				byte[] byteArray = str.getBytes(utf8Charset);
				marshaller.writeInt(byteArray.length);
				marshaller.write(byteArray);
			}
		}

		private java.util.Date readDate(ObjectInputStream dis) throws IOException {
			java.util.Date dateReturn = null;
			int length = 0;
			length = dis.readByte();
			if (length == -1) {
				dateReturn = null;
			} else {
				dateReturn = new Date(dis.readLong());
			}
			return dateReturn;
		}

		private java.util.Date readDate(org.jboss.marshalling.Unmarshaller unmarshaller) throws IOException {
			java.util.Date dateReturn = null;
			int length = 0;
			length = unmarshaller.readByte();
			if (length == -1) {
				dateReturn = null;
			} else {
				dateReturn = new Date(unmarshaller.readLong());
			}
			return dateReturn;
		}

		private void writeDate(java.util.Date date1, ObjectOutputStream dos) throws IOException {
			if (date1 == null) {
				dos.writeByte(-1);
			} else {
				dos.writeByte(0);
				dos.writeLong(date1.getTime());
			}
		}

		private void writeDate(java.util.Date date1, org.jboss.marshalling.Marshaller marshaller) throws IOException {
			if (date1 == null) {
				marshaller.writeByte(-1);
			} else {
				marshaller.writeByte(0);
				marshaller.writeLong(date1.getTime());
			}
		}

		public void readData(ObjectInputStream dis) {

			synchronized (commonByteArrayLock_MYFIRSTJOB_TP_MAJ) {

				try {

					int length = 0;

					this.id = readInteger(dis);

					this.title = readString(dis);

					this.date = readDate(dis);

					this.budget = readInteger(dis);

					length = dis.readByte();
					if (length == -1) {
						this.revenue = null;
					} else {
						this.revenue = dis.readLong();
					}

				} catch (IOException e) {
					throw new RuntimeException(e);

				}

			}

		}

		public void readData(org.jboss.marshalling.Unmarshaller dis) {

			synchronized (commonByteArrayLock_MYFIRSTJOB_TP_MAJ) {

				try {

					int length = 0;

					this.id = readInteger(dis);

					this.title = readString(dis);

					this.date = readDate(dis);

					this.budget = readInteger(dis);

					length = dis.readByte();
					if (length == -1) {
						this.revenue = null;
					} else {
						this.revenue = dis.readLong();
					}

				} catch (IOException e) {
					throw new RuntimeException(e);

				}

			}

		}

		public void writeData(ObjectOutputStream dos) {
			try {

				// Integer

				writeInteger(this.id, dos);

				// String

				writeString(this.title, dos);

				// java.util.Date

				writeDate(this.date, dos);

				// Integer

				writeInteger(this.budget, dos);

				// Long

				if (this.revenue == null) {
					dos.writeByte(-1);
				} else {
					dos.writeByte(0);
					dos.writeLong(this.revenue);
				}

			} catch (IOException e) {
				throw new RuntimeException(e);
			}

		}

		public void writeData(org.jboss.marshalling.Marshaller dos) {
			try {

				// Integer

				writeInteger(this.id, dos);

				// String

				writeString(this.title, dos);

				// java.util.Date

				writeDate(this.date, dos);

				// Integer

				writeInteger(this.budget, dos);

				// Long

				if (this.revenue == null) {
					dos.writeByte(-1);
				} else {
					dos.writeByte(0);
					dos.writeLong(this.revenue);
				}

			} catch (IOException e) {
				throw new RuntimeException(e);
			}

		}

		public String toString() {

			StringBuilder sb = new StringBuilder();
			sb.append(super.toString());
			sb.append("[");
			sb.append("id=" + String.valueOf(id));
			sb.append(",title=" + title);
			sb.append(",date=" + String.valueOf(date));
			sb.append(",budget=" + String.valueOf(budget));
			sb.append(",revenue=" + String.valueOf(revenue));
			sb.append("]");

			return sb.toString();
		}

		/**
		 * Compare keys
		 */
		public int compareTo(JointSheet2Struct other) {

			int returnValue = -1;

			returnValue = checkNullsAndCompare(this.id, other.id);
			if (returnValue != 0) {
				return returnValue;
			}

			return returnValue;
		}

		private int checkNullsAndCompare(Object object1, Object object2) {
			int returnValue = 0;
			if (object1 instanceof Comparable && object2 instanceof Comparable) {
				returnValue = ((Comparable) object1).compareTo(object2);
			} else if (object1 != null && object2 != null) {
				returnValue = compareStrings(object1.toString(), object2.toString());
			} else if (object1 == null && object2 != null) {
				returnValue = 1;
			} else if (object1 != null && object2 == null) {
				returnValue = -1;
			} else {
				returnValue = 0;
			}

			return returnValue;
		}

		private int compareStrings(String string1, String string2) {
			return string1.compareTo(string2);
		}

	}

	public static class JoinSheet3Struct implements routines.system.IPersistableRow<JoinSheet3Struct> {
		final static byte[] commonByteArrayLock_MYFIRSTJOB_TP_MAJ = new byte[0];
		static byte[] commonByteArray_MYFIRSTJOB_TP_MAJ = new byte[0];
		protected static final int DEFAULT_HASHCODE = 1;
		protected static final int PRIME = 31;
		protected int hashCode = DEFAULT_HASHCODE;
		public boolean hashCodeDirty = true;

		public String loopKey;

		public Integer id;

		public Integer getId() {
			return this.id;
		}

		public String title;

		public String getTitle() {
			return this.title;
		}

		public java.util.Date date;

		public java.util.Date getDate() {
			return this.date;
		}

		public Integer budget;

		public Integer getBudget() {
			return this.budget;
		}

		public Long revenue;

		public Long getRevenue() {
			return this.revenue;
		}

		public Long gain_perte;

		public Long getGain_perte() {
			return this.gain_perte;
		}

		@Override
		public int hashCode() {
			if (this.hashCodeDirty) {
				final int prime = PRIME;
				int result = DEFAULT_HASHCODE;

				result = prime * result + ((this.id == null) ? 0 : this.id.hashCode());

				this.hashCode = result;
				this.hashCodeDirty = false;
			}
			return this.hashCode;
		}

		@Override
		public boolean equals(Object obj) {
			if (this == obj)
				return true;
			if (obj == null)
				return false;
			if (getClass() != obj.getClass())
				return false;
			final JoinSheet3Struct other = (JoinSheet3Struct) obj;

			if (this.id == null) {
				if (other.id != null)
					return false;

			} else if (!this.id.equals(other.id))

				return false;

			return true;
		}

		public void copyDataTo(JoinSheet3Struct other) {

			other.id = this.id;
			other.title = this.title;
			other.date = this.date;
			other.budget = this.budget;
			other.revenue = this.revenue;
			other.gain_perte = this.gain_perte;

		}

		public void copyKeysDataTo(JoinSheet3Struct other) {

			other.id = this.id;

		}

		private Integer readInteger(ObjectInputStream dis) throws IOException {
			Integer intReturn;
			int length = 0;
			length = dis.readByte();
			if (length == -1) {
				intReturn = null;
			} else {
				intReturn = dis.readInt();
			}
			return intReturn;
		}

		private Integer readInteger(org.jboss.marshalling.Unmarshaller dis) throws IOException {
			Integer intReturn;
			int length = 0;
			length = dis.readByte();
			if (length == -1) {
				intReturn = null;
			} else {
				intReturn = dis.readInt();
			}
			return intReturn;
		}

		private void writeInteger(Integer intNum, ObjectOutputStream dos) throws IOException {
			if (intNum == null) {
				dos.writeByte(-1);
			} else {
				dos.writeByte(0);
				dos.writeInt(intNum);
			}
		}

		private void writeInteger(Integer intNum, org.jboss.marshalling.Marshaller marshaller) throws IOException {
			if (intNum == null) {
				marshaller.writeByte(-1);
			} else {
				marshaller.writeByte(0);
				marshaller.writeInt(intNum);
			}
		}

		private String readString(ObjectInputStream dis) throws IOException {
			String strReturn = null;
			int length = 0;
			length = dis.readInt();
			if (length == -1) {
				strReturn = null;
			} else {
				if (length > commonByteArray_MYFIRSTJOB_TP_MAJ.length) {
					if (length < 1024 && commonByteArray_MYFIRSTJOB_TP_MAJ.length == 0) {
						commonByteArray_MYFIRSTJOB_TP_MAJ = new byte[1024];
					} else {
						commonByteArray_MYFIRSTJOB_TP_MAJ = new byte[2 * length];
					}
				}
				dis.readFully(commonByteArray_MYFIRSTJOB_TP_MAJ, 0, length);
				strReturn = new String(commonByteArray_MYFIRSTJOB_TP_MAJ, 0, length, utf8Charset);
			}
			return strReturn;
		}

		private String readString(org.jboss.marshalling.Unmarshaller unmarshaller) throws IOException {
			String strReturn = null;
			int length = 0;
			length = unmarshaller.readInt();
			if (length == -1) {
				strReturn = null;
			} else {
				if (length > commonByteArray_MYFIRSTJOB_TP_MAJ.length) {
					if (length < 1024 && commonByteArray_MYFIRSTJOB_TP_MAJ.length == 0) {
						commonByteArray_MYFIRSTJOB_TP_MAJ = new byte[1024];
					} else {
						commonByteArray_MYFIRSTJOB_TP_MAJ = new byte[2 * length];
					}
				}
				unmarshaller.readFully(commonByteArray_MYFIRSTJOB_TP_MAJ, 0, length);
				strReturn = new String(commonByteArray_MYFIRSTJOB_TP_MAJ, 0, length, utf8Charset);
			}
			return strReturn;
		}

		private void writeString(String str, ObjectOutputStream dos) throws IOException {
			if (str == null) {
				dos.writeInt(-1);
			} else {
				byte[] byteArray = str.getBytes(utf8Charset);
				dos.writeInt(byteArray.length);
				dos.write(byteArray);
			}
		}

		private void writeString(String str, org.jboss.marshalling.Marshaller marshaller) throws IOException {
			if (str == null) {
				marshaller.writeInt(-1);
			} else {
				byte[] byteArray = str.getBytes(utf8Charset);
				marshaller.writeInt(byteArray.length);
				marshaller.write(byteArray);
			}
		}

		private java.util.Date readDate(ObjectInputStream dis) throws IOException {
			java.util.Date dateReturn = null;
			int length = 0;
			length = dis.readByte();
			if (length == -1) {
				dateReturn = null;
			} else {
				dateReturn = new Date(dis.readLong());
			}
			return dateReturn;
		}

		private java.util.Date readDate(org.jboss.marshalling.Unmarshaller unmarshaller) throws IOException {
			java.util.Date dateReturn = null;
			int length = 0;
			length = unmarshaller.readByte();
			if (length == -1) {
				dateReturn = null;
			} else {
				dateReturn = new Date(unmarshaller.readLong());
			}
			return dateReturn;
		}

		private void writeDate(java.util.Date date1, ObjectOutputStream dos) throws IOException {
			if (date1 == null) {
				dos.writeByte(-1);
			} else {
				dos.writeByte(0);
				dos.writeLong(date1.getTime());
			}
		}

		private void writeDate(java.util.Date date1, org.jboss.marshalling.Marshaller marshaller) throws IOException {
			if (date1 == null) {
				marshaller.writeByte(-1);
			} else {
				marshaller.writeByte(0);
				marshaller.writeLong(date1.getTime());
			}
		}

		public void readData(ObjectInputStream dis) {

			synchronized (commonByteArrayLock_MYFIRSTJOB_TP_MAJ) {

				try {

					int length = 0;

					this.id = readInteger(dis);

					this.title = readString(dis);

					this.date = readDate(dis);

					this.budget = readInteger(dis);

					length = dis.readByte();
					if (length == -1) {
						this.revenue = null;
					} else {
						this.revenue = dis.readLong();
					}

					length = dis.readByte();
					if (length == -1) {
						this.gain_perte = null;
					} else {
						this.gain_perte = dis.readLong();
					}

				} catch (IOException e) {
					throw new RuntimeException(e);

				}

			}

		}

		public void readData(org.jboss.marshalling.Unmarshaller dis) {

			synchronized (commonByteArrayLock_MYFIRSTJOB_TP_MAJ) {

				try {

					int length = 0;

					this.id = readInteger(dis);

					this.title = readString(dis);

					this.date = readDate(dis);

					this.budget = readInteger(dis);

					length = dis.readByte();
					if (length == -1) {
						this.revenue = null;
					} else {
						this.revenue = dis.readLong();
					}

					length = dis.readByte();
					if (length == -1) {
						this.gain_perte = null;
					} else {
						this.gain_perte = dis.readLong();
					}

				} catch (IOException e) {
					throw new RuntimeException(e);

				}

			}

		}

		public void writeData(ObjectOutputStream dos) {
			try {

				// Integer

				writeInteger(this.id, dos);

				// String

				writeString(this.title, dos);

				// java.util.Date

				writeDate(this.date, dos);

				// Integer

				writeInteger(this.budget, dos);

				// Long

				if (this.revenue == null) {
					dos.writeByte(-1);
				} else {
					dos.writeByte(0);
					dos.writeLong(this.revenue);
				}

				// Long

				if (this.gain_perte == null) {
					dos.writeByte(-1);
				} else {
					dos.writeByte(0);
					dos.writeLong(this.gain_perte);
				}

			} catch (IOException e) {
				throw new RuntimeException(e);
			}

		}

		public void writeData(org.jboss.marshalling.Marshaller dos) {
			try {

				// Integer

				writeInteger(this.id, dos);

				// String

				writeString(this.title, dos);

				// java.util.Date

				writeDate(this.date, dos);

				// Integer

				writeInteger(this.budget, dos);

				// Long

				if (this.revenue == null) {
					dos.writeByte(-1);
				} else {
					dos.writeByte(0);
					dos.writeLong(this.revenue);
				}

				// Long

				if (this.gain_perte == null) {
					dos.writeByte(-1);
				} else {
					dos.writeByte(0);
					dos.writeLong(this.gain_perte);
				}

			} catch (IOException e) {
				throw new RuntimeException(e);
			}

		}

		public String toString() {

			StringBuilder sb = new StringBuilder();
			sb.append(super.toString());
			sb.append("[");
			sb.append("id=" + String.valueOf(id));
			sb.append(",title=" + title);
			sb.append(",date=" + String.valueOf(date));
			sb.append(",budget=" + String.valueOf(budget));
			sb.append(",revenue=" + String.valueOf(revenue));
			sb.append(",gain_perte=" + String.valueOf(gain_perte));
			sb.append("]");

			return sb.toString();
		}

		/**
		 * Compare keys
		 */
		public int compareTo(JoinSheet3Struct other) {

			int returnValue = -1;

			returnValue = checkNullsAndCompare(this.id, other.id);
			if (returnValue != 0) {
				return returnValue;
			}

			return returnValue;
		}

		private int checkNullsAndCompare(Object object1, Object object2) {
			int returnValue = 0;
			if (object1 instanceof Comparable && object2 instanceof Comparable) {
				returnValue = ((Comparable) object1).compareTo(object2);
			} else if (object1 != null && object2 != null) {
				returnValue = compareStrings(object1.toString(), object2.toString());
			} else if (object1 == null && object2 != null) {
				returnValue = 1;
			} else if (object1 != null && object2 == null) {
				returnValue = -1;
			} else {
				returnValue = 0;
			}

			return returnValue;
		}

		private int compareStrings(String string1, String string2) {
			return string1.compareTo(string2);
		}

	}

	public static class row14Struct implements routines.system.IPersistableRow<row14Struct> {
		final static byte[] commonByteArrayLock_MYFIRSTJOB_TP_MAJ = new byte[0];
		static byte[] commonByteArray_MYFIRSTJOB_TP_MAJ = new byte[0];

		public Integer id;

		public Integer getId() {
			return this.id;
		}

		public String title;

		public String getTitle() {
			return this.title;
		}

		public java.util.Date date;

		public java.util.Date getDate() {
			return this.date;
		}

		public Float popularity;

		public Float getPopularity() {
			return this.popularity;
		}

		public Integer vote_count;

		public Integer getVote_count() {
			return this.vote_count;
		}

		public Float vote_average;

		public Float getVote_average() {
			return this.vote_average;
		}

		public Integer budget;

		public Integer getBudget() {
			return this.budget;
		}

		public Long revenue;

		public Long getRevenue() {
			return this.revenue;
		}

		private Integer readInteger(ObjectInputStream dis) throws IOException {
			Integer intReturn;
			int length = 0;
			length = dis.readByte();
			if (length == -1) {
				intReturn = null;
			} else {
				intReturn = dis.readInt();
			}
			return intReturn;
		}

		private Integer readInteger(org.jboss.marshalling.Unmarshaller dis) throws IOException {
			Integer intReturn;
			int length = 0;
			length = dis.readByte();
			if (length == -1) {
				intReturn = null;
			} else {
				intReturn = dis.readInt();
			}
			return intReturn;
		}

		private void writeInteger(Integer intNum, ObjectOutputStream dos) throws IOException {
			if (intNum == null) {
				dos.writeByte(-1);
			} else {
				dos.writeByte(0);
				dos.writeInt(intNum);
			}
		}

		private void writeInteger(Integer intNum, org.jboss.marshalling.Marshaller marshaller) throws IOException {
			if (intNum == null) {
				marshaller.writeByte(-1);
			} else {
				marshaller.writeByte(0);
				marshaller.writeInt(intNum);
			}
		}

		private String readString(ObjectInputStream dis) throws IOException {
			String strReturn = null;
			int length = 0;
			length = dis.readInt();
			if (length == -1) {
				strReturn = null;
			} else {
				if (length > commonByteArray_MYFIRSTJOB_TP_MAJ.length) {
					if (length < 1024 && commonByteArray_MYFIRSTJOB_TP_MAJ.length == 0) {
						commonByteArray_MYFIRSTJOB_TP_MAJ = new byte[1024];
					} else {
						commonByteArray_MYFIRSTJOB_TP_MAJ = new byte[2 * length];
					}
				}
				dis.readFully(commonByteArray_MYFIRSTJOB_TP_MAJ, 0, length);
				strReturn = new String(commonByteArray_MYFIRSTJOB_TP_MAJ, 0, length, utf8Charset);
			}
			return strReturn;
		}

		private String readString(org.jboss.marshalling.Unmarshaller unmarshaller) throws IOException {
			String strReturn = null;
			int length = 0;
			length = unmarshaller.readInt();
			if (length == -1) {
				strReturn = null;
			} else {
				if (length > commonByteArray_MYFIRSTJOB_TP_MAJ.length) {
					if (length < 1024 && commonByteArray_MYFIRSTJOB_TP_MAJ.length == 0) {
						commonByteArray_MYFIRSTJOB_TP_MAJ = new byte[1024];
					} else {
						commonByteArray_MYFIRSTJOB_TP_MAJ = new byte[2 * length];
					}
				}
				unmarshaller.readFully(commonByteArray_MYFIRSTJOB_TP_MAJ, 0, length);
				strReturn = new String(commonByteArray_MYFIRSTJOB_TP_MAJ, 0, length, utf8Charset);
			}
			return strReturn;
		}

		private void writeString(String str, ObjectOutputStream dos) throws IOException {
			if (str == null) {
				dos.writeInt(-1);
			} else {
				byte[] byteArray = str.getBytes(utf8Charset);
				dos.writeInt(byteArray.length);
				dos.write(byteArray);
			}
		}

		private void writeString(String str, org.jboss.marshalling.Marshaller marshaller) throws IOException {
			if (str == null) {
				marshaller.writeInt(-1);
			} else {
				byte[] byteArray = str.getBytes(utf8Charset);
				marshaller.writeInt(byteArray.length);
				marshaller.write(byteArray);
			}
		}

		private java.util.Date readDate(ObjectInputStream dis) throws IOException {
			java.util.Date dateReturn = null;
			int length = 0;
			length = dis.readByte();
			if (length == -1) {
				dateReturn = null;
			} else {
				dateReturn = new Date(dis.readLong());
			}
			return dateReturn;
		}

		private java.util.Date readDate(org.jboss.marshalling.Unmarshaller unmarshaller) throws IOException {
			java.util.Date dateReturn = null;
			int length = 0;
			length = unmarshaller.readByte();
			if (length == -1) {
				dateReturn = null;
			} else {
				dateReturn = new Date(unmarshaller.readLong());
			}
			return dateReturn;
		}

		private void writeDate(java.util.Date date1, ObjectOutputStream dos) throws IOException {
			if (date1 == null) {
				dos.writeByte(-1);
			} else {
				dos.writeByte(0);
				dos.writeLong(date1.getTime());
			}
		}

		private void writeDate(java.util.Date date1, org.jboss.marshalling.Marshaller marshaller) throws IOException {
			if (date1 == null) {
				marshaller.writeByte(-1);
			} else {
				marshaller.writeByte(0);
				marshaller.writeLong(date1.getTime());
			}
		}

		public void readData(ObjectInputStream dis) {

			synchronized (commonByteArrayLock_MYFIRSTJOB_TP_MAJ) {

				try {

					int length = 0;

					this.id = readInteger(dis);

					this.title = readString(dis);

					this.date = readDate(dis);

					length = dis.readByte();
					if (length == -1) {
						this.popularity = null;
					} else {
						this.popularity = dis.readFloat();
					}

					this.vote_count = readInteger(dis);

					length = dis.readByte();
					if (length == -1) {
						this.vote_average = null;
					} else {
						this.vote_average = dis.readFloat();
					}

					this.budget = readInteger(dis);

					length = dis.readByte();
					if (length == -1) {
						this.revenue = null;
					} else {
						this.revenue = dis.readLong();
					}

				} catch (IOException e) {
					throw new RuntimeException(e);

				}

			}

		}

		public void readData(org.jboss.marshalling.Unmarshaller dis) {

			synchronized (commonByteArrayLock_MYFIRSTJOB_TP_MAJ) {

				try {

					int length = 0;

					this.id = readInteger(dis);

					this.title = readString(dis);

					this.date = readDate(dis);

					length = dis.readByte();
					if (length == -1) {
						this.popularity = null;
					} else {
						this.popularity = dis.readFloat();
					}

					this.vote_count = readInteger(dis);

					length = dis.readByte();
					if (length == -1) {
						this.vote_average = null;
					} else {
						this.vote_average = dis.readFloat();
					}

					this.budget = readInteger(dis);

					length = dis.readByte();
					if (length == -1) {
						this.revenue = null;
					} else {
						this.revenue = dis.readLong();
					}

				} catch (IOException e) {
					throw new RuntimeException(e);

				}

			}

		}

		public void writeData(ObjectOutputStream dos) {
			try {

				// Integer

				writeInteger(this.id, dos);

				// String

				writeString(this.title, dos);

				// java.util.Date

				writeDate(this.date, dos);

				// Float

				if (this.popularity == null) {
					dos.writeByte(-1);
				} else {
					dos.writeByte(0);
					dos.writeFloat(this.popularity);
				}

				// Integer

				writeInteger(this.vote_count, dos);

				// Float

				if (this.vote_average == null) {
					dos.writeByte(-1);
				} else {
					dos.writeByte(0);
					dos.writeFloat(this.vote_average);
				}

				// Integer

				writeInteger(this.budget, dos);

				// Long

				if (this.revenue == null) {
					dos.writeByte(-1);
				} else {
					dos.writeByte(0);
					dos.writeLong(this.revenue);
				}

			} catch (IOException e) {
				throw new RuntimeException(e);
			}

		}

		public void writeData(org.jboss.marshalling.Marshaller dos) {
			try {

				// Integer

				writeInteger(this.id, dos);

				// String

				writeString(this.title, dos);

				// java.util.Date

				writeDate(this.date, dos);

				// Float

				if (this.popularity == null) {
					dos.writeByte(-1);
				} else {
					dos.writeByte(0);
					dos.writeFloat(this.popularity);
				}

				// Integer

				writeInteger(this.vote_count, dos);

				// Float

				if (this.vote_average == null) {
					dos.writeByte(-1);
				} else {
					dos.writeByte(0);
					dos.writeFloat(this.vote_average);
				}

				// Integer

				writeInteger(this.budget, dos);

				// Long

				if (this.revenue == null) {
					dos.writeByte(-1);
				} else {
					dos.writeByte(0);
					dos.writeLong(this.revenue);
				}

			} catch (IOException e) {
				throw new RuntimeException(e);
			}

		}

		public String toString() {

			StringBuilder sb = new StringBuilder();
			sb.append(super.toString());
			sb.append("[");
			sb.append("id=" + String.valueOf(id));
			sb.append(",title=" + title);
			sb.append(",date=" + String.valueOf(date));
			sb.append(",popularity=" + String.valueOf(popularity));
			sb.append(",vote_count=" + String.valueOf(vote_count));
			sb.append(",vote_average=" + String.valueOf(vote_average));
			sb.append(",budget=" + String.valueOf(budget));
			sb.append(",revenue=" + String.valueOf(revenue));
			sb.append("]");

			return sb.toString();
		}

		/**
		 * Compare keys
		 */
		public int compareTo(row14Struct other) {

			int returnValue = -1;

			return returnValue;
		}

		private int checkNullsAndCompare(Object object1, Object object2) {
			int returnValue = 0;
			if (object1 instanceof Comparable && object2 instanceof Comparable) {
				returnValue = ((Comparable) object1).compareTo(object2);
			} else if (object1 != null && object2 != null) {
				returnValue = compareStrings(object1.toString(), object2.toString());
			} else if (object1 == null && object2 != null) {
				returnValue = 1;
			} else if (object1 != null && object2 == null) {
				returnValue = -1;
			} else {
				returnValue = 0;
			}

			return returnValue;
		}

		private int compareStrings(String string1, String string2) {
			return string1.compareTo(string2);
		}

	}

	public static class row8Struct implements routines.system.IPersistableRow<row8Struct> {
		final static byte[] commonByteArrayLock_MYFIRSTJOB_TP_MAJ = new byte[0];
		static byte[] commonByteArray_MYFIRSTJOB_TP_MAJ = new byte[0];
		protected static final int DEFAULT_HASHCODE = 1;
		protected static final int PRIME = 31;
		protected int hashCode = DEFAULT_HASHCODE;
		public boolean hashCodeDirty = true;

		public String loopKey;

		public Integer id;

		public Integer getId() {
			return this.id;
		}

		public String title;

		public String getTitle() {
			return this.title;
		}

		public java.util.Date date;

		public java.util.Date getDate() {
			return this.date;
		}

		public Float popularity;

		public Float getPopularity() {
			return this.popularity;
		}

		public Integer vote_count;

		public Integer getVote_count() {
			return this.vote_count;
		}

		public Float vote_average;

		public Float getVote_average() {
			return this.vote_average;
		}

		public Integer budget;

		public Integer getBudget() {
			return this.budget;
		}

		public Long revenue;

		public Long getRevenue() {
			return this.revenue;
		}

		public String errorMessage;

		public String getErrorMessage() {
			return this.errorMessage;
		}

		@Override
		public int hashCode() {
			if (this.hashCodeDirty) {
				final int prime = PRIME;
				int result = DEFAULT_HASHCODE;

				result = prime * result + ((this.id == null) ? 0 : this.id.hashCode());

				this.hashCode = result;
				this.hashCodeDirty = false;
			}
			return this.hashCode;
		}

		@Override
		public boolean equals(Object obj) {
			if (this == obj)
				return true;
			if (obj == null)
				return false;
			if (getClass() != obj.getClass())
				return false;
			final row8Struct other = (row8Struct) obj;

			if (this.id == null) {
				if (other.id != null)
					return false;

			} else if (!this.id.equals(other.id))

				return false;

			return true;
		}

		public void copyDataTo(row8Struct other) {

			other.id = this.id;
			other.title = this.title;
			other.date = this.date;
			other.popularity = this.popularity;
			other.vote_count = this.vote_count;
			other.vote_average = this.vote_average;
			other.budget = this.budget;
			other.revenue = this.revenue;
			other.errorMessage = this.errorMessage;

		}

		public void copyKeysDataTo(row8Struct other) {

			other.id = this.id;

		}

		private Integer readInteger(ObjectInputStream dis) throws IOException {
			Integer intReturn;
			int length = 0;
			length = dis.readByte();
			if (length == -1) {
				intReturn = null;
			} else {
				intReturn = dis.readInt();
			}
			return intReturn;
		}

		private Integer readInteger(org.jboss.marshalling.Unmarshaller dis) throws IOException {
			Integer intReturn;
			int length = 0;
			length = dis.readByte();
			if (length == -1) {
				intReturn = null;
			} else {
				intReturn = dis.readInt();
			}
			return intReturn;
		}

		private void writeInteger(Integer intNum, ObjectOutputStream dos) throws IOException {
			if (intNum == null) {
				dos.writeByte(-1);
			} else {
				dos.writeByte(0);
				dos.writeInt(intNum);
			}
		}

		private void writeInteger(Integer intNum, org.jboss.marshalling.Marshaller marshaller) throws IOException {
			if (intNum == null) {
				marshaller.writeByte(-1);
			} else {
				marshaller.writeByte(0);
				marshaller.writeInt(intNum);
			}
		}

		private String readString(ObjectInputStream dis) throws IOException {
			String strReturn = null;
			int length = 0;
			length = dis.readInt();
			if (length == -1) {
				strReturn = null;
			} else {
				if (length > commonByteArray_MYFIRSTJOB_TP_MAJ.length) {
					if (length < 1024 && commonByteArray_MYFIRSTJOB_TP_MAJ.length == 0) {
						commonByteArray_MYFIRSTJOB_TP_MAJ = new byte[1024];
					} else {
						commonByteArray_MYFIRSTJOB_TP_MAJ = new byte[2 * length];
					}
				}
				dis.readFully(commonByteArray_MYFIRSTJOB_TP_MAJ, 0, length);
				strReturn = new String(commonByteArray_MYFIRSTJOB_TP_MAJ, 0, length, utf8Charset);
			}
			return strReturn;
		}

		private String readString(org.jboss.marshalling.Unmarshaller unmarshaller) throws IOException {
			String strReturn = null;
			int length = 0;
			length = unmarshaller.readInt();
			if (length == -1) {
				strReturn = null;
			} else {
				if (length > commonByteArray_MYFIRSTJOB_TP_MAJ.length) {
					if (length < 1024 && commonByteArray_MYFIRSTJOB_TP_MAJ.length == 0) {
						commonByteArray_MYFIRSTJOB_TP_MAJ = new byte[1024];
					} else {
						commonByteArray_MYFIRSTJOB_TP_MAJ = new byte[2 * length];
					}
				}
				unmarshaller.readFully(commonByteArray_MYFIRSTJOB_TP_MAJ, 0, length);
				strReturn = new String(commonByteArray_MYFIRSTJOB_TP_MAJ, 0, length, utf8Charset);
			}
			return strReturn;
		}

		private void writeString(String str, ObjectOutputStream dos) throws IOException {
			if (str == null) {
				dos.writeInt(-1);
			} else {
				byte[] byteArray = str.getBytes(utf8Charset);
				dos.writeInt(byteArray.length);
				dos.write(byteArray);
			}
		}

		private void writeString(String str, org.jboss.marshalling.Marshaller marshaller) throws IOException {
			if (str == null) {
				marshaller.writeInt(-1);
			} else {
				byte[] byteArray = str.getBytes(utf8Charset);
				marshaller.writeInt(byteArray.length);
				marshaller.write(byteArray);
			}
		}

		private java.util.Date readDate(ObjectInputStream dis) throws IOException {
			java.util.Date dateReturn = null;
			int length = 0;
			length = dis.readByte();
			if (length == -1) {
				dateReturn = null;
			} else {
				dateReturn = new Date(dis.readLong());
			}
			return dateReturn;
		}

		private java.util.Date readDate(org.jboss.marshalling.Unmarshaller unmarshaller) throws IOException {
			java.util.Date dateReturn = null;
			int length = 0;
			length = unmarshaller.readByte();
			if (length == -1) {
				dateReturn = null;
			} else {
				dateReturn = new Date(unmarshaller.readLong());
			}
			return dateReturn;
		}

		private void writeDate(java.util.Date date1, ObjectOutputStream dos) throws IOException {
			if (date1 == null) {
				dos.writeByte(-1);
			} else {
				dos.writeByte(0);
				dos.writeLong(date1.getTime());
			}
		}

		private void writeDate(java.util.Date date1, org.jboss.marshalling.Marshaller marshaller) throws IOException {
			if (date1 == null) {
				marshaller.writeByte(-1);
			} else {
				marshaller.writeByte(0);
				marshaller.writeLong(date1.getTime());
			}
		}

		public void readData(ObjectInputStream dis) {

			synchronized (commonByteArrayLock_MYFIRSTJOB_TP_MAJ) {

				try {

					int length = 0;

					this.id = readInteger(dis);

					this.title = readString(dis);

					this.date = readDate(dis);

					length = dis.readByte();
					if (length == -1) {
						this.popularity = null;
					} else {
						this.popularity = dis.readFloat();
					}

					this.vote_count = readInteger(dis);

					length = dis.readByte();
					if (length == -1) {
						this.vote_average = null;
					} else {
						this.vote_average = dis.readFloat();
					}

					this.budget = readInteger(dis);

					length = dis.readByte();
					if (length == -1) {
						this.revenue = null;
					} else {
						this.revenue = dis.readLong();
					}

					this.errorMessage = readString(dis);

				} catch (IOException e) {
					throw new RuntimeException(e);

				}

			}

		}

		public void readData(org.jboss.marshalling.Unmarshaller dis) {

			synchronized (commonByteArrayLock_MYFIRSTJOB_TP_MAJ) {

				try {

					int length = 0;

					this.id = readInteger(dis);

					this.title = readString(dis);

					this.date = readDate(dis);

					length = dis.readByte();
					if (length == -1) {
						this.popularity = null;
					} else {
						this.popularity = dis.readFloat();
					}

					this.vote_count = readInteger(dis);

					length = dis.readByte();
					if (length == -1) {
						this.vote_average = null;
					} else {
						this.vote_average = dis.readFloat();
					}

					this.budget = readInteger(dis);

					length = dis.readByte();
					if (length == -1) {
						this.revenue = null;
					} else {
						this.revenue = dis.readLong();
					}

					this.errorMessage = readString(dis);

				} catch (IOException e) {
					throw new RuntimeException(e);

				}

			}

		}

		public void writeData(ObjectOutputStream dos) {
			try {

				// Integer

				writeInteger(this.id, dos);

				// String

				writeString(this.title, dos);

				// java.util.Date

				writeDate(this.date, dos);

				// Float

				if (this.popularity == null) {
					dos.writeByte(-1);
				} else {
					dos.writeByte(0);
					dos.writeFloat(this.popularity);
				}

				// Integer

				writeInteger(this.vote_count, dos);

				// Float

				if (this.vote_average == null) {
					dos.writeByte(-1);
				} else {
					dos.writeByte(0);
					dos.writeFloat(this.vote_average);
				}

				// Integer

				writeInteger(this.budget, dos);

				// Long

				if (this.revenue == null) {
					dos.writeByte(-1);
				} else {
					dos.writeByte(0);
					dos.writeLong(this.revenue);
				}

				// String

				writeString(this.errorMessage, dos);

			} catch (IOException e) {
				throw new RuntimeException(e);
			}

		}

		public void writeData(org.jboss.marshalling.Marshaller dos) {
			try {

				// Integer

				writeInteger(this.id, dos);

				// String

				writeString(this.title, dos);

				// java.util.Date

				writeDate(this.date, dos);

				// Float

				if (this.popularity == null) {
					dos.writeByte(-1);
				} else {
					dos.writeByte(0);
					dos.writeFloat(this.popularity);
				}

				// Integer

				writeInteger(this.vote_count, dos);

				// Float

				if (this.vote_average == null) {
					dos.writeByte(-1);
				} else {
					dos.writeByte(0);
					dos.writeFloat(this.vote_average);
				}

				// Integer

				writeInteger(this.budget, dos);

				// Long

				if (this.revenue == null) {
					dos.writeByte(-1);
				} else {
					dos.writeByte(0);
					dos.writeLong(this.revenue);
				}

				// String

				writeString(this.errorMessage, dos);

			} catch (IOException e) {
				throw new RuntimeException(e);
			}

		}

		public String toString() {

			StringBuilder sb = new StringBuilder();
			sb.append(super.toString());
			sb.append("[");
			sb.append("id=" + String.valueOf(id));
			sb.append(",title=" + title);
			sb.append(",date=" + String.valueOf(date));
			sb.append(",popularity=" + String.valueOf(popularity));
			sb.append(",vote_count=" + String.valueOf(vote_count));
			sb.append(",vote_average=" + String.valueOf(vote_average));
			sb.append(",budget=" + String.valueOf(budget));
			sb.append(",revenue=" + String.valueOf(revenue));
			sb.append(",errorMessage=" + errorMessage);
			sb.append("]");

			return sb.toString();
		}

		/**
		 * Compare keys
		 */
		public int compareTo(row8Struct other) {

			int returnValue = -1;

			returnValue = checkNullsAndCompare(this.id, other.id);
			if (returnValue != 0) {
				return returnValue;
			}

			return returnValue;
		}

		private int checkNullsAndCompare(Object object1, Object object2) {
			int returnValue = 0;
			if (object1 instanceof Comparable && object2 instanceof Comparable) {
				returnValue = ((Comparable) object1).compareTo(object2);
			} else if (object1 != null && object2 != null) {
				returnValue = compareStrings(object1.toString(), object2.toString());
			} else if (object1 == null && object2 != null) {
				returnValue = 1;
			} else if (object1 != null && object2 == null) {
				returnValue = -1;
			} else {
				returnValue = 0;
			}

			return returnValue;
		}

		private int compareStrings(String string1, String string2) {
			return string1.compareTo(string2);
		}

	}

	public static class movieJointStruct implements routines.system.IPersistableRow<movieJointStruct> {
		final static byte[] commonByteArrayLock_MYFIRSTJOB_TP_MAJ = new byte[0];
		static byte[] commonByteArray_MYFIRSTJOB_TP_MAJ = new byte[0];
		protected static final int DEFAULT_HASHCODE = 1;
		protected static final int PRIME = 31;
		protected int hashCode = DEFAULT_HASHCODE;
		public boolean hashCodeDirty = true;

		public String loopKey;

		public Integer id;

		public Integer getId() {
			return this.id;
		}

		public String title;

		public String getTitle() {
			return this.title;
		}

		public java.util.Date date;

		public java.util.Date getDate() {
			return this.date;
		}

		public Float popularity;

		public Float getPopularity() {
			return this.popularity;
		}

		public Integer vote_count;

		public Integer getVote_count() {
			return this.vote_count;
		}

		public Float vote_average;

		public Float getVote_average() {
			return this.vote_average;
		}

		public Integer budget;

		public Integer getBudget() {
			return this.budget;
		}

		public Long revenue;

		public Long getRevenue() {
			return this.revenue;
		}

		@Override
		public int hashCode() {
			if (this.hashCodeDirty) {
				final int prime = PRIME;
				int result = DEFAULT_HASHCODE;

				result = prime * result + ((this.id == null) ? 0 : this.id.hashCode());

				this.hashCode = result;
				this.hashCodeDirty = false;
			}
			return this.hashCode;
		}

		@Override
		public boolean equals(Object obj) {
			if (this == obj)
				return true;
			if (obj == null)
				return false;
			if (getClass() != obj.getClass())
				return false;
			final movieJointStruct other = (movieJointStruct) obj;

			if (this.id == null) {
				if (other.id != null)
					return false;

			} else if (!this.id.equals(other.id))

				return false;

			return true;
		}

		public void copyDataTo(movieJointStruct other) {

			other.id = this.id;
			other.title = this.title;
			other.date = this.date;
			other.popularity = this.popularity;
			other.vote_count = this.vote_count;
			other.vote_average = this.vote_average;
			other.budget = this.budget;
			other.revenue = this.revenue;

		}

		public void copyKeysDataTo(movieJointStruct other) {

			other.id = this.id;

		}

		private Integer readInteger(ObjectInputStream dis) throws IOException {
			Integer intReturn;
			int length = 0;
			length = dis.readByte();
			if (length == -1) {
				intReturn = null;
			} else {
				intReturn = dis.readInt();
			}
			return intReturn;
		}

		private Integer readInteger(org.jboss.marshalling.Unmarshaller dis) throws IOException {
			Integer intReturn;
			int length = 0;
			length = dis.readByte();
			if (length == -1) {
				intReturn = null;
			} else {
				intReturn = dis.readInt();
			}
			return intReturn;
		}

		private void writeInteger(Integer intNum, ObjectOutputStream dos) throws IOException {
			if (intNum == null) {
				dos.writeByte(-1);
			} else {
				dos.writeByte(0);
				dos.writeInt(intNum);
			}
		}

		private void writeInteger(Integer intNum, org.jboss.marshalling.Marshaller marshaller) throws IOException {
			if (intNum == null) {
				marshaller.writeByte(-1);
			} else {
				marshaller.writeByte(0);
				marshaller.writeInt(intNum);
			}
		}

		private String readString(ObjectInputStream dis) throws IOException {
			String strReturn = null;
			int length = 0;
			length = dis.readInt();
			if (length == -1) {
				strReturn = null;
			} else {
				if (length > commonByteArray_MYFIRSTJOB_TP_MAJ.length) {
					if (length < 1024 && commonByteArray_MYFIRSTJOB_TP_MAJ.length == 0) {
						commonByteArray_MYFIRSTJOB_TP_MAJ = new byte[1024];
					} else {
						commonByteArray_MYFIRSTJOB_TP_MAJ = new byte[2 * length];
					}
				}
				dis.readFully(commonByteArray_MYFIRSTJOB_TP_MAJ, 0, length);
				strReturn = new String(commonByteArray_MYFIRSTJOB_TP_MAJ, 0, length, utf8Charset);
			}
			return strReturn;
		}

		private String readString(org.jboss.marshalling.Unmarshaller unmarshaller) throws IOException {
			String strReturn = null;
			int length = 0;
			length = unmarshaller.readInt();
			if (length == -1) {
				strReturn = null;
			} else {
				if (length > commonByteArray_MYFIRSTJOB_TP_MAJ.length) {
					if (length < 1024 && commonByteArray_MYFIRSTJOB_TP_MAJ.length == 0) {
						commonByteArray_MYFIRSTJOB_TP_MAJ = new byte[1024];
					} else {
						commonByteArray_MYFIRSTJOB_TP_MAJ = new byte[2 * length];
					}
				}
				unmarshaller.readFully(commonByteArray_MYFIRSTJOB_TP_MAJ, 0, length);
				strReturn = new String(commonByteArray_MYFIRSTJOB_TP_MAJ, 0, length, utf8Charset);
			}
			return strReturn;
		}

		private void writeString(String str, ObjectOutputStream dos) throws IOException {
			if (str == null) {
				dos.writeInt(-1);
			} else {
				byte[] byteArray = str.getBytes(utf8Charset);
				dos.writeInt(byteArray.length);
				dos.write(byteArray);
			}
		}

		private void writeString(String str, org.jboss.marshalling.Marshaller marshaller) throws IOException {
			if (str == null) {
				marshaller.writeInt(-1);
			} else {
				byte[] byteArray = str.getBytes(utf8Charset);
				marshaller.writeInt(byteArray.length);
				marshaller.write(byteArray);
			}
		}

		private java.util.Date readDate(ObjectInputStream dis) throws IOException {
			java.util.Date dateReturn = null;
			int length = 0;
			length = dis.readByte();
			if (length == -1) {
				dateReturn = null;
			} else {
				dateReturn = new Date(dis.readLong());
			}
			return dateReturn;
		}

		private java.util.Date readDate(org.jboss.marshalling.Unmarshaller unmarshaller) throws IOException {
			java.util.Date dateReturn = null;
			int length = 0;
			length = unmarshaller.readByte();
			if (length == -1) {
				dateReturn = null;
			} else {
				dateReturn = new Date(unmarshaller.readLong());
			}
			return dateReturn;
		}

		private void writeDate(java.util.Date date1, ObjectOutputStream dos) throws IOException {
			if (date1 == null) {
				dos.writeByte(-1);
			} else {
				dos.writeByte(0);
				dos.writeLong(date1.getTime());
			}
		}

		private void writeDate(java.util.Date date1, org.jboss.marshalling.Marshaller marshaller) throws IOException {
			if (date1 == null) {
				marshaller.writeByte(-1);
			} else {
				marshaller.writeByte(0);
				marshaller.writeLong(date1.getTime());
			}
		}

		public void readData(ObjectInputStream dis) {

			synchronized (commonByteArrayLock_MYFIRSTJOB_TP_MAJ) {

				try {

					int length = 0;

					this.id = readInteger(dis);

					this.title = readString(dis);

					this.date = readDate(dis);

					length = dis.readByte();
					if (length == -1) {
						this.popularity = null;
					} else {
						this.popularity = dis.readFloat();
					}

					this.vote_count = readInteger(dis);

					length = dis.readByte();
					if (length == -1) {
						this.vote_average = null;
					} else {
						this.vote_average = dis.readFloat();
					}

					this.budget = readInteger(dis);

					length = dis.readByte();
					if (length == -1) {
						this.revenue = null;
					} else {
						this.revenue = dis.readLong();
					}

				} catch (IOException e) {
					throw new RuntimeException(e);

				}

			}

		}

		public void readData(org.jboss.marshalling.Unmarshaller dis) {

			synchronized (commonByteArrayLock_MYFIRSTJOB_TP_MAJ) {

				try {

					int length = 0;

					this.id = readInteger(dis);

					this.title = readString(dis);

					this.date = readDate(dis);

					length = dis.readByte();
					if (length == -1) {
						this.popularity = null;
					} else {
						this.popularity = dis.readFloat();
					}

					this.vote_count = readInteger(dis);

					length = dis.readByte();
					if (length == -1) {
						this.vote_average = null;
					} else {
						this.vote_average = dis.readFloat();
					}

					this.budget = readInteger(dis);

					length = dis.readByte();
					if (length == -1) {
						this.revenue = null;
					} else {
						this.revenue = dis.readLong();
					}

				} catch (IOException e) {
					throw new RuntimeException(e);

				}

			}

		}

		public void writeData(ObjectOutputStream dos) {
			try {

				// Integer

				writeInteger(this.id, dos);

				// String

				writeString(this.title, dos);

				// java.util.Date

				writeDate(this.date, dos);

				// Float

				if (this.popularity == null) {
					dos.writeByte(-1);
				} else {
					dos.writeByte(0);
					dos.writeFloat(this.popularity);
				}

				// Integer

				writeInteger(this.vote_count, dos);

				// Float

				if (this.vote_average == null) {
					dos.writeByte(-1);
				} else {
					dos.writeByte(0);
					dos.writeFloat(this.vote_average);
				}

				// Integer

				writeInteger(this.budget, dos);

				// Long

				if (this.revenue == null) {
					dos.writeByte(-1);
				} else {
					dos.writeByte(0);
					dos.writeLong(this.revenue);
				}

			} catch (IOException e) {
				throw new RuntimeException(e);
			}

		}

		public void writeData(org.jboss.marshalling.Marshaller dos) {
			try {

				// Integer

				writeInteger(this.id, dos);

				// String

				writeString(this.title, dos);

				// java.util.Date

				writeDate(this.date, dos);

				// Float

				if (this.popularity == null) {
					dos.writeByte(-1);
				} else {
					dos.writeByte(0);
					dos.writeFloat(this.popularity);
				}

				// Integer

				writeInteger(this.vote_count, dos);

				// Float

				if (this.vote_average == null) {
					dos.writeByte(-1);
				} else {
					dos.writeByte(0);
					dos.writeFloat(this.vote_average);
				}

				// Integer

				writeInteger(this.budget, dos);

				// Long

				if (this.revenue == null) {
					dos.writeByte(-1);
				} else {
					dos.writeByte(0);
					dos.writeLong(this.revenue);
				}

			} catch (IOException e) {
				throw new RuntimeException(e);
			}

		}

		public String toString() {

			StringBuilder sb = new StringBuilder();
			sb.append(super.toString());
			sb.append("[");
			sb.append("id=" + String.valueOf(id));
			sb.append(",title=" + title);
			sb.append(",date=" + String.valueOf(date));
			sb.append(",popularity=" + String.valueOf(popularity));
			sb.append(",vote_count=" + String.valueOf(vote_count));
			sb.append(",vote_average=" + String.valueOf(vote_average));
			sb.append(",budget=" + String.valueOf(budget));
			sb.append(",revenue=" + String.valueOf(revenue));
			sb.append("]");

			return sb.toString();
		}

		/**
		 * Compare keys
		 */
		public int compareTo(movieJointStruct other) {

			int returnValue = -1;

			returnValue = checkNullsAndCompare(this.id, other.id);
			if (returnValue != 0) {
				return returnValue;
			}

			return returnValue;
		}

		private int checkNullsAndCompare(Object object1, Object object2) {
			int returnValue = 0;
			if (object1 instanceof Comparable && object2 instanceof Comparable) {
				returnValue = ((Comparable) object1).compareTo(object2);
			} else if (object1 != null && object2 != null) {
				returnValue = compareStrings(object1.toString(), object2.toString());
			} else if (object1 == null && object2 != null) {
				returnValue = 1;
			} else if (object1 != null && object2 == null) {
				returnValue = -1;
			} else {
				returnValue = 0;
			}

			return returnValue;
		}

		private int compareStrings(String string1, String string2) {
			return string1.compareTo(string2);
		}

	}

	public static class row7Struct implements routines.system.IPersistableRow<row7Struct> {
		final static byte[] commonByteArrayLock_MYFIRSTJOB_TP_MAJ = new byte[0];
		static byte[] commonByteArray_MYFIRSTJOB_TP_MAJ = new byte[0];

		public Integer id;

		public Integer getId() {
			return this.id;
		}

		public String title;

		public String getTitle() {
			return this.title;
		}

		public java.util.Date date;

		public java.util.Date getDate() {
			return this.date;
		}

		private Integer readInteger(ObjectInputStream dis) throws IOException {
			Integer intReturn;
			int length = 0;
			length = dis.readByte();
			if (length == -1) {
				intReturn = null;
			} else {
				intReturn = dis.readInt();
			}
			return intReturn;
		}

		private Integer readInteger(org.jboss.marshalling.Unmarshaller dis) throws IOException {
			Integer intReturn;
			int length = 0;
			length = dis.readByte();
			if (length == -1) {
				intReturn = null;
			} else {
				intReturn = dis.readInt();
			}
			return intReturn;
		}

		private void writeInteger(Integer intNum, ObjectOutputStream dos) throws IOException {
			if (intNum == null) {
				dos.writeByte(-1);
			} else {
				dos.writeByte(0);
				dos.writeInt(intNum);
			}
		}

		private void writeInteger(Integer intNum, org.jboss.marshalling.Marshaller marshaller) throws IOException {
			if (intNum == null) {
				marshaller.writeByte(-1);
			} else {
				marshaller.writeByte(0);
				marshaller.writeInt(intNum);
			}
		}

		private String readString(ObjectInputStream dis) throws IOException {
			String strReturn = null;
			int length = 0;
			length = dis.readInt();
			if (length == -1) {
				strReturn = null;
			} else {
				if (length > commonByteArray_MYFIRSTJOB_TP_MAJ.length) {
					if (length < 1024 && commonByteArray_MYFIRSTJOB_TP_MAJ.length == 0) {
						commonByteArray_MYFIRSTJOB_TP_MAJ = new byte[1024];
					} else {
						commonByteArray_MYFIRSTJOB_TP_MAJ = new byte[2 * length];
					}
				}
				dis.readFully(commonByteArray_MYFIRSTJOB_TP_MAJ, 0, length);
				strReturn = new String(commonByteArray_MYFIRSTJOB_TP_MAJ, 0, length, utf8Charset);
			}
			return strReturn;
		}

		private String readString(org.jboss.marshalling.Unmarshaller unmarshaller) throws IOException {
			String strReturn = null;
			int length = 0;
			length = unmarshaller.readInt();
			if (length == -1) {
				strReturn = null;
			} else {
				if (length > commonByteArray_MYFIRSTJOB_TP_MAJ.length) {
					if (length < 1024 && commonByteArray_MYFIRSTJOB_TP_MAJ.length == 0) {
						commonByteArray_MYFIRSTJOB_TP_MAJ = new byte[1024];
					} else {
						commonByteArray_MYFIRSTJOB_TP_MAJ = new byte[2 * length];
					}
				}
				unmarshaller.readFully(commonByteArray_MYFIRSTJOB_TP_MAJ, 0, length);
				strReturn = new String(commonByteArray_MYFIRSTJOB_TP_MAJ, 0, length, utf8Charset);
			}
			return strReturn;
		}

		private void writeString(String str, ObjectOutputStream dos) throws IOException {
			if (str == null) {
				dos.writeInt(-1);
			} else {
				byte[] byteArray = str.getBytes(utf8Charset);
				dos.writeInt(byteArray.length);
				dos.write(byteArray);
			}
		}

		private void writeString(String str, org.jboss.marshalling.Marshaller marshaller) throws IOException {
			if (str == null) {
				marshaller.writeInt(-1);
			} else {
				byte[] byteArray = str.getBytes(utf8Charset);
				marshaller.writeInt(byteArray.length);
				marshaller.write(byteArray);
			}
		}

		private java.util.Date readDate(ObjectInputStream dis) throws IOException {
			java.util.Date dateReturn = null;
			int length = 0;
			length = dis.readByte();
			if (length == -1) {
				dateReturn = null;
			} else {
				dateReturn = new Date(dis.readLong());
			}
			return dateReturn;
		}

		private java.util.Date readDate(org.jboss.marshalling.Unmarshaller unmarshaller) throws IOException {
			java.util.Date dateReturn = null;
			int length = 0;
			length = unmarshaller.readByte();
			if (length == -1) {
				dateReturn = null;
			} else {
				dateReturn = new Date(unmarshaller.readLong());
			}
			return dateReturn;
		}

		private void writeDate(java.util.Date date1, ObjectOutputStream dos) throws IOException {
			if (date1 == null) {
				dos.writeByte(-1);
			} else {
				dos.writeByte(0);
				dos.writeLong(date1.getTime());
			}
		}

		private void writeDate(java.util.Date date1, org.jboss.marshalling.Marshaller marshaller) throws IOException {
			if (date1 == null) {
				marshaller.writeByte(-1);
			} else {
				marshaller.writeByte(0);
				marshaller.writeLong(date1.getTime());
			}
		}

		public void readData(ObjectInputStream dis) {

			synchronized (commonByteArrayLock_MYFIRSTJOB_TP_MAJ) {

				try {

					int length = 0;

					this.id = readInteger(dis);

					this.title = readString(dis);

					this.date = readDate(dis);

				} catch (IOException e) {
					throw new RuntimeException(e);

				}

			}

		}

		public void readData(org.jboss.marshalling.Unmarshaller dis) {

			synchronized (commonByteArrayLock_MYFIRSTJOB_TP_MAJ) {

				try {

					int length = 0;

					this.id = readInteger(dis);

					this.title = readString(dis);

					this.date = readDate(dis);

				} catch (IOException e) {
					throw new RuntimeException(e);

				}

			}

		}

		public void writeData(ObjectOutputStream dos) {
			try {

				// Integer

				writeInteger(this.id, dos);

				// String

				writeString(this.title, dos);

				// java.util.Date

				writeDate(this.date, dos);

			} catch (IOException e) {
				throw new RuntimeException(e);
			}

		}

		public void writeData(org.jboss.marshalling.Marshaller dos) {
			try {

				// Integer

				writeInteger(this.id, dos);

				// String

				writeString(this.title, dos);

				// java.util.Date

				writeDate(this.date, dos);

			} catch (IOException e) {
				throw new RuntimeException(e);
			}

		}

		public String toString() {

			StringBuilder sb = new StringBuilder();
			sb.append(super.toString());
			sb.append("[");
			sb.append("id=" + String.valueOf(id));
			sb.append(",title=" + title);
			sb.append(",date=" + String.valueOf(date));
			sb.append("]");

			return sb.toString();
		}

		/**
		 * Compare keys
		 */
		public int compareTo(row7Struct other) {

			int returnValue = -1;

			return returnValue;
		}

		private int checkNullsAndCompare(Object object1, Object object2) {
			int returnValue = 0;
			if (object1 instanceof Comparable && object2 instanceof Comparable) {
				returnValue = ((Comparable) object1).compareTo(object2);
			} else if (object1 != null && object2 != null) {
				returnValue = compareStrings(object1.toString(), object2.toString());
			} else if (object1 == null && object2 != null) {
				returnValue = 1;
			} else if (object1 != null && object2 == null) {
				returnValue = -1;
			} else {
				returnValue = 0;
			}

			return returnValue;
		}

		private int compareStrings(String string1, String string2) {
			return string1.compareTo(string2);
		}

	}

	public static class row5Struct implements routines.system.IPersistableRow<row5Struct> {
		final static byte[] commonByteArrayLock_MYFIRSTJOB_TP_MAJ = new byte[0];
		static byte[] commonByteArray_MYFIRSTJOB_TP_MAJ = new byte[0];
		protected static final int DEFAULT_HASHCODE = 1;
		protected static final int PRIME = 31;
		protected int hashCode = DEFAULT_HASHCODE;
		public boolean hashCodeDirty = true;

		public String loopKey;

		public Integer id;

		public Integer getId() {
			return this.id;
		}

		public String title;

		public String getTitle() {
			return this.title;
		}

		public Integer C;

		public Integer getC() {
			return this.C;
		}

		public String D;

		public String getD() {
			return this.D;
		}

		public String E;

		public String getE() {
			return this.E;
		}

		public String F;

		public String getF() {
			return this.F;
		}

		public java.util.Date date;

		public java.util.Date getDate() {
			return this.date;
		}

		@Override
		public int hashCode() {
			if (this.hashCodeDirty) {
				final int prime = PRIME;
				int result = DEFAULT_HASHCODE;

				result = prime * result + ((this.id == null) ? 0 : this.id.hashCode());

				this.hashCode = result;
				this.hashCodeDirty = false;
			}
			return this.hashCode;
		}

		@Override
		public boolean equals(Object obj) {
			if (this == obj)
				return true;
			if (obj == null)
				return false;
			if (getClass() != obj.getClass())
				return false;
			final row5Struct other = (row5Struct) obj;

			if (this.id == null) {
				if (other.id != null)
					return false;

			} else if (!this.id.equals(other.id))

				return false;

			return true;
		}

		public void copyDataTo(row5Struct other) {

			other.id = this.id;
			other.title = this.title;
			other.C = this.C;
			other.D = this.D;
			other.E = this.E;
			other.F = this.F;
			other.date = this.date;

		}

		public void copyKeysDataTo(row5Struct other) {

			other.id = this.id;

		}

		private Integer readInteger(ObjectInputStream dis) throws IOException {
			Integer intReturn;
			int length = 0;
			length = dis.readByte();
			if (length == -1) {
				intReturn = null;
			} else {
				intReturn = dis.readInt();
			}
			return intReturn;
		}

		private Integer readInteger(org.jboss.marshalling.Unmarshaller dis) throws IOException {
			Integer intReturn;
			int length = 0;
			length = dis.readByte();
			if (length == -1) {
				intReturn = null;
			} else {
				intReturn = dis.readInt();
			}
			return intReturn;
		}

		private void writeInteger(Integer intNum, ObjectOutputStream dos) throws IOException {
			if (intNum == null) {
				dos.writeByte(-1);
			} else {
				dos.writeByte(0);
				dos.writeInt(intNum);
			}
		}

		private void writeInteger(Integer intNum, org.jboss.marshalling.Marshaller marshaller) throws IOException {
			if (intNum == null) {
				marshaller.writeByte(-1);
			} else {
				marshaller.writeByte(0);
				marshaller.writeInt(intNum);
			}
		}

		private String readString(ObjectInputStream dis) throws IOException {
			String strReturn = null;
			int length = 0;
			length = dis.readInt();
			if (length == -1) {
				strReturn = null;
			} else {
				if (length > commonByteArray_MYFIRSTJOB_TP_MAJ.length) {
					if (length < 1024 && commonByteArray_MYFIRSTJOB_TP_MAJ.length == 0) {
						commonByteArray_MYFIRSTJOB_TP_MAJ = new byte[1024];
					} else {
						commonByteArray_MYFIRSTJOB_TP_MAJ = new byte[2 * length];
					}
				}
				dis.readFully(commonByteArray_MYFIRSTJOB_TP_MAJ, 0, length);
				strReturn = new String(commonByteArray_MYFIRSTJOB_TP_MAJ, 0, length, utf8Charset);
			}
			return strReturn;
		}

		private String readString(org.jboss.marshalling.Unmarshaller unmarshaller) throws IOException {
			String strReturn = null;
			int length = 0;
			length = unmarshaller.readInt();
			if (length == -1) {
				strReturn = null;
			} else {
				if (length > commonByteArray_MYFIRSTJOB_TP_MAJ.length) {
					if (length < 1024 && commonByteArray_MYFIRSTJOB_TP_MAJ.length == 0) {
						commonByteArray_MYFIRSTJOB_TP_MAJ = new byte[1024];
					} else {
						commonByteArray_MYFIRSTJOB_TP_MAJ = new byte[2 * length];
					}
				}
				unmarshaller.readFully(commonByteArray_MYFIRSTJOB_TP_MAJ, 0, length);
				strReturn = new String(commonByteArray_MYFIRSTJOB_TP_MAJ, 0, length, utf8Charset);
			}
			return strReturn;
		}

		private void writeString(String str, ObjectOutputStream dos) throws IOException {
			if (str == null) {
				dos.writeInt(-1);
			} else {
				byte[] byteArray = str.getBytes(utf8Charset);
				dos.writeInt(byteArray.length);
				dos.write(byteArray);
			}
		}

		private void writeString(String str, org.jboss.marshalling.Marshaller marshaller) throws IOException {
			if (str == null) {
				marshaller.writeInt(-1);
			} else {
				byte[] byteArray = str.getBytes(utf8Charset);
				marshaller.writeInt(byteArray.length);
				marshaller.write(byteArray);
			}
		}

		private java.util.Date readDate(ObjectInputStream dis) throws IOException {
			java.util.Date dateReturn = null;
			int length = 0;
			length = dis.readByte();
			if (length == -1) {
				dateReturn = null;
			} else {
				dateReturn = new Date(dis.readLong());
			}
			return dateReturn;
		}

		private java.util.Date readDate(org.jboss.marshalling.Unmarshaller unmarshaller) throws IOException {
			java.util.Date dateReturn = null;
			int length = 0;
			length = unmarshaller.readByte();
			if (length == -1) {
				dateReturn = null;
			} else {
				dateReturn = new Date(unmarshaller.readLong());
			}
			return dateReturn;
		}

		private void writeDate(java.util.Date date1, ObjectOutputStream dos) throws IOException {
			if (date1 == null) {
				dos.writeByte(-1);
			} else {
				dos.writeByte(0);
				dos.writeLong(date1.getTime());
			}
		}

		private void writeDate(java.util.Date date1, org.jboss.marshalling.Marshaller marshaller) throws IOException {
			if (date1 == null) {
				marshaller.writeByte(-1);
			} else {
				marshaller.writeByte(0);
				marshaller.writeLong(date1.getTime());
			}
		}

		public void readData(ObjectInputStream dis) {

			synchronized (commonByteArrayLock_MYFIRSTJOB_TP_MAJ) {

				try {

					int length = 0;

					this.id = readInteger(dis);

					this.title = readString(dis);

					this.C = readInteger(dis);

					this.D = readString(dis);

					this.E = readString(dis);

					this.F = readString(dis);

					this.date = readDate(dis);

				} catch (IOException e) {
					throw new RuntimeException(e);

				}

			}

		}

		public void readData(org.jboss.marshalling.Unmarshaller dis) {

			synchronized (commonByteArrayLock_MYFIRSTJOB_TP_MAJ) {

				try {

					int length = 0;

					this.id = readInteger(dis);

					this.title = readString(dis);

					this.C = readInteger(dis);

					this.D = readString(dis);

					this.E = readString(dis);

					this.F = readString(dis);

					this.date = readDate(dis);

				} catch (IOException e) {
					throw new RuntimeException(e);

				}

			}

		}

		public void writeData(ObjectOutputStream dos) {
			try {

				// Integer

				writeInteger(this.id, dos);

				// String

				writeString(this.title, dos);

				// Integer

				writeInteger(this.C, dos);

				// String

				writeString(this.D, dos);

				// String

				writeString(this.E, dos);

				// String

				writeString(this.F, dos);

				// java.util.Date

				writeDate(this.date, dos);

			} catch (IOException e) {
				throw new RuntimeException(e);
			}

		}

		public void writeData(org.jboss.marshalling.Marshaller dos) {
			try {

				// Integer

				writeInteger(this.id, dos);

				// String

				writeString(this.title, dos);

				// Integer

				writeInteger(this.C, dos);

				// String

				writeString(this.D, dos);

				// String

				writeString(this.E, dos);

				// String

				writeString(this.F, dos);

				// java.util.Date

				writeDate(this.date, dos);

			} catch (IOException e) {
				throw new RuntimeException(e);
			}

		}

		public String toString() {

			StringBuilder sb = new StringBuilder();
			sb.append(super.toString());
			sb.append("[");
			sb.append("id=" + String.valueOf(id));
			sb.append(",title=" + title);
			sb.append(",C=" + String.valueOf(C));
			sb.append(",D=" + D);
			sb.append(",E=" + E);
			sb.append(",F=" + F);
			sb.append(",date=" + String.valueOf(date));
			sb.append("]");

			return sb.toString();
		}

		/**
		 * Compare keys
		 */
		public int compareTo(row5Struct other) {

			int returnValue = -1;

			returnValue = checkNullsAndCompare(this.id, other.id);
			if (returnValue != 0) {
				return returnValue;
			}

			return returnValue;
		}

		private int checkNullsAndCompare(Object object1, Object object2) {
			int returnValue = 0;
			if (object1 instanceof Comparable && object2 instanceof Comparable) {
				returnValue = ((Comparable) object1).compareTo(object2);
			} else if (object1 != null && object2 != null) {
				returnValue = compareStrings(object1.toString(), object2.toString());
			} else if (object1 == null && object2 != null) {
				returnValue = 1;
			} else if (object1 != null && object2 == null) {
				returnValue = -1;
			} else {
				returnValue = 0;
			}

			return returnValue;
		}

		private int compareStrings(String string1, String string2) {
			return string1.compareTo(string2);
		}

	}

	public static class row3Struct implements routines.system.IPersistableRow<row3Struct> {
		final static byte[] commonByteArrayLock_MYFIRSTJOB_TP_MAJ = new byte[0];
		static byte[] commonByteArray_MYFIRSTJOB_TP_MAJ = new byte[0];
		protected static final int DEFAULT_HASHCODE = 1;
		protected static final int PRIME = 31;
		protected int hashCode = DEFAULT_HASHCODE;
		public boolean hashCodeDirty = true;

		public String loopKey;

		public Integer id;

		public Integer getId() {
			return this.id;
		}

		public String title;

		public String getTitle() {
			return this.title;
		}

		public Integer C;

		public Integer getC() {
			return this.C;
		}

		public String D;

		public String getD() {
			return this.D;
		}

		public String E;

		public String getE() {
			return this.E;
		}

		public String F;

		public String getF() {
			return this.F;
		}

		public java.util.Date date;

		public java.util.Date getDate() {
			return this.date;
		}

		@Override
		public int hashCode() {
			if (this.hashCodeDirty) {
				final int prime = PRIME;
				int result = DEFAULT_HASHCODE;

				result = prime * result + ((this.id == null) ? 0 : this.id.hashCode());

				this.hashCode = result;
				this.hashCodeDirty = false;
			}
			return this.hashCode;
		}

		@Override
		public boolean equals(Object obj) {
			if (this == obj)
				return true;
			if (obj == null)
				return false;
			if (getClass() != obj.getClass())
				return false;
			final row3Struct other = (row3Struct) obj;

			if (this.id == null) {
				if (other.id != null)
					return false;

			} else if (!this.id.equals(other.id))

				return false;

			return true;
		}

		public void copyDataTo(row3Struct other) {

			other.id = this.id;
			other.title = this.title;
			other.C = this.C;
			other.D = this.D;
			other.E = this.E;
			other.F = this.F;
			other.date = this.date;

		}

		public void copyKeysDataTo(row3Struct other) {

			other.id = this.id;

		}

		private Integer readInteger(ObjectInputStream dis) throws IOException {
			Integer intReturn;
			int length = 0;
			length = dis.readByte();
			if (length == -1) {
				intReturn = null;
			} else {
				intReturn = dis.readInt();
			}
			return intReturn;
		}

		private Integer readInteger(org.jboss.marshalling.Unmarshaller dis) throws IOException {
			Integer intReturn;
			int length = 0;
			length = dis.readByte();
			if (length == -1) {
				intReturn = null;
			} else {
				intReturn = dis.readInt();
			}
			return intReturn;
		}

		private void writeInteger(Integer intNum, ObjectOutputStream dos) throws IOException {
			if (intNum == null) {
				dos.writeByte(-1);
			} else {
				dos.writeByte(0);
				dos.writeInt(intNum);
			}
		}

		private void writeInteger(Integer intNum, org.jboss.marshalling.Marshaller marshaller) throws IOException {
			if (intNum == null) {
				marshaller.writeByte(-1);
			} else {
				marshaller.writeByte(0);
				marshaller.writeInt(intNum);
			}
		}

		private String readString(ObjectInputStream dis) throws IOException {
			String strReturn = null;
			int length = 0;
			length = dis.readInt();
			if (length == -1) {
				strReturn = null;
			} else {
				if (length > commonByteArray_MYFIRSTJOB_TP_MAJ.length) {
					if (length < 1024 && commonByteArray_MYFIRSTJOB_TP_MAJ.length == 0) {
						commonByteArray_MYFIRSTJOB_TP_MAJ = new byte[1024];
					} else {
						commonByteArray_MYFIRSTJOB_TP_MAJ = new byte[2 * length];
					}
				}
				dis.readFully(commonByteArray_MYFIRSTJOB_TP_MAJ, 0, length);
				strReturn = new String(commonByteArray_MYFIRSTJOB_TP_MAJ, 0, length, utf8Charset);
			}
			return strReturn;
		}

		private String readString(org.jboss.marshalling.Unmarshaller unmarshaller) throws IOException {
			String strReturn = null;
			int length = 0;
			length = unmarshaller.readInt();
			if (length == -1) {
				strReturn = null;
			} else {
				if (length > commonByteArray_MYFIRSTJOB_TP_MAJ.length) {
					if (length < 1024 && commonByteArray_MYFIRSTJOB_TP_MAJ.length == 0) {
						commonByteArray_MYFIRSTJOB_TP_MAJ = new byte[1024];
					} else {
						commonByteArray_MYFIRSTJOB_TP_MAJ = new byte[2 * length];
					}
				}
				unmarshaller.readFully(commonByteArray_MYFIRSTJOB_TP_MAJ, 0, length);
				strReturn = new String(commonByteArray_MYFIRSTJOB_TP_MAJ, 0, length, utf8Charset);
			}
			return strReturn;
		}

		private void writeString(String str, ObjectOutputStream dos) throws IOException {
			if (str == null) {
				dos.writeInt(-1);
			} else {
				byte[] byteArray = str.getBytes(utf8Charset);
				dos.writeInt(byteArray.length);
				dos.write(byteArray);
			}
		}

		private void writeString(String str, org.jboss.marshalling.Marshaller marshaller) throws IOException {
			if (str == null) {
				marshaller.writeInt(-1);
			} else {
				byte[] byteArray = str.getBytes(utf8Charset);
				marshaller.writeInt(byteArray.length);
				marshaller.write(byteArray);
			}
		}

		private java.util.Date readDate(ObjectInputStream dis) throws IOException {
			java.util.Date dateReturn = null;
			int length = 0;
			length = dis.readByte();
			if (length == -1) {
				dateReturn = null;
			} else {
				dateReturn = new Date(dis.readLong());
			}
			return dateReturn;
		}

		private java.util.Date readDate(org.jboss.marshalling.Unmarshaller unmarshaller) throws IOException {
			java.util.Date dateReturn = null;
			int length = 0;
			length = unmarshaller.readByte();
			if (length == -1) {
				dateReturn = null;
			} else {
				dateReturn = new Date(unmarshaller.readLong());
			}
			return dateReturn;
		}

		private void writeDate(java.util.Date date1, ObjectOutputStream dos) throws IOException {
			if (date1 == null) {
				dos.writeByte(-1);
			} else {
				dos.writeByte(0);
				dos.writeLong(date1.getTime());
			}
		}

		private void writeDate(java.util.Date date1, org.jboss.marshalling.Marshaller marshaller) throws IOException {
			if (date1 == null) {
				marshaller.writeByte(-1);
			} else {
				marshaller.writeByte(0);
				marshaller.writeLong(date1.getTime());
			}
		}

		public void readData(ObjectInputStream dis) {

			synchronized (commonByteArrayLock_MYFIRSTJOB_TP_MAJ) {

				try {

					int length = 0;

					this.id = readInteger(dis);

					this.title = readString(dis);

					this.C = readInteger(dis);

					this.D = readString(dis);

					this.E = readString(dis);

					this.F = readString(dis);

					this.date = readDate(dis);

				} catch (IOException e) {
					throw new RuntimeException(e);

				}

			}

		}

		public void readData(org.jboss.marshalling.Unmarshaller dis) {

			synchronized (commonByteArrayLock_MYFIRSTJOB_TP_MAJ) {

				try {

					int length = 0;

					this.id = readInteger(dis);

					this.title = readString(dis);

					this.C = readInteger(dis);

					this.D = readString(dis);

					this.E = readString(dis);

					this.F = readString(dis);

					this.date = readDate(dis);

				} catch (IOException e) {
					throw new RuntimeException(e);

				}

			}

		}

		public void writeData(ObjectOutputStream dos) {
			try {

				// Integer

				writeInteger(this.id, dos);

				// String

				writeString(this.title, dos);

				// Integer

				writeInteger(this.C, dos);

				// String

				writeString(this.D, dos);

				// String

				writeString(this.E, dos);

				// String

				writeString(this.F, dos);

				// java.util.Date

				writeDate(this.date, dos);

			} catch (IOException e) {
				throw new RuntimeException(e);
			}

		}

		public void writeData(org.jboss.marshalling.Marshaller dos) {
			try {

				// Integer

				writeInteger(this.id, dos);

				// String

				writeString(this.title, dos);

				// Integer

				writeInteger(this.C, dos);

				// String

				writeString(this.D, dos);

				// String

				writeString(this.E, dos);

				// String

				writeString(this.F, dos);

				// java.util.Date

				writeDate(this.date, dos);

			} catch (IOException e) {
				throw new RuntimeException(e);
			}

		}

		public String toString() {

			StringBuilder sb = new StringBuilder();
			sb.append(super.toString());
			sb.append("[");
			sb.append("id=" + String.valueOf(id));
			sb.append(",title=" + title);
			sb.append(",C=" + String.valueOf(C));
			sb.append(",D=" + D);
			sb.append(",E=" + E);
			sb.append(",F=" + F);
			sb.append(",date=" + String.valueOf(date));
			sb.append("]");

			return sb.toString();
		}

		/**
		 * Compare keys
		 */
		public int compareTo(row3Struct other) {

			int returnValue = -1;

			returnValue = checkNullsAndCompare(this.id, other.id);
			if (returnValue != 0) {
				return returnValue;
			}

			return returnValue;
		}

		private int checkNullsAndCompare(Object object1, Object object2) {
			int returnValue = 0;
			if (object1 instanceof Comparable && object2 instanceof Comparable) {
				returnValue = ((Comparable) object1).compareTo(object2);
			} else if (object1 != null && object2 != null) {
				returnValue = compareStrings(object1.toString(), object2.toString());
			} else if (object1 == null && object2 != null) {
				returnValue = 1;
			} else if (object1 != null && object2 == null) {
				returnValue = -1;
			} else {
				returnValue = 0;
			}

			return returnValue;
		}

		private int compareStrings(String string1, String string2) {
			return string1.compareTo(string2);
		}

	}

	public static class after_tFileInputExcel_1Struct
			implements routines.system.IPersistableRow<after_tFileInputExcel_1Struct> {
		final static byte[] commonByteArrayLock_MYFIRSTJOB_TP_MAJ = new byte[0];
		static byte[] commonByteArray_MYFIRSTJOB_TP_MAJ = new byte[0];
		protected static final int DEFAULT_HASHCODE = 1;
		protected static final int PRIME = 31;
		protected int hashCode = DEFAULT_HASHCODE;
		public boolean hashCodeDirty = true;

		public String loopKey;

		public Integer id;

		public Integer getId() {
			return this.id;
		}

		public String title;

		public String getTitle() {
			return this.title;
		}

		public Integer C;

		public Integer getC() {
			return this.C;
		}

		public String D;

		public String getD() {
			return this.D;
		}

		public String E;

		public String getE() {
			return this.E;
		}

		public String F;

		public String getF() {
			return this.F;
		}

		public java.util.Date date;

		public java.util.Date getDate() {
			return this.date;
		}

		@Override
		public int hashCode() {
			if (this.hashCodeDirty) {
				final int prime = PRIME;
				int result = DEFAULT_HASHCODE;

				result = prime * result + ((this.id == null) ? 0 : this.id.hashCode());

				this.hashCode = result;
				this.hashCodeDirty = false;
			}
			return this.hashCode;
		}

		@Override
		public boolean equals(Object obj) {
			if (this == obj)
				return true;
			if (obj == null)
				return false;
			if (getClass() != obj.getClass())
				return false;
			final after_tFileInputExcel_1Struct other = (after_tFileInputExcel_1Struct) obj;

			if (this.id == null) {
				if (other.id != null)
					return false;

			} else if (!this.id.equals(other.id))

				return false;

			return true;
		}

		public void copyDataTo(after_tFileInputExcel_1Struct other) {

			other.id = this.id;
			other.title = this.title;
			other.C = this.C;
			other.D = this.D;
			other.E = this.E;
			other.F = this.F;
			other.date = this.date;

		}

		public void copyKeysDataTo(after_tFileInputExcel_1Struct other) {

			other.id = this.id;

		}

		private Integer readInteger(ObjectInputStream dis) throws IOException {
			Integer intReturn;
			int length = 0;
			length = dis.readByte();
			if (length == -1) {
				intReturn = null;
			} else {
				intReturn = dis.readInt();
			}
			return intReturn;
		}

		private Integer readInteger(org.jboss.marshalling.Unmarshaller dis) throws IOException {
			Integer intReturn;
			int length = 0;
			length = dis.readByte();
			if (length == -1) {
				intReturn = null;
			} else {
				intReturn = dis.readInt();
			}
			return intReturn;
		}

		private void writeInteger(Integer intNum, ObjectOutputStream dos) throws IOException {
			if (intNum == null) {
				dos.writeByte(-1);
			} else {
				dos.writeByte(0);
				dos.writeInt(intNum);
			}
		}

		private void writeInteger(Integer intNum, org.jboss.marshalling.Marshaller marshaller) throws IOException {
			if (intNum == null) {
				marshaller.writeByte(-1);
			} else {
				marshaller.writeByte(0);
				marshaller.writeInt(intNum);
			}
		}

		private String readString(ObjectInputStream dis) throws IOException {
			String strReturn = null;
			int length = 0;
			length = dis.readInt();
			if (length == -1) {
				strReturn = null;
			} else {
				if (length > commonByteArray_MYFIRSTJOB_TP_MAJ.length) {
					if (length < 1024 && commonByteArray_MYFIRSTJOB_TP_MAJ.length == 0) {
						commonByteArray_MYFIRSTJOB_TP_MAJ = new byte[1024];
					} else {
						commonByteArray_MYFIRSTJOB_TP_MAJ = new byte[2 * length];
					}
				}
				dis.readFully(commonByteArray_MYFIRSTJOB_TP_MAJ, 0, length);
				strReturn = new String(commonByteArray_MYFIRSTJOB_TP_MAJ, 0, length, utf8Charset);
			}
			return strReturn;
		}

		private String readString(org.jboss.marshalling.Unmarshaller unmarshaller) throws IOException {
			String strReturn = null;
			int length = 0;
			length = unmarshaller.readInt();
			if (length == -1) {
				strReturn = null;
			} else {
				if (length > commonByteArray_MYFIRSTJOB_TP_MAJ.length) {
					if (length < 1024 && commonByteArray_MYFIRSTJOB_TP_MAJ.length == 0) {
						commonByteArray_MYFIRSTJOB_TP_MAJ = new byte[1024];
					} else {
						commonByteArray_MYFIRSTJOB_TP_MAJ = new byte[2 * length];
					}
				}
				unmarshaller.readFully(commonByteArray_MYFIRSTJOB_TP_MAJ, 0, length);
				strReturn = new String(commonByteArray_MYFIRSTJOB_TP_MAJ, 0, length, utf8Charset);
			}
			return strReturn;
		}

		private void writeString(String str, ObjectOutputStream dos) throws IOException {
			if (str == null) {
				dos.writeInt(-1);
			} else {
				byte[] byteArray = str.getBytes(utf8Charset);
				dos.writeInt(byteArray.length);
				dos.write(byteArray);
			}
		}

		private void writeString(String str, org.jboss.marshalling.Marshaller marshaller) throws IOException {
			if (str == null) {
				marshaller.writeInt(-1);
			} else {
				byte[] byteArray = str.getBytes(utf8Charset);
				marshaller.writeInt(byteArray.length);
				marshaller.write(byteArray);
			}
		}

		private java.util.Date readDate(ObjectInputStream dis) throws IOException {
			java.util.Date dateReturn = null;
			int length = 0;
			length = dis.readByte();
			if (length == -1) {
				dateReturn = null;
			} else {
				dateReturn = new Date(dis.readLong());
			}
			return dateReturn;
		}

		private java.util.Date readDate(org.jboss.marshalling.Unmarshaller unmarshaller) throws IOException {
			java.util.Date dateReturn = null;
			int length = 0;
			length = unmarshaller.readByte();
			if (length == -1) {
				dateReturn = null;
			} else {
				dateReturn = new Date(unmarshaller.readLong());
			}
			return dateReturn;
		}

		private void writeDate(java.util.Date date1, ObjectOutputStream dos) throws IOException {
			if (date1 == null) {
				dos.writeByte(-1);
			} else {
				dos.writeByte(0);
				dos.writeLong(date1.getTime());
			}
		}

		private void writeDate(java.util.Date date1, org.jboss.marshalling.Marshaller marshaller) throws IOException {
			if (date1 == null) {
				marshaller.writeByte(-1);
			} else {
				marshaller.writeByte(0);
				marshaller.writeLong(date1.getTime());
			}
		}

		public void readData(ObjectInputStream dis) {

			synchronized (commonByteArrayLock_MYFIRSTJOB_TP_MAJ) {

				try {

					int length = 0;

					this.id = readInteger(dis);

					this.title = readString(dis);

					this.C = readInteger(dis);

					this.D = readString(dis);

					this.E = readString(dis);

					this.F = readString(dis);

					this.date = readDate(dis);

				} catch (IOException e) {
					throw new RuntimeException(e);

				}

			}

		}

		public void readData(org.jboss.marshalling.Unmarshaller dis) {

			synchronized (commonByteArrayLock_MYFIRSTJOB_TP_MAJ) {

				try {

					int length = 0;

					this.id = readInteger(dis);

					this.title = readString(dis);

					this.C = readInteger(dis);

					this.D = readString(dis);

					this.E = readString(dis);

					this.F = readString(dis);

					this.date = readDate(dis);

				} catch (IOException e) {
					throw new RuntimeException(e);

				}

			}

		}

		public void writeData(ObjectOutputStream dos) {
			try {

				// Integer

				writeInteger(this.id, dos);

				// String

				writeString(this.title, dos);

				// Integer

				writeInteger(this.C, dos);

				// String

				writeString(this.D, dos);

				// String

				writeString(this.E, dos);

				// String

				writeString(this.F, dos);

				// java.util.Date

				writeDate(this.date, dos);

			} catch (IOException e) {
				throw new RuntimeException(e);
			}

		}

		public void writeData(org.jboss.marshalling.Marshaller dos) {
			try {

				// Integer

				writeInteger(this.id, dos);

				// String

				writeString(this.title, dos);

				// Integer

				writeInteger(this.C, dos);

				// String

				writeString(this.D, dos);

				// String

				writeString(this.E, dos);

				// String

				writeString(this.F, dos);

				// java.util.Date

				writeDate(this.date, dos);

			} catch (IOException e) {
				throw new RuntimeException(e);
			}

		}

		public String toString() {

			StringBuilder sb = new StringBuilder();
			sb.append(super.toString());
			sb.append("[");
			sb.append("id=" + String.valueOf(id));
			sb.append(",title=" + title);
			sb.append(",C=" + String.valueOf(C));
			sb.append(",D=" + D);
			sb.append(",E=" + E);
			sb.append(",F=" + F);
			sb.append(",date=" + String.valueOf(date));
			sb.append("]");

			return sb.toString();
		}

		/**
		 * Compare keys
		 */
		public int compareTo(after_tFileInputExcel_1Struct other) {

			int returnValue = -1;

			returnValue = checkNullsAndCompare(this.id, other.id);
			if (returnValue != 0) {
				return returnValue;
			}

			return returnValue;
		}

		private int checkNullsAndCompare(Object object1, Object object2) {
			int returnValue = 0;
			if (object1 instanceof Comparable && object2 instanceof Comparable) {
				returnValue = ((Comparable) object1).compareTo(object2);
			} else if (object1 != null && object2 != null) {
				returnValue = compareStrings(object1.toString(), object2.toString());
			} else if (object1 == null && object2 != null) {
				returnValue = 1;
			} else if (object1 != null && object2 == null) {
				returnValue = -1;
			} else {
				returnValue = 0;
			}

			return returnValue;
		}

		private int compareStrings(String string1, String string2) {
			return string1.compareTo(string2);
		}

	}

	public void tFileInputExcel_1Process(final java.util.Map<String, Object> globalMap) throws TalendException {
		globalMap.put("tFileInputExcel_1_SUBPROCESS_STATE", 0);

		final boolean execStat = this.execStat;
		String currentVirtualComponent = null;

		String iterateId = "";

		String currentComponent = "";
		java.util.Map<String, Object> resourceMap = new java.util.HashMap<String, Object>();

		try {
			// TDI-39566 avoid throwing an useless Exception
			boolean resumeIt = true;
			if (globalResumeTicket == false && resumeEntryMethodName != null) {
				String currentMethodName = new java.lang.Exception().getStackTrace()[0].getMethodName();
				resumeIt = resumeEntryMethodName.equals(currentMethodName);
			}
			if (resumeIt || globalResumeTicket) { // start the resume
				globalResumeTicket = true;

				tFileInputDelimited_1Process(globalMap);
				tFileInputXML_1Process(globalMap);

				row3Struct row3 = new row3Struct();
				row3Struct row5 = row3;
				row7Struct row7 = new row7Struct();
				movieJointStruct movieJoint = new movieJointStruct();
				row14Struct row14 = new row14Struct();
				Joint_rev_budg_opStruct Joint_rev_budg_op = new Joint_rev_budg_opStruct();
				Joint_rev_budg_opStruct row9 = Joint_rev_budg_op;
				row10Struct row10 = new row10Struct();
				Joint_rev_budget_dateStruct Joint_rev_budget_date = new Joint_rev_budget_dateStruct();
				Joint_rev_budget_dateStruct row11 = Joint_rev_budget_date;
				row12Struct row12 = new row12Struct();
				RatingXmlStruct RatingXml = new RatingXmlStruct();
				RatingXmlStruct row13 = RatingXml;
				Joint_rev_budget_date2Struct Joint_rev_budget_date2 = new Joint_rev_budget_date2Struct();
				Joint_rev_budget_date2Struct row15 = Joint_rev_budget_date2;
				row16Struct row16 = new row16Struct();
				JointSheet2Struct JointSheet2 = new JointSheet2Struct();
				JointSheet2Struct row17 = JointSheet2;
				row18Struct row18 = new row18Struct();
				row19Struct row19 = new row19Struct();
				JoinSheet3Struct JoinSheet3 = new JoinSheet3Struct();
				JoinSheet3Struct row20 = JoinSheet3;
				row21Struct row21 = new row21Struct();
				row8Struct row8 = new row8Struct();

				/**
				 * [tSortRow_1_SortOut begin ] start
				 */

				ok_Hash.put("tSortRow_1_SortOut", false);
				start_Hash.put("tSortRow_1_SortOut", System.currentTimeMillis());

				currentVirtualComponent = "tSortRow_1";

				currentComponent = "tSortRow_1_SortOut";

				if (execStat) {
					runStat.updateStatOnConnection(resourceMap, iterateId, 0, 0, "row9");
				}

				int tos_count_tSortRow_1_SortOut = 0;

				class Comparablerow9Struct extends row9Struct implements Comparable<Comparablerow9Struct> {

					public int compareTo(Comparablerow9Struct other) {

						if (this.title == null && other.title != null) {
							return -1;

						} else if (this.title != null && other.title == null) {
							return 1;

						} else if (this.title != null && other.title != null) {
							if (!this.title.equals(other.title)) {
								return this.title.compareTo(other.title);
							}
						}
						return 0;
					}
				}

				java.util.List<Comparablerow9Struct> list_tSortRow_1_SortOut = new java.util.ArrayList<Comparablerow9Struct>();

				/**
				 * [tSortRow_1_SortOut begin ] stop
				 */

				/**
				 * [tLogRow_5 begin ] start
				 */

				ok_Hash.put("tLogRow_5", false);
				start_Hash.put("tLogRow_5", System.currentTimeMillis());

				currentComponent = "tLogRow_5";

				if (execStat) {
					runStat.updateStatOnConnection(resourceMap, iterateId, 0, 0, "Joint_rev_budg_op");
				}

				int tos_count_tLogRow_5 = 0;

				///////////////////////

				final String OUTPUT_FIELD_SEPARATOR_tLogRow_5 = "|";
				java.io.PrintStream consoleOut_tLogRow_5 = null;

				StringBuilder strBuffer_tLogRow_5 = null;
				int nb_line_tLogRow_5 = 0;
///////////////////////    			

				/**
				 * [tLogRow_5 begin ] stop
				 */

				/**
				 * [tSortRow_2_SortOut begin ] start
				 */

				ok_Hash.put("tSortRow_2_SortOut", false);
				start_Hash.put("tSortRow_2_SortOut", System.currentTimeMillis());

				currentVirtualComponent = "tSortRow_2";

				currentComponent = "tSortRow_2_SortOut";

				if (execStat) {
					runStat.updateStatOnConnection(resourceMap, iterateId, 0, 0, "row11");
				}

				int tos_count_tSortRow_2_SortOut = 0;

				class Comparablerow11Struct extends row11Struct implements Comparable<Comparablerow11Struct> {

					public int compareTo(Comparablerow11Struct other) {

						if (this.date == null && other.date != null) {
							return -1;

						} else if (this.date != null && other.date == null) {
							return 1;

						} else if (this.date != null && other.date != null) {
							if (!this.date.equals(other.date)) {
								return this.date.compareTo(other.date);
							}
						}
						if (this.title == null && other.title != null) {
							return -1;

						} else if (this.title != null && other.title == null) {
							return 1;

						} else if (this.title != null && other.title != null) {
							if (!this.title.equals(other.title)) {
								return this.title.compareTo(other.title);
							}
						}
						return 0;
					}
				}

				java.util.List<Comparablerow11Struct> list_tSortRow_2_SortOut = new java.util.ArrayList<Comparablerow11Struct>();

				/**
				 * [tSortRow_2_SortOut begin ] stop
				 */

				/**
				 * [tLogRow_6 begin ] start
				 */

				ok_Hash.put("tLogRow_6", false);
				start_Hash.put("tLogRow_6", System.currentTimeMillis());

				currentComponent = "tLogRow_6";

				if (execStat) {
					runStat.updateStatOnConnection(resourceMap, iterateId, 0, 0, "Joint_rev_budget_date");
				}

				int tos_count_tLogRow_6 = 0;

				///////////////////////

				final String OUTPUT_FIELD_SEPARATOR_tLogRow_6 = "|";
				java.io.PrintStream consoleOut_tLogRow_6 = null;

				StringBuilder strBuffer_tLogRow_6 = null;
				int nb_line_tLogRow_6 = 0;
///////////////////////    			

				/**
				 * [tLogRow_6 begin ] stop
				 */

				/**
				 * [tFileOutputXML_1 begin ] start
				 */

				ok_Hash.put("tFileOutputXML_1", false);
				start_Hash.put("tFileOutputXML_1", System.currentTimeMillis());

				currentComponent = "tFileOutputXML_1";

				if (execStat) {
					runStat.updateStatOnConnection(resourceMap, iterateId, 0, 0, "row13");
				}

				int tos_count_tFileOutputXML_1 = 0;

				String originalFileName_tFileOutputXML_1 = "C:/Users/ananf/OneDrive/Documents/Aivancity/DATA pipeline/Client3";
				java.io.File originalFile_tFileOutputXML_1 = new java.io.File(originalFileName_tFileOutputXML_1);

				String fileName_tFileOutputXML_1 = originalFileName_tFileOutputXML_1;
				java.io.File file_tFileOutputXML_1 = new java.io.File(fileName_tFileOutputXML_1);
				if (!file_tFileOutputXML_1.isAbsolute()) {
					file_tFileOutputXML_1 = file_tFileOutputXML_1.getCanonicalFile();
				}

				// create directory only if not exists

				file_tFileOutputXML_1.getParentFile().mkdirs();

				String[] headers_tFileOutputXML_1 = new String[2];

				headers_tFileOutputXML_1[0] = "<?xml version=\"1.0\" encoding=\"" + "ISO-8859-15" + "\"?>";

				String[] footers_tFileOutputXML_1 = new String[1];

				headers_tFileOutputXML_1[1] = "<" + "root" + ">";

				footers_tFileOutputXML_1[0] = "</" + "root" + ">";

				int nb_line_tFileOutputXML_1 = 0;

				java.io.BufferedWriter out_tFileOutputXML_1 = new java.io.BufferedWriter(new java.io.OutputStreamWriter(
						new java.io.FileOutputStream(file_tFileOutputXML_1), "ISO-8859-15"));

				out_tFileOutputXML_1.write(headers_tFileOutputXML_1[0]);
				out_tFileOutputXML_1.newLine();
				out_tFileOutputXML_1.write(headers_tFileOutputXML_1[1]);
				out_tFileOutputXML_1.newLine();

				/**
				 * [tFileOutputXML_1 begin ] stop
				 */

				/**
				 * [tLogRow_4 begin ] start
				 */

				ok_Hash.put("tLogRow_4", false);
				start_Hash.put("tLogRow_4", System.currentTimeMillis());

				currentComponent = "tLogRow_4";

				if (execStat) {
					runStat.updateStatOnConnection(resourceMap, iterateId, 0, 0, "RatingXml");
				}

				int tos_count_tLogRow_4 = 0;

				///////////////////////

				final String OUTPUT_FIELD_SEPARATOR_tLogRow_4 = "|";
				java.io.PrintStream consoleOut_tLogRow_4 = null;

				StringBuilder strBuffer_tLogRow_4 = null;
				int nb_line_tLogRow_4 = 0;
///////////////////////    			

				/**
				 * [tLogRow_4 begin ] stop
				 */

				/**
				 * [tSortRow_3_SortOut begin ] start
				 */

				ok_Hash.put("tSortRow_3_SortOut", false);
				start_Hash.put("tSortRow_3_SortOut", System.currentTimeMillis());

				currentVirtualComponent = "tSortRow_3";

				currentComponent = "tSortRow_3_SortOut";

				if (execStat) {
					runStat.updateStatOnConnection(resourceMap, iterateId, 0, 0, "row15");
				}

				int tos_count_tSortRow_3_SortOut = 0;

				class Comparablerow15Struct extends row15Struct implements Comparable<Comparablerow15Struct> {

					public int compareTo(Comparablerow15Struct other) {

						if (this.date == null && other.date != null) {
							return -1;

						} else if (this.date != null && other.date == null) {
							return 1;

						} else if (this.date != null && other.date != null) {
							if (!this.date.equals(other.date)) {
								return this.date.compareTo(other.date);
							}
						}
						if (this.title == null && other.title != null) {
							return -1;

						} else if (this.title != null && other.title == null) {
							return 1;

						} else if (this.title != null && other.title != null) {
							if (!this.title.equals(other.title)) {
								return this.title.compareTo(other.title);
							}
						}
						return 0;
					}
				}

				java.util.List<Comparablerow15Struct> list_tSortRow_3_SortOut = new java.util.ArrayList<Comparablerow15Struct>();

				/**
				 * [tSortRow_3_SortOut begin ] stop
				 */

				/**
				 * [tLogRow_7 begin ] start
				 */

				ok_Hash.put("tLogRow_7", false);
				start_Hash.put("tLogRow_7", System.currentTimeMillis());

				currentComponent = "tLogRow_7";

				if (execStat) {
					runStat.updateStatOnConnection(resourceMap, iterateId, 0, 0, "Joint_rev_budget_date2");
				}

				int tos_count_tLogRow_7 = 0;

				///////////////////////

				class Util_tLogRow_7 {

					String[] des_top = { ".", ".", "-", "+" };

					String[] des_head = { "|=", "=|", "-", "+" };

					String[] des_bottom = { "'", "'", "-", "+" };

					String name = "";

					java.util.List<String[]> list = new java.util.ArrayList<String[]>();

					int[] colLengths = new int[5];

					public void addRow(String[] row) {

						for (int i = 0; i < 5; i++) {
							if (row[i] != null) {
								colLengths[i] = Math.max(colLengths[i], row[i].length());
							}
						}
						list.add(row);
					}

					public void setTableName(String name) {

						this.name = name;
					}

					public StringBuilder format() {

						StringBuilder sb = new StringBuilder();

						sb.append(print(des_top));

						int totals = 0;
						for (int i = 0; i < colLengths.length; i++) {
							totals = totals + colLengths[i];
						}

						// name
						sb.append("|");
						int k = 0;
						for (k = 0; k < (totals + 4 - name.length()) / 2; k++) {
							sb.append(' ');
						}
						sb.append(name);
						for (int i = 0; i < totals + 4 - name.length() - k; i++) {
							sb.append(' ');
						}
						sb.append("|\n");

						// head and rows
						sb.append(print(des_head));
						for (int i = 0; i < list.size(); i++) {

							String[] row = list.get(i);

							java.util.Formatter formatter = new java.util.Formatter(new StringBuilder());

							StringBuilder sbformat = new StringBuilder();
							sbformat.append("|%1$-");
							sbformat.append(colLengths[0]);
							sbformat.append("s");

							sbformat.append("|%2$-");
							sbformat.append(colLengths[1]);
							sbformat.append("s");

							sbformat.append("|%3$-");
							sbformat.append(colLengths[2]);
							sbformat.append("s");

							sbformat.append("|%4$-");
							sbformat.append(colLengths[3]);
							sbformat.append("s");

							sbformat.append("|%5$-");
							sbformat.append(colLengths[4]);
							sbformat.append("s");

							sbformat.append("|\n");

							formatter.format(sbformat.toString(), (Object[]) row);

							sb.append(formatter.toString());
							if (i == 0)
								sb.append(print(des_head)); // print the head
						}

						// end
						sb.append(print(des_bottom));
						return sb;
					}

					private StringBuilder print(String[] fillChars) {
						StringBuilder sb = new StringBuilder();
						// first column
						sb.append(fillChars[0]);
						for (int i = 0; i < colLengths[0] - fillChars[0].length() + 1; i++) {
							sb.append(fillChars[2]);
						}
						sb.append(fillChars[3]);

						for (int i = 0; i < colLengths[1] - fillChars[3].length() + 1; i++) {
							sb.append(fillChars[2]);
						}
						sb.append(fillChars[3]);
						for (int i = 0; i < colLengths[2] - fillChars[3].length() + 1; i++) {
							sb.append(fillChars[2]);
						}
						sb.append(fillChars[3]);
						for (int i = 0; i < colLengths[3] - fillChars[3].length() + 1; i++) {
							sb.append(fillChars[2]);
						}
						sb.append(fillChars[3]);

						// last column
						for (int i = 0; i < colLengths[4] - fillChars[1].length() + 1; i++) {
							sb.append(fillChars[2]);
						}
						sb.append(fillChars[1]);
						sb.append("\n");
						return sb;
					}

					public boolean isTableEmpty() {
						if (list.size() > 1)
							return false;
						return true;
					}
				}
				Util_tLogRow_7 util_tLogRow_7 = new Util_tLogRow_7();
				util_tLogRow_7.setTableName("tLogRow_7");
				util_tLogRow_7.addRow(new String[] { "id", "title", "date", "budget", "revenue", });
				StringBuilder strBuffer_tLogRow_7 = null;
				int nb_line_tLogRow_7 = 0;
///////////////////////    			

				/**
				 * [tLogRow_7 begin ] stop
				 */

				/**
				 * [tAggregateRow_1_AGGOUT begin ] start
				 */

				ok_Hash.put("tAggregateRow_1_AGGOUT", false);
				start_Hash.put("tAggregateRow_1_AGGOUT", System.currentTimeMillis());

				currentVirtualComponent = "tAggregateRow_1";

				currentComponent = "tAggregateRow_1_AGGOUT";

				if (execStat) {
					runStat.updateStatOnConnection(resourceMap, iterateId, 0, 0, "row17");
				}

				int tos_count_tAggregateRow_1_AGGOUT = 0;

// ------------ Seems it is not used

				java.util.Map hashAggreg_tAggregateRow_1 = new java.util.HashMap();

// ------------

				class UtilClass_tAggregateRow_1 { // G_OutBegin_AggR_144

					public double sd(Double[] data) {
						final int n = data.length;
						if (n < 2) {
							return Double.NaN;
						}
						double d1 = 0d;
						double d2 = 0d;

						for (int i = 0; i < data.length; i++) {
							d1 += (data[i] * data[i]);
							d2 += data[i];
						}

						return Math.sqrt((n * d1 - d2 * d2) / n / (n - 1));
					}

					public void checkedIADD(byte a, byte b, boolean checkTypeOverFlow, boolean checkUlp) {
						byte r = (byte) (a + b);
						if (checkTypeOverFlow && ((a ^ r) & (b ^ r)) < 0) {
							throw new RuntimeException(buildOverflowMessage(String.valueOf(a), String.valueOf(b),
									"'short/Short'", "'byte/Byte'"));
						}
					}

					public void checkedIADD(short a, short b, boolean checkTypeOverFlow, boolean checkUlp) {
						short r = (short) (a + b);
						if (checkTypeOverFlow && ((a ^ r) & (b ^ r)) < 0) {
							throw new RuntimeException(buildOverflowMessage(String.valueOf(a), String.valueOf(b),
									"'int/Integer'", "'short/Short'"));
						}
					}

					public void checkedIADD(int a, int b, boolean checkTypeOverFlow, boolean checkUlp) {
						int r = a + b;
						if (checkTypeOverFlow && ((a ^ r) & (b ^ r)) < 0) {
							throw new RuntimeException(buildOverflowMessage(String.valueOf(a), String.valueOf(b),
									"'long/Long'", "'int/Integer'"));
						}
					}

					public void checkedIADD(long a, long b, boolean checkTypeOverFlow, boolean checkUlp) {
						long r = a + b;
						if (checkTypeOverFlow && ((a ^ r) & (b ^ r)) < 0) {
							throw new RuntimeException(buildOverflowMessage(String.valueOf(a), String.valueOf(b),
									"'BigDecimal'", "'long/Long'"));
						}
					}

					public void checkedIADD(float a, float b, boolean checkTypeOverFlow, boolean checkUlp) {

						if (checkUlp) {
							float minAddedValue = Math.ulp(a);
							if (minAddedValue > Math.abs(b)) {
								throw new RuntimeException(buildPrecisionMessage(String.valueOf(a), String.valueOf(b),
										"'double' or 'BigDecimal'", "'float/Float'"));
							}
						}

						if (checkTypeOverFlow && ((double) a + (double) b > (double) Float.MAX_VALUE)
								|| ((double) a + (double) b < (double) -Float.MAX_VALUE)) {
							throw new RuntimeException(buildOverflowMessage(String.valueOf(a), String.valueOf(b),
									"'double' or 'BigDecimal'", "'float/Float'"));
						}
					}

					public void checkedIADD(double a, double b, boolean checkTypeOverFlow, boolean checkUlp) {

						if (checkUlp) {
							double minAddedValue = Math.ulp(a);
							if (minAddedValue > Math.abs(b)) {
								throw new RuntimeException(buildPrecisionMessage(String.valueOf(a), String.valueOf(a),
										"'BigDecimal'", "'double/Double'"));
							}
						}

						if (checkTypeOverFlow && (a + b > (double) Double.MAX_VALUE) || (a + b < -Double.MAX_VALUE)) {
							throw new RuntimeException(buildOverflowMessage(String.valueOf(a), String.valueOf(b),
									"'BigDecimal'", "'double/Double'"));
						}
					}

					public void checkedIADD(double a, byte b, boolean checkTypeOverFlow, boolean checkUlp) {

						if (checkTypeOverFlow && (a + b > (double) Double.MAX_VALUE) || (a + b < -Double.MAX_VALUE)) {
							throw new RuntimeException(buildOverflowMessage(String.valueOf(a), String.valueOf(b),
									"'BigDecimal'", "'double/Double'"));
						}
					}

					public void checkedIADD(double a, short b, boolean checkTypeOverFlow, boolean checkUlp) {

						if (checkTypeOverFlow && (a + b > (double) Double.MAX_VALUE) || (a + b < -Double.MAX_VALUE)) {
							throw new RuntimeException(buildOverflowMessage(String.valueOf(a), String.valueOf(b),
									"'BigDecimal'", "'double/Double'"));
						}
					}

					public void checkedIADD(double a, int b, boolean checkTypeOverFlow, boolean checkUlp) {

						if (checkTypeOverFlow && (a + b > (double) Double.MAX_VALUE) || (a + b < -Double.MAX_VALUE)) {
							throw new RuntimeException(buildOverflowMessage(String.valueOf(a), String.valueOf(b),
									"'BigDecimal'", "'double/Double'"));
						}
					}

					public void checkedIADD(double a, float b, boolean checkTypeOverFlow, boolean checkUlp) {

						if (checkUlp) {
							double minAddedValue = Math.ulp(a);
							if (minAddedValue > Math.abs(b)) {
								throw new RuntimeException(buildPrecisionMessage(String.valueOf(a), String.valueOf(a),
										"'BigDecimal'", "'double/Double'"));
							}
						}

						if (checkTypeOverFlow && (a + b > (double) Double.MAX_VALUE) || (a + b < -Double.MAX_VALUE)) {
							throw new RuntimeException(buildOverflowMessage(String.valueOf(a), String.valueOf(b),
									"'BigDecimal'", "'double/Double'"));
						}
					}

					private String buildOverflowMessage(String a, String b, String advicedTypes, String originalType) {
						return "Type overflow when adding " + b + " to " + a
								+ ", to resolve this problem, increase the precision by using " + advicedTypes
								+ " type in place of " + originalType + ".";
					}

					private String buildPrecisionMessage(String a, String b, String advicedTypes, String originalType) {
						return "The double precision is unsufficient to add the value " + b + " to " + a
								+ ", to resolve this problem, increase the precision by using " + advicedTypes
								+ " type in place of " + originalType + ".";
					}

				} // G_OutBegin_AggR_144

				UtilClass_tAggregateRow_1 utilClass_tAggregateRow_1 = new UtilClass_tAggregateRow_1();

				class AggOperationStruct_tAggregateRow_1 { // G_OutBegin_AggR_100

					private static final int DEFAULT_HASHCODE = 1;
					private static final int PRIME = 31;
					private int hashCode = DEFAULT_HASHCODE;
					public boolean hashCodeDirty = true;

					java.util.Date date;
					Long revenue_sum;
					Integer budget_sum;
					int count = 0;
					int id_clmCount = 0;

					@Override
					public int hashCode() {
						if (this.hashCodeDirty) {
							final int prime = PRIME;
							int result = DEFAULT_HASHCODE;

							result = prime * result + ((this.date == null) ? 0 : this.date.hashCode());

							this.hashCode = result;
							this.hashCodeDirty = false;
						}
						return this.hashCode;
					}

					@Override
					public boolean equals(Object obj) {
						if (this == obj)
							return true;
						if (obj == null)
							return false;
						if (getClass() != obj.getClass())
							return false;
						final AggOperationStruct_tAggregateRow_1 other = (AggOperationStruct_tAggregateRow_1) obj;

						if (this.date == null) {
							if (other.date != null)
								return false;
						} else if (!this.date.equals(other.date))
							return false;

						return true;
					}

				} // G_OutBegin_AggR_100

				AggOperationStruct_tAggregateRow_1 operation_result_tAggregateRow_1 = null;
				AggOperationStruct_tAggregateRow_1 operation_finder_tAggregateRow_1 = new AggOperationStruct_tAggregateRow_1();
				java.util.Map<AggOperationStruct_tAggregateRow_1, AggOperationStruct_tAggregateRow_1> hash_tAggregateRow_1 = new java.util.HashMap<AggOperationStruct_tAggregateRow_1, AggOperationStruct_tAggregateRow_1>();

				/**
				 * [tAggregateRow_1_AGGOUT begin ] stop
				 */

				/**
				 * [tLogRow_8 begin ] start
				 */

				ok_Hash.put("tLogRow_8", false);
				start_Hash.put("tLogRow_8", System.currentTimeMillis());

				currentComponent = "tLogRow_8";

				if (execStat) {
					runStat.updateStatOnConnection(resourceMap, iterateId, 0, 0, "JointSheet2");
				}

				int tos_count_tLogRow_8 = 0;

				///////////////////////

				final String OUTPUT_FIELD_SEPARATOR_tLogRow_8 = "|";
				java.io.PrintStream consoleOut_tLogRow_8 = null;

				StringBuilder strBuffer_tLogRow_8 = null;
				int nb_line_tLogRow_8 = 0;
///////////////////////    			

				/**
				 * [tLogRow_8 begin ] stop
				 */

				/**
				 * [tSortRow_5_SortOut begin ] start
				 */

				ok_Hash.put("tSortRow_5_SortOut", false);
				start_Hash.put("tSortRow_5_SortOut", System.currentTimeMillis());

				currentVirtualComponent = "tSortRow_5";

				currentComponent = "tSortRow_5_SortOut";

				if (execStat) {
					runStat.updateStatOnConnection(resourceMap, iterateId, 0, 0, "row20");
				}

				int tos_count_tSortRow_5_SortOut = 0;

				class Comparablerow20Struct extends row20Struct implements Comparable<Comparablerow20Struct> {

					public int compareTo(Comparablerow20Struct other) {

						if (this.gain_perte == null && other.gain_perte != null) {
							return -1;

						} else if (this.gain_perte != null && other.gain_perte == null) {
							return 1;

						} else if (this.gain_perte != null && other.gain_perte != null) {
							if (!this.gain_perte.equals(other.gain_perte)) {
								return this.gain_perte.compareTo(other.gain_perte);
							}
						}
						return 0;
					}
				}

				java.util.List<Comparablerow20Struct> list_tSortRow_5_SortOut = new java.util.ArrayList<Comparablerow20Struct>();

				/**
				 * [tSortRow_5_SortOut begin ] stop
				 */

				/**
				 * [tLogRow_9 begin ] start
				 */

				ok_Hash.put("tLogRow_9", false);
				start_Hash.put("tLogRow_9", System.currentTimeMillis());

				currentComponent = "tLogRow_9";

				if (execStat) {
					runStat.updateStatOnConnection(resourceMap, iterateId, 0, 0, "JoinSheet3");
				}

				int tos_count_tLogRow_9 = 0;

				///////////////////////

				final String OUTPUT_FIELD_SEPARATOR_tLogRow_9 = "|";
				java.io.PrintStream consoleOut_tLogRow_9 = null;

				StringBuilder strBuffer_tLogRow_9 = null;
				int nb_line_tLogRow_9 = 0;
///////////////////////    			

				/**
				 * [tLogRow_9 begin ] stop
				 */

				/**
				 * [tMap_2 begin ] start
				 */

				ok_Hash.put("tMap_2", false);
				start_Hash.put("tMap_2", System.currentTimeMillis());

				currentComponent = "tMap_2";

				if (execStat) {
					runStat.updateStatOnConnection(resourceMap, iterateId, 0, 0, "row14");
				}

				int tos_count_tMap_2 = 0;

// ###############################
// # Lookup's keys initialization
// ###############################        

// ###############################
// # Vars initialization
				class Var__tMap_2__Struct {
					long gain_perte;
				}
				Var__tMap_2__Struct Var__tMap_2 = new Var__tMap_2__Struct();
// ###############################

// ###############################
// # Outputs initialization
				Joint_rev_budg_opStruct Joint_rev_budg_op_tmp = new Joint_rev_budg_opStruct();
				Joint_rev_budget_dateStruct Joint_rev_budget_date_tmp = new Joint_rev_budget_dateStruct();
				RatingXmlStruct RatingXml_tmp = new RatingXmlStruct();
				Joint_rev_budget_date2Struct Joint_rev_budget_date2_tmp = new Joint_rev_budget_date2Struct();
				JointSheet2Struct JointSheet2_tmp = new JointSheet2Struct();
				JoinSheet3Struct JoinSheet3_tmp = new JoinSheet3Struct();
// ###############################

				/**
				 * [tMap_2 begin ] stop
				 */

				/**
				 * [tFileOutputDelimited_1 begin ] start
				 */

				ok_Hash.put("tFileOutputDelimited_1", false);
				start_Hash.put("tFileOutputDelimited_1", System.currentTimeMillis());

				currentComponent = "tFileOutputDelimited_1";

				if (execStat) {
					runStat.updateStatOnConnection(resourceMap, iterateId, 0, 0, "row8");
				}

				int tos_count_tFileOutputDelimited_1 = 0;

				String fileName_tFileOutputDelimited_1 = "";
				fileName_tFileOutputDelimited_1 = (new java.io.File(
						"C:/Users/ananf/OneDrive/Documents/Aivancity/DATA pipeline/oldMov.csv")).getAbsolutePath()
								.replace("\\", "/");
				String fullName_tFileOutputDelimited_1 = null;
				String extension_tFileOutputDelimited_1 = null;
				String directory_tFileOutputDelimited_1 = null;
				if ((fileName_tFileOutputDelimited_1.indexOf("/") != -1)) {
					if (fileName_tFileOutputDelimited_1.lastIndexOf(".") < fileName_tFileOutputDelimited_1
							.lastIndexOf("/")) {
						fullName_tFileOutputDelimited_1 = fileName_tFileOutputDelimited_1;
						extension_tFileOutputDelimited_1 = "";
					} else {
						fullName_tFileOutputDelimited_1 = fileName_tFileOutputDelimited_1.substring(0,
								fileName_tFileOutputDelimited_1.lastIndexOf("."));
						extension_tFileOutputDelimited_1 = fileName_tFileOutputDelimited_1
								.substring(fileName_tFileOutputDelimited_1.lastIndexOf("."));
					}
					directory_tFileOutputDelimited_1 = fileName_tFileOutputDelimited_1.substring(0,
							fileName_tFileOutputDelimited_1.lastIndexOf("/"));
				} else {
					if (fileName_tFileOutputDelimited_1.lastIndexOf(".") != -1) {
						fullName_tFileOutputDelimited_1 = fileName_tFileOutputDelimited_1.substring(0,
								fileName_tFileOutputDelimited_1.lastIndexOf("."));
						extension_tFileOutputDelimited_1 = fileName_tFileOutputDelimited_1
								.substring(fileName_tFileOutputDelimited_1.lastIndexOf("."));
					} else {
						fullName_tFileOutputDelimited_1 = fileName_tFileOutputDelimited_1;
						extension_tFileOutputDelimited_1 = "";
					}
					directory_tFileOutputDelimited_1 = "";
				}
				boolean isFileGenerated_tFileOutputDelimited_1 = true;
				java.io.File filetFileOutputDelimited_1 = new java.io.File(fileName_tFileOutputDelimited_1);
				globalMap.put("tFileOutputDelimited_1_FILE_NAME", fileName_tFileOutputDelimited_1);
				if (filetFileOutputDelimited_1.exists()) {
					throw new RuntimeException("The particular file \"" + filetFileOutputDelimited_1.getAbsoluteFile()
							+ "\" already exist. If you want to overwrite the file, please uncheck the"
							+ " \"Throw an error if the file already exist\" option in Advanced settings.");
				}
				int nb_line_tFileOutputDelimited_1 = 0;
				int splitedFileNo_tFileOutputDelimited_1 = 0;
				int currentRow_tFileOutputDelimited_1 = 0;

				final String OUT_DELIM_tFileOutputDelimited_1 = /** Start field tFileOutputDelimited_1:FIELDSEPARATOR */
						";"/** End field tFileOutputDelimited_1:FIELDSEPARATOR */
				;

				final String OUT_DELIM_ROWSEP_tFileOutputDelimited_1 = /**
																		 * Start field
																		 * tFileOutputDelimited_1:ROWSEPARATOR
																		 */
						"\n"/** End field tFileOutputDelimited_1:ROWSEPARATOR */
				;

				// create directory only if not exists
				if (directory_tFileOutputDelimited_1 != null && directory_tFileOutputDelimited_1.trim().length() != 0) {
					java.io.File dir_tFileOutputDelimited_1 = new java.io.File(directory_tFileOutputDelimited_1);
					if (!dir_tFileOutputDelimited_1.exists()) {
						dir_tFileOutputDelimited_1.mkdirs();
					}
				}

				// routines.system.Row
				java.io.Writer outtFileOutputDelimited_1 = null;

				java.io.File fileToDelete_tFileOutputDelimited_1 = new java.io.File(fileName_tFileOutputDelimited_1);
				if (fileToDelete_tFileOutputDelimited_1.exists()) {
					fileToDelete_tFileOutputDelimited_1.delete();
				}
				outtFileOutputDelimited_1 = new java.io.BufferedWriter(new java.io.OutputStreamWriter(
						new java.io.FileOutputStream(fileName_tFileOutputDelimited_1, false), "ISO-8859-15"));
				if (filetFileOutputDelimited_1.length() == 0) {
					outtFileOutputDelimited_1.write("id");
					outtFileOutputDelimited_1.write(OUT_DELIM_tFileOutputDelimited_1);
					outtFileOutputDelimited_1.write("title");
					outtFileOutputDelimited_1.write(OUT_DELIM_tFileOutputDelimited_1);
					outtFileOutputDelimited_1.write("date");
					outtFileOutputDelimited_1.write(OUT_DELIM_tFileOutputDelimited_1);
					outtFileOutputDelimited_1.write("popularity");
					outtFileOutputDelimited_1.write(OUT_DELIM_tFileOutputDelimited_1);
					outtFileOutputDelimited_1.write("vote_count");
					outtFileOutputDelimited_1.write(OUT_DELIM_tFileOutputDelimited_1);
					outtFileOutputDelimited_1.write("vote_average");
					outtFileOutputDelimited_1.write(OUT_DELIM_tFileOutputDelimited_1);
					outtFileOutputDelimited_1.write("budget");
					outtFileOutputDelimited_1.write(OUT_DELIM_tFileOutputDelimited_1);
					outtFileOutputDelimited_1.write("revenue");
					outtFileOutputDelimited_1.write(OUT_DELIM_ROWSEP_tFileOutputDelimited_1);
					outtFileOutputDelimited_1.flush();
				}

				resourceMap.put("out_tFileOutputDelimited_1", outtFileOutputDelimited_1);
				resourceMap.put("nb_line_tFileOutputDelimited_1", nb_line_tFileOutputDelimited_1);

				/**
				 * [tFileOutputDelimited_1 begin ] stop
				 */

				/**
				 * [tFilterRow_1 begin ] start
				 */

				ok_Hash.put("tFilterRow_1", false);
				start_Hash.put("tFilterRow_1", System.currentTimeMillis());

				currentComponent = "tFilterRow_1";

				if (execStat) {
					runStat.updateStatOnConnection(resourceMap, iterateId, 0, 0, "movieJoint");
				}

				int tos_count_tFilterRow_1 = 0;

				int nb_line_tFilterRow_1 = 0;
				int nb_line_ok_tFilterRow_1 = 0;
				int nb_line_reject_tFilterRow_1 = 0;

				class Operator_tFilterRow_1 {
					private String sErrorMsg = "";
					private boolean bMatchFlag = true;
					private String sUnionFlag = "&&";

					public Operator_tFilterRow_1(String unionFlag) {
						sUnionFlag = unionFlag;
						bMatchFlag = "||".equals(unionFlag) ? false : true;
					}

					public String getErrorMsg() {
						if (sErrorMsg != null && sErrorMsg.length() > 1)
							return sErrorMsg.substring(1);
						else
							return null;
					}

					public boolean getMatchFlag() {
						return bMatchFlag;
					}

					public void matches(boolean partMatched, String reason) {
						// no need to care about the next judgement
						if ("||".equals(sUnionFlag) && bMatchFlag) {
							return;
						}

						if (!partMatched) {
							sErrorMsg += "|" + reason;
						}

						if ("||".equals(sUnionFlag))
							bMatchFlag = bMatchFlag || partMatched;
						else
							bMatchFlag = bMatchFlag && partMatched;
					}
				}

				/**
				 * [tFilterRow_1 begin ] stop
				 */

				/**
				 * [tMap_1 begin ] start
				 */

				ok_Hash.put("tMap_1", false);
				start_Hash.put("tMap_1", System.currentTimeMillis());

				currentComponent = "tMap_1";

				if (execStat) {
					runStat.updateStatOnConnection(resourceMap, iterateId, 0, 0, "row7");
				}

				int tos_count_tMap_1 = 0;

// ###############################
// # Lookup's keys initialization

				org.talend.designer.components.lookup.memory.AdvancedMemoryLookup<row6Struct> tHash_Lookup_row6 = (org.talend.designer.components.lookup.memory.AdvancedMemoryLookup<row6Struct>) ((org.talend.designer.components.lookup.memory.AdvancedMemoryLookup<row6Struct>) globalMap
						.get("tHash_Lookup_row6"));

				row6Struct row6HashKey = new row6Struct();
				row6Struct row6Default = new row6Struct();

				org.talend.designer.components.lookup.memory.AdvancedMemoryLookup<row2Struct> tHash_Lookup_row2 = (org.talend.designer.components.lookup.memory.AdvancedMemoryLookup<row2Struct>) ((org.talend.designer.components.lookup.memory.AdvancedMemoryLookup<row2Struct>) globalMap
						.get("tHash_Lookup_row2"));

				row2Struct row2HashKey = new row2Struct();
				row2Struct row2Default = new row2Struct();
// ###############################        

// ###############################
// # Vars initialization
				class Var__tMap_1__Struct {
				}
				Var__tMap_1__Struct Var__tMap_1 = new Var__tMap_1__Struct();
// ###############################

// ###############################
// # Outputs initialization
				movieJointStruct movieJoint_tmp = new movieJointStruct();
// ###############################

				/**
				 * [tMap_1 begin ] stop
				 */

				/**
				 * [tFilterColumns_1 begin ] start
				 */

				ok_Hash.put("tFilterColumns_1", false);
				start_Hash.put("tFilterColumns_1", System.currentTimeMillis());

				currentComponent = "tFilterColumns_1";

				if (execStat) {
					runStat.updateStatOnConnection(resourceMap, iterateId, 0, 0, "row5");
				}

				int tos_count_tFilterColumns_1 = 0;

				int nb_line_tFilterColumns_1 = 0;

				/**
				 * [tFilterColumns_1 begin ] stop
				 */

				/**
				 * [tLogRow_1 begin ] start
				 */

				ok_Hash.put("tLogRow_1", false);
				start_Hash.put("tLogRow_1", System.currentTimeMillis());

				currentComponent = "tLogRow_1";

				if (execStat) {
					runStat.updateStatOnConnection(resourceMap, iterateId, 0, 0, "row3");
				}

				int tos_count_tLogRow_1 = 0;

				///////////////////////

				class Util_tLogRow_1 {

					String[] des_top = { ".", ".", "-", "+" };

					String[] des_head = { "|=", "=|", "-", "+" };

					String[] des_bottom = { "'", "'", "-", "+" };

					String name = "";

					java.util.List<String[]> list = new java.util.ArrayList<String[]>();

					int[] colLengths = new int[7];

					public void addRow(String[] row) {

						for (int i = 0; i < 7; i++) {
							if (row[i] != null) {
								colLengths[i] = Math.max(colLengths[i], row[i].length());
							}
						}
						list.add(row);
					}

					public void setTableName(String name) {

						this.name = name;
					}

					public StringBuilder format() {

						StringBuilder sb = new StringBuilder();

						sb.append(print(des_top));

						int totals = 0;
						for (int i = 0; i < colLengths.length; i++) {
							totals = totals + colLengths[i];
						}

						// name
						sb.append("|");
						int k = 0;
						for (k = 0; k < (totals + 6 - name.length()) / 2; k++) {
							sb.append(' ');
						}
						sb.append(name);
						for (int i = 0; i < totals + 6 - name.length() - k; i++) {
							sb.append(' ');
						}
						sb.append("|\n");

						// head and rows
						sb.append(print(des_head));
						for (int i = 0; i < list.size(); i++) {

							String[] row = list.get(i);

							java.util.Formatter formatter = new java.util.Formatter(new StringBuilder());

							StringBuilder sbformat = new StringBuilder();
							sbformat.append("|%1$-");
							sbformat.append(colLengths[0]);
							sbformat.append("s");

							sbformat.append("|%2$-");
							sbformat.append(colLengths[1]);
							sbformat.append("s");

							sbformat.append("|%3$-");
							sbformat.append(colLengths[2]);
							sbformat.append("s");

							sbformat.append("|%4$-");
							sbformat.append(colLengths[3]);
							sbformat.append("s");

							sbformat.append("|%5$-");
							sbformat.append(colLengths[4]);
							sbformat.append("s");

							sbformat.append("|%6$-");
							sbformat.append(colLengths[5]);
							sbformat.append("s");

							sbformat.append("|%7$-");
							sbformat.append(colLengths[6]);
							sbformat.append("s");

							sbformat.append("|\n");

							formatter.format(sbformat.toString(), (Object[]) row);

							sb.append(formatter.toString());
							if (i == 0)
								sb.append(print(des_head)); // print the head
						}

						// end
						sb.append(print(des_bottom));
						return sb;
					}

					private StringBuilder print(String[] fillChars) {
						StringBuilder sb = new StringBuilder();
						// first column
						sb.append(fillChars[0]);
						for (int i = 0; i < colLengths[0] - fillChars[0].length() + 1; i++) {
							sb.append(fillChars[2]);
						}
						sb.append(fillChars[3]);

						for (int i = 0; i < colLengths[1] - fillChars[3].length() + 1; i++) {
							sb.append(fillChars[2]);
						}
						sb.append(fillChars[3]);
						for (int i = 0; i < colLengths[2] - fillChars[3].length() + 1; i++) {
							sb.append(fillChars[2]);
						}
						sb.append(fillChars[3]);
						for (int i = 0; i < colLengths[3] - fillChars[3].length() + 1; i++) {
							sb.append(fillChars[2]);
						}
						sb.append(fillChars[3]);
						for (int i = 0; i < colLengths[4] - fillChars[3].length() + 1; i++) {
							sb.append(fillChars[2]);
						}
						sb.append(fillChars[3]);
						for (int i = 0; i < colLengths[5] - fillChars[3].length() + 1; i++) {
							sb.append(fillChars[2]);
						}
						sb.append(fillChars[3]);

						// last column
						for (int i = 0; i < colLengths[6] - fillChars[1].length() + 1; i++) {
							sb.append(fillChars[2]);
						}
						sb.append(fillChars[1]);
						sb.append("\n");
						return sb;
					}

					public boolean isTableEmpty() {
						if (list.size() > 1)
							return false;
						return true;
					}
				}
				Util_tLogRow_1 util_tLogRow_1 = new Util_tLogRow_1();
				util_tLogRow_1.setTableName("logRelease");
				util_tLogRow_1.addRow(new String[] { "id", "title", "C", "D", "E", "F", "date", });
				StringBuilder strBuffer_tLogRow_1 = null;
				int nb_line_tLogRow_1 = 0;
///////////////////////    			

				/**
				 * [tLogRow_1 begin ] stop
				 */

				/**
				 * [tFileInputExcel_1 begin ] start
				 */

				ok_Hash.put("tFileInputExcel_1", false);
				start_Hash.put("tFileInputExcel_1", System.currentTimeMillis());

				currentComponent = "tFileInputExcel_1";

				int tos_count_tFileInputExcel_1 = 0;

				class RegexUtil_tFileInputExcel_1 {

					public java.util.List<jxl.Sheet> getSheets(jxl.Workbook workbook, String oneSheetName,
							boolean useRegex) {

						java.util.List<jxl.Sheet> list = new java.util.ArrayList<jxl.Sheet>();

						if (useRegex) {// this part process the regex issue

							jxl.Sheet[] sheets = workbook.getSheets();
							java.util.regex.Pattern pattern = java.util.regex.Pattern.compile(oneSheetName);
							for (int i = 0; i < sheets.length; i++) {
								String sheetName = sheets[i].getName();
								java.util.regex.Matcher matcher = pattern.matcher(sheetName);
								if (matcher.matches()) {
									jxl.Sheet sheet = workbook.getSheet(sheetName);
									if (sheet != null) {
										list.add(sheet);
									}
								}
							}

						} else {
							jxl.Sheet sheet = workbook.getSheet(oneSheetName);
							if (sheet != null) {
								list.add(sheet);
							}

						}

						return list;
					}

					public java.util.List<jxl.Sheet> getSheets(jxl.Workbook workbook, int index, boolean useRegex) {
						java.util.List<jxl.Sheet> list = new java.util.ArrayList<jxl.Sheet>();
						jxl.Sheet sheet = workbook.getSheet(index);
						if (sheet != null) {
							list.add(sheet);
						}
						return list;
					}

				}

				RegexUtil_tFileInputExcel_1 regexUtil_tFileInputExcel_1 = new RegexUtil_tFileInputExcel_1();
				final jxl.WorkbookSettings workbookSettings_tFileInputExcel_1 = new jxl.WorkbookSettings();
				workbookSettings_tFileInputExcel_1.setDrawingsDisabled(true);
				workbookSettings_tFileInputExcel_1.setEncoding("UTF-8");

				Object source_tFileInputExcel_1 = "C:/Users/ananf/OneDrive/Documents/Aivancity/DATA pipeline/moviesRelease.xls";
				final jxl.Workbook workbook_tFileInputExcel_1;

				java.io.InputStream toClose_tFileInputExcel_1 = null;
				java.io.BufferedInputStream buffIStreamtFileInputExcel_1 = null;
				try {
					if (source_tFileInputExcel_1 instanceof java.io.InputStream) {
						toClose_tFileInputExcel_1 = (java.io.InputStream) source_tFileInputExcel_1;
						buffIStreamtFileInputExcel_1 = new java.io.BufferedInputStream(toClose_tFileInputExcel_1);
						workbook_tFileInputExcel_1 = jxl.Workbook.getWorkbook(buffIStreamtFileInputExcel_1,
								workbookSettings_tFileInputExcel_1);
					} else if (source_tFileInputExcel_1 instanceof String) {
						toClose_tFileInputExcel_1 = new java.io.FileInputStream(source_tFileInputExcel_1.toString());
						buffIStreamtFileInputExcel_1 = new java.io.BufferedInputStream(toClose_tFileInputExcel_1);
						workbook_tFileInputExcel_1 = jxl.Workbook.getWorkbook(buffIStreamtFileInputExcel_1,
								workbookSettings_tFileInputExcel_1);
					} else {
						workbook_tFileInputExcel_1 = null;
						throw new java.lang.Exception(
								"The data source should be specified as Inputstream or File Path!");
					}
				} finally {
					try {
						if (buffIStreamtFileInputExcel_1 != null) {
							buffIStreamtFileInputExcel_1.close();
						}
					} catch (Exception e) {
						globalMap.put("tFileInputExcel_1_ERROR_MESSAGE", e.getMessage());
					}
				}
				try {
					java.util.List<jxl.Sheet> sheetList_tFileInputExcel_1 = java.util.Arrays.<jxl.Sheet>asList(
							workbook_tFileInputExcel_1.getSheets());
					if (sheetList_tFileInputExcel_1.size() <= 0) {
						throw new RuntimeException("Special sheets not exist!");
					}

					java.util.List<jxl.Sheet> sheet_FilterNullList_tFileInputExcel_1 = new java.util.ArrayList<jxl.Sheet>();
					for (jxl.Sheet sheet_FilterNull_tFileInputExcel_1 : sheetList_tFileInputExcel_1) {
						if (sheet_FilterNull_tFileInputExcel_1.getRows() > 0) {
							sheet_FilterNullList_tFileInputExcel_1.add(sheet_FilterNull_tFileInputExcel_1);
						}
					}
					sheetList_tFileInputExcel_1 = sheet_FilterNullList_tFileInputExcel_1;
					if (sheetList_tFileInputExcel_1.size() > 0) {
						int nb_line_tFileInputExcel_1 = 0;

						int begin_line_tFileInputExcel_1 = 0;

						int footer_input_tFileInputExcel_1 = 0;

						int end_line_tFileInputExcel_1 = 0;
						for (jxl.Sheet sheet_tFileInputExcel_1 : sheetList_tFileInputExcel_1) {
							end_line_tFileInputExcel_1 += sheet_tFileInputExcel_1.getRows();
						}
						end_line_tFileInputExcel_1 -= footer_input_tFileInputExcel_1;
						int limit_tFileInputExcel_1 = -1;
						int start_column_tFileInputExcel_1 = 1 - 1;
						int end_column_tFileInputExcel_1 = sheetList_tFileInputExcel_1.get(0).getColumns();
						jxl.Cell[] row_tFileInputExcel_1 = null;
						jxl.Sheet sheet_tFileInputExcel_1 = sheetList_tFileInputExcel_1.get(0);
						int rowCount_tFileInputExcel_1 = 0;
						int sheetIndex_tFileInputExcel_1 = 0;
						int currentRows_tFileInputExcel_1 = sheetList_tFileInputExcel_1.get(0).getRows();

						// for the number format
						java.text.DecimalFormat df_tFileInputExcel_1 = new java.text.DecimalFormat(
								"#.####################################");
						char separatorChar_tFileInputExcel_1 = df_tFileInputExcel_1.getDecimalFormatSymbols()
								.getDecimalSeparator();

						for (int i_tFileInputExcel_1 = begin_line_tFileInputExcel_1; i_tFileInputExcel_1 < end_line_tFileInputExcel_1; i_tFileInputExcel_1++) {

							int emptyColumnCount_tFileInputExcel_1 = 0;

							if (limit_tFileInputExcel_1 != -1 && nb_line_tFileInputExcel_1 >= limit_tFileInputExcel_1) {
								break;
							}

							while (i_tFileInputExcel_1 >= rowCount_tFileInputExcel_1 + currentRows_tFileInputExcel_1) {
								rowCount_tFileInputExcel_1 += currentRows_tFileInputExcel_1;
								sheet_tFileInputExcel_1 = sheetList_tFileInputExcel_1
										.get(++sheetIndex_tFileInputExcel_1);
								currentRows_tFileInputExcel_1 = sheet_tFileInputExcel_1.getRows();
							}
							if (rowCount_tFileInputExcel_1 <= i_tFileInputExcel_1) {
								row_tFileInputExcel_1 = sheet_tFileInputExcel_1
										.getRow(i_tFileInputExcel_1 - rowCount_tFileInputExcel_1);
							}
							globalMap.put("tFileInputExcel_1_CURRENT_SHEET", sheet_tFileInputExcel_1.getName());
							row3 = null;
							int tempRowLength_tFileInputExcel_1 = 7;

							int columnIndex_tFileInputExcel_1 = 0;

//
//end%>

							String[] temp_row_tFileInputExcel_1 = new String[tempRowLength_tFileInputExcel_1];
							int actual_end_column_tFileInputExcel_1 = end_column_tFileInputExcel_1 > row_tFileInputExcel_1.length
									? row_tFileInputExcel_1.length
									: end_column_tFileInputExcel_1;

							java.util.TimeZone zone_tFileInputExcel_1 = java.util.TimeZone.getTimeZone("GMT");
							java.text.SimpleDateFormat sdf_tFileInputExcel_1 = new java.text.SimpleDateFormat(
									"dd-MM-yyyy");
							sdf_tFileInputExcel_1.setTimeZone(zone_tFileInputExcel_1);

							for (int i = 0; i < tempRowLength_tFileInputExcel_1; i++) {

								if (i + start_column_tFileInputExcel_1 < actual_end_column_tFileInputExcel_1) {

									jxl.Cell cell_tFileInputExcel_1 = row_tFileInputExcel_1[i
											+ start_column_tFileInputExcel_1];
									temp_row_tFileInputExcel_1[i] = cell_tFileInputExcel_1.getContents();

								} else {
									temp_row_tFileInputExcel_1[i] = "";
								}
							}

							boolean whetherReject_tFileInputExcel_1 = false;
							row3 = new row3Struct();
							int curColNum_tFileInputExcel_1 = -1;
							String curColName_tFileInputExcel_1 = "";
							try {
								columnIndex_tFileInputExcel_1 = 0;

								if (temp_row_tFileInputExcel_1[columnIndex_tFileInputExcel_1].length() > 0) {
									curColNum_tFileInputExcel_1 = columnIndex_tFileInputExcel_1
											+ start_column_tFileInputExcel_1 + 1;
									curColName_tFileInputExcel_1 = "id";
									row3.id = ParserUtils
											.parseTo_Integer(temp_row_tFileInputExcel_1[columnIndex_tFileInputExcel_1]);
								} else {
									row3.id = null;
									emptyColumnCount_tFileInputExcel_1++;
								}
								columnIndex_tFileInputExcel_1 = 1;

								if (temp_row_tFileInputExcel_1[columnIndex_tFileInputExcel_1].length() > 0) {
									curColNum_tFileInputExcel_1 = columnIndex_tFileInputExcel_1
											+ start_column_tFileInputExcel_1 + 1;
									curColName_tFileInputExcel_1 = "title";
									row3.title = temp_row_tFileInputExcel_1[columnIndex_tFileInputExcel_1];
								} else {
									row3.title = null;
									emptyColumnCount_tFileInputExcel_1++;
								}
								columnIndex_tFileInputExcel_1 = 2;

								if (temp_row_tFileInputExcel_1[columnIndex_tFileInputExcel_1].length() > 0) {
									curColNum_tFileInputExcel_1 = columnIndex_tFileInputExcel_1
											+ start_column_tFileInputExcel_1 + 1;
									curColName_tFileInputExcel_1 = "C";
									row3.C = ParserUtils
											.parseTo_Integer(temp_row_tFileInputExcel_1[columnIndex_tFileInputExcel_1]);
								} else {
									row3.C = null;
									emptyColumnCount_tFileInputExcel_1++;
								}
								columnIndex_tFileInputExcel_1 = 3;

								if (temp_row_tFileInputExcel_1[columnIndex_tFileInputExcel_1].length() > 0) {
									curColNum_tFileInputExcel_1 = columnIndex_tFileInputExcel_1
											+ start_column_tFileInputExcel_1 + 1;
									curColName_tFileInputExcel_1 = "D";
									row3.D = temp_row_tFileInputExcel_1[columnIndex_tFileInputExcel_1];
								} else {
									row3.D = null;
									emptyColumnCount_tFileInputExcel_1++;
								}
								columnIndex_tFileInputExcel_1 = 4;

								if (temp_row_tFileInputExcel_1[columnIndex_tFileInputExcel_1].length() > 0) {
									curColNum_tFileInputExcel_1 = columnIndex_tFileInputExcel_1
											+ start_column_tFileInputExcel_1 + 1;
									curColName_tFileInputExcel_1 = "E";
									row3.E = temp_row_tFileInputExcel_1[columnIndex_tFileInputExcel_1];
								} else {
									row3.E = null;
									emptyColumnCount_tFileInputExcel_1++;
								}
								columnIndex_tFileInputExcel_1 = 5;

								if (temp_row_tFileInputExcel_1[columnIndex_tFileInputExcel_1].length() > 0) {
									curColNum_tFileInputExcel_1 = columnIndex_tFileInputExcel_1
											+ start_column_tFileInputExcel_1 + 1;
									curColName_tFileInputExcel_1 = "F";
									row3.F = temp_row_tFileInputExcel_1[columnIndex_tFileInputExcel_1];
								} else {
									row3.F = null;
									emptyColumnCount_tFileInputExcel_1++;
								}
								columnIndex_tFileInputExcel_1 = 6;

								if (temp_row_tFileInputExcel_1[columnIndex_tFileInputExcel_1].length() > 0) {
									curColNum_tFileInputExcel_1 = columnIndex_tFileInputExcel_1
											+ start_column_tFileInputExcel_1 + 1;
									curColName_tFileInputExcel_1 = "date";
									if (6 < actual_end_column_tFileInputExcel_1) {
										try {
											java.util.Date dateGMT_tFileInputExcel_1 = ((jxl.DateCell) row_tFileInputExcel_1[columnIndex_tFileInputExcel_1
													+ start_column_tFileInputExcel_1]).getDate();
											row3.date = new java.util.Date(dateGMT_tFileInputExcel_1.getTime()
													- java.util.TimeZone.getDefault()
															.getOffset(dateGMT_tFileInputExcel_1.getTime()));
										} catch (java.lang.Exception e) {
											globalMap.put("tFileInputExcel_1_ERROR_MESSAGE", e.getMessage());

											throw new RuntimeException("The cell format is not Date in ( Row. "
													+ (nb_line_tFileInputExcel_1 + 1) + " and ColumnNum. "
													+ curColNum_tFileInputExcel_1 + " )");
										}
									}
								} else {
									row3.date = null;
									emptyColumnCount_tFileInputExcel_1++;
								}

								nb_line_tFileInputExcel_1++;

							} catch (java.lang.Exception e) {
								globalMap.put("tFileInputExcel_1_ERROR_MESSAGE", e.getMessage());
								whetherReject_tFileInputExcel_1 = true;
								System.err.println(e.getMessage());
								row3 = null;
							}

							/**
							 * [tFileInputExcel_1 begin ] stop
							 */

							/**
							 * [tFileInputExcel_1 main ] start
							 */

							currentComponent = "tFileInputExcel_1";

							tos_count_tFileInputExcel_1++;

							/**
							 * [tFileInputExcel_1 main ] stop
							 */

							/**
							 * [tFileInputExcel_1 process_data_begin ] start
							 */

							currentComponent = "tFileInputExcel_1";

							/**
							 * [tFileInputExcel_1 process_data_begin ] stop
							 */
// Start of branch "row3"
							if (row3 != null) {

								/**
								 * [tLogRow_1 main ] start
								 */

								currentComponent = "tLogRow_1";

								if (execStat) {
									runStat.updateStatOnConnection(iterateId, 1, 1

											, "row3"

									);
								}

///////////////////////		

								String[] row_tLogRow_1 = new String[7];

								if (row3.id != null) { //
									row_tLogRow_1[0] = String.valueOf(row3.id);

								} //

								if (row3.title != null) { //
									row_tLogRow_1[1] = String.valueOf(row3.title);

								} //

								if (row3.C != null) { //
									row_tLogRow_1[2] = String.valueOf(row3.C);

								} //

								if (row3.D != null) { //
									row_tLogRow_1[3] = String.valueOf(row3.D);

								} //

								if (row3.E != null) { //
									row_tLogRow_1[4] = String.valueOf(row3.E);

								} //

								if (row3.F != null) { //
									row_tLogRow_1[5] = String.valueOf(row3.F);

								} //

								if (row3.date != null) { //
									row_tLogRow_1[6] = FormatterUtils.format_Date(row3.date, "dd-MM-yyyy");

								} //

								util_tLogRow_1.addRow(row_tLogRow_1);
								nb_line_tLogRow_1++;
//////

//////                    

///////////////////////    			

								row5 = row3;

								tos_count_tLogRow_1++;

								/**
								 * [tLogRow_1 main ] stop
								 */

								/**
								 * [tLogRow_1 process_data_begin ] start
								 */

								currentComponent = "tLogRow_1";

								/**
								 * [tLogRow_1 process_data_begin ] stop
								 */

								/**
								 * [tFilterColumns_1 main ] start
								 */

								currentComponent = "tFilterColumns_1";

								if (execStat) {
									runStat.updateStatOnConnection(iterateId, 1, 1

											, "row5"

									);
								}

								row7.id = row5.id;

								row7.title = row5.title;

								row7.date = row5.date;

								nb_line_tFilterColumns_1++;

								tos_count_tFilterColumns_1++;

								/**
								 * [tFilterColumns_1 main ] stop
								 */

								/**
								 * [tFilterColumns_1 process_data_begin ] start
								 */

								currentComponent = "tFilterColumns_1";

								/**
								 * [tFilterColumns_1 process_data_begin ] stop
								 */

								/**
								 * [tMap_1 main ] start
								 */

								currentComponent = "tMap_1";

								if (execStat) {
									runStat.updateStatOnConnection(iterateId, 1, 1

											, "row7"

									);
								}

								boolean hasCasePrimitiveKeyWithNull_tMap_1 = false;

								// ###############################
								// # Input tables (lookups)
								boolean rejectedInnerJoin_tMap_1 = false;
								boolean mainRowRejected_tMap_1 = false;

								///////////////////////////////////////////////
								// Starting Lookup Table "row6"
								///////////////////////////////////////////////

								boolean forceLooprow6 = false;

								row6Struct row6ObjectFromLookup = null;

								if (!rejectedInnerJoin_tMap_1) { // G_TM_M_020

									hasCasePrimitiveKeyWithNull_tMap_1 = false;

									row6HashKey.title = row7.title;

									row6HashKey.hashCodeDirty = true;

									tHash_Lookup_row6.lookup(row6HashKey);

								} // G_TM_M_020

								if (tHash_Lookup_row6 != null && tHash_Lookup_row6.getCount(row6HashKey) > 1) { // G 071

									// System.out.println("WARNING: UNIQUE MATCH is configured for the lookup 'row6'
									// and it contains more one result from keys : row6.title = '" +
									// row6HashKey.title + "'");
								} // G 071

								row6Struct row6 = null;

								row6Struct fromLookup_row6 = null;
								row6 = row6Default;

								if (tHash_Lookup_row6 != null && tHash_Lookup_row6.hasNext()) { // G 099

									fromLookup_row6 = tHash_Lookup_row6.next();

								} // G 099

								if (fromLookup_row6 != null) {
									row6 = fromLookup_row6;
								}

								///////////////////////////////////////////////
								// Starting Lookup Table "row2"
								///////////////////////////////////////////////

								boolean forceLooprow2 = false;

								row2Struct row2ObjectFromLookup = null;

								if (!rejectedInnerJoin_tMap_1) { // G_TM_M_020

									hasCasePrimitiveKeyWithNull_tMap_1 = false;

									row2HashKey.movie_id = row7.id;

									row2HashKey.hashCodeDirty = true;

									tHash_Lookup_row2.lookup(row2HashKey);

								} // G_TM_M_020

								if (tHash_Lookup_row2 != null && tHash_Lookup_row2.getCount(row2HashKey) > 1) { // G 071

									// System.out.println("WARNING: UNIQUE MATCH is configured for the lookup 'row2'
									// and it contains more one result from keys : row2.movie_id = '" +
									// row2HashKey.movie_id + "'");
								} // G 071

								row2Struct row2 = null;

								row2Struct fromLookup_row2 = null;
								row2 = row2Default;

								if (tHash_Lookup_row2 != null && tHash_Lookup_row2.hasNext()) { // G 099

									fromLookup_row2 = tHash_Lookup_row2.next();

								} // G 099

								if (fromLookup_row2 != null) {
									row2 = fromLookup_row2;
								}

								// ###############################
								{ // start of Var scope

									// ###############################
									// # Vars tables

									Var__tMap_1__Struct Var = Var__tMap_1;// ###############################
									// ###############################
									// # Output tables

									movieJoint = null;

// # Output table : 'movieJoint'
									movieJoint_tmp.id = row7.id;
									movieJoint_tmp.title = row7.title;
									movieJoint_tmp.date = row7.date;
									movieJoint_tmp.popularity = row6.popularity;
									movieJoint_tmp.vote_count = row6.vote_count;
									movieJoint_tmp.vote_average = row6.vote_average;
									movieJoint_tmp.budget = row2.budget;
									movieJoint_tmp.revenue = row2.revenue;
									movieJoint = movieJoint_tmp;
// ###############################

								} // end of Var scope

								rejectedInnerJoin_tMap_1 = false;

								tos_count_tMap_1++;

								/**
								 * [tMap_1 main ] stop
								 */

								/**
								 * [tMap_1 process_data_begin ] start
								 */

								currentComponent = "tMap_1";

								/**
								 * [tMap_1 process_data_begin ] stop
								 */
// Start of branch "movieJoint"
								if (movieJoint != null) {

									/**
									 * [tFilterRow_1 main ] start
									 */

									currentComponent = "tFilterRow_1";

									if (execStat) {
										runStat.updateStatOnConnection(iterateId, 1, 1

												, "movieJoint"

										);
									}

									row8 = null;
									row14 = null;
									Operator_tFilterRow_1 ope_tFilterRow_1 = new Operator_tFilterRow_1("&&");
									ope_tFilterRow_1.matches(
											(movieJoint.date == null ? false
													: movieJoint.date.compareTo(
															TalendDate.parseDate("dd-MM-yyyy", "31-12-1999")) > 0),
											"date.compareTo(TalendDate.parseDate(\"dd-MM-yyyy\", \"31-12-1999\")) > 0 failed");

									if (ope_tFilterRow_1.getMatchFlag()) {
										if (row14 == null) {
											row14 = new row14Struct();
										}
										row14.id = movieJoint.id;
										row14.title = movieJoint.title;
										row14.date = movieJoint.date;
										row14.popularity = movieJoint.popularity;
										row14.vote_count = movieJoint.vote_count;
										row14.vote_average = movieJoint.vote_average;
										row14.budget = movieJoint.budget;
										row14.revenue = movieJoint.revenue;
										nb_line_ok_tFilterRow_1++;
									} else {
										if (row8 == null) {
											row8 = new row8Struct();
										}
										row8.id = movieJoint.id;
										row8.title = movieJoint.title;
										row8.date = movieJoint.date;
										row8.popularity = movieJoint.popularity;
										row8.vote_count = movieJoint.vote_count;
										row8.vote_average = movieJoint.vote_average;
										row8.budget = movieJoint.budget;
										row8.revenue = movieJoint.revenue;
										row8.errorMessage = ope_tFilterRow_1.getErrorMsg();
										nb_line_reject_tFilterRow_1++;
									}

									nb_line_tFilterRow_1++;

									tos_count_tFilterRow_1++;

									/**
									 * [tFilterRow_1 main ] stop
									 */

									/**
									 * [tFilterRow_1 process_data_begin ] start
									 */

									currentComponent = "tFilterRow_1";

									/**
									 * [tFilterRow_1 process_data_begin ] stop
									 */
// Start of branch "row14"
									if (row14 != null) {

										/**
										 * [tMap_2 main ] start
										 */

										currentComponent = "tMap_2";

										if (execStat) {
											runStat.updateStatOnConnection(iterateId, 1, 1

													, "row14"

											);
										}

										boolean hasCasePrimitiveKeyWithNull_tMap_2 = false;

										// ###############################
										// # Input tables (lookups)
										boolean rejectedInnerJoin_tMap_2 = false;
										boolean mainRowRejected_tMap_2 = false;

										// ###############################
										{ // start of Var scope

											// ###############################
											// # Vars tables

											Var__tMap_2__Struct Var = Var__tMap_2;
											Var.gain_perte = (row14.revenue - row14.budget);// ###############################
											// ###############################
											// # Output tables

											Joint_rev_budg_op = null;
											Joint_rev_budget_date = null;
											RatingXml = null;
											Joint_rev_budget_date2 = null;
											JointSheet2 = null;
											JoinSheet3 = null;

// # Output table : 'Joint_rev_budg_op'
											Joint_rev_budg_op_tmp.id = row14.id;
											Joint_rev_budg_op_tmp.title = row14.title;
											Joint_rev_budg_op_tmp.popularity = row14.popularity;
											Joint_rev_budg_op_tmp.budget = row14.budget;
											Joint_rev_budg_op_tmp.revenue = row14.revenue;
											Joint_rev_budg_op = Joint_rev_budg_op_tmp;

// # Output table : 'Joint_rev_budget_date'
											Joint_rev_budget_date_tmp.id = row14.id;
											Joint_rev_budget_date_tmp.title = row14.title;
											Joint_rev_budget_date_tmp.budget = row14.budget;
											Joint_rev_budget_date_tmp.revenue = row14.revenue;
											Joint_rev_budget_date_tmp.date = row14.date;
											Joint_rev_budget_date = Joint_rev_budget_date_tmp;

// # Output table : 'RatingXml'
											RatingXml_tmp.id = row14.id;
											RatingXml_tmp.title = row14.title;
											RatingXml_tmp.date = row14.date;
											RatingXml_tmp.popularity = row14.popularity;
											RatingXml_tmp.vote_count = row14.vote_count;
											RatingXml_tmp.vote_average = row14.vote_average;
											RatingXml = RatingXml_tmp;

// # Output table : 'Joint_rev_budget_date2'
											Joint_rev_budget_date2_tmp.id = row14.id;
											Joint_rev_budget_date2_tmp.title = row14.title;
											Joint_rev_budget_date2_tmp.date = row14.date;
											Joint_rev_budget_date2_tmp.budget = row14.budget;
											Joint_rev_budget_date2_tmp.revenue = row14.revenue;
											Joint_rev_budget_date2 = Joint_rev_budget_date2_tmp;

// # Output table : 'JointSheet2'
											JointSheet2_tmp.id = row14.id;
											JointSheet2_tmp.title = row14.title;
											JointSheet2_tmp.date = row14.date;
											JointSheet2_tmp.budget = row14.budget;
											JointSheet2_tmp.revenue = row14.revenue;
											JointSheet2 = JointSheet2_tmp;

// # Output table : 'JoinSheet3'
											JoinSheet3_tmp.id = row14.id;
											JoinSheet3_tmp.title = row14.title;
											JoinSheet3_tmp.date = row14.date;
											JoinSheet3_tmp.budget = row14.budget;
											JoinSheet3_tmp.revenue = row14.revenue;
											JoinSheet3_tmp.gain_perte = Var.gain_perte;
											JoinSheet3 = JoinSheet3_tmp;
// ###############################

										} // end of Var scope

										rejectedInnerJoin_tMap_2 = false;

										tos_count_tMap_2++;

										/**
										 * [tMap_2 main ] stop
										 */

										/**
										 * [tMap_2 process_data_begin ] start
										 */

										currentComponent = "tMap_2";

										/**
										 * [tMap_2 process_data_begin ] stop
										 */
// Start of branch "Joint_rev_budg_op"
										if (Joint_rev_budg_op != null) {

											/**
											 * [tLogRow_5 main ] start
											 */

											currentComponent = "tLogRow_5";

											if (execStat) {
												runStat.updateStatOnConnection(iterateId, 1, 1

														, "Joint_rev_budg_op"

												);
											}

///////////////////////		

											strBuffer_tLogRow_5 = new StringBuilder();

											if (Joint_rev_budg_op.id != null) { //

												strBuffer_tLogRow_5.append(String.valueOf(Joint_rev_budg_op.id));

											} //

											strBuffer_tLogRow_5.append("|");

											if (Joint_rev_budg_op.title != null) { //

												strBuffer_tLogRow_5.append(String.valueOf(Joint_rev_budg_op.title));

											} //

											strBuffer_tLogRow_5.append("|");

											if (Joint_rev_budg_op.popularity != null) { //

												strBuffer_tLogRow_5.append(
														FormatterUtils.formatUnwithE(Joint_rev_budg_op.popularity));

											} //

											strBuffer_tLogRow_5.append("|");

											if (Joint_rev_budg_op.budget != null) { //

												strBuffer_tLogRow_5.append(String.valueOf(Joint_rev_budg_op.budget));

											} //

											strBuffer_tLogRow_5.append("|");

											if (Joint_rev_budg_op.revenue != null) { //

												strBuffer_tLogRow_5.append(String.valueOf(Joint_rev_budg_op.revenue));

											} //

											if (globalMap.get("tLogRow_CONSOLE") != null) {
												consoleOut_tLogRow_5 = (java.io.PrintStream) globalMap
														.get("tLogRow_CONSOLE");
											} else {
												consoleOut_tLogRow_5 = new java.io.PrintStream(
														new java.io.BufferedOutputStream(System.out));
												globalMap.put("tLogRow_CONSOLE", consoleOut_tLogRow_5);
											}
											consoleOut_tLogRow_5.println(strBuffer_tLogRow_5.toString());
											consoleOut_tLogRow_5.flush();
											nb_line_tLogRow_5++;
//////

//////                    

///////////////////////    			

											row9 = Joint_rev_budg_op;

											tos_count_tLogRow_5++;

											/**
											 * [tLogRow_5 main ] stop
											 */

											/**
											 * [tLogRow_5 process_data_begin ] start
											 */

											currentComponent = "tLogRow_5";

											/**
											 * [tLogRow_5 process_data_begin ] stop
											 */

											/**
											 * [tSortRow_1_SortOut main ] start
											 */

											currentVirtualComponent = "tSortRow_1";

											currentComponent = "tSortRow_1_SortOut";

											if (execStat) {
												runStat.updateStatOnConnection(iterateId, 1, 1

														, "row9"

												);
											}

											Comparablerow9Struct arrayRowtSortRow_1_SortOut = new Comparablerow9Struct();

											arrayRowtSortRow_1_SortOut.id = row9.id;
											arrayRowtSortRow_1_SortOut.title = row9.title;
											arrayRowtSortRow_1_SortOut.popularity = row9.popularity;
											arrayRowtSortRow_1_SortOut.budget = row9.budget;
											arrayRowtSortRow_1_SortOut.revenue = row9.revenue;
											list_tSortRow_1_SortOut.add(arrayRowtSortRow_1_SortOut);

											tos_count_tSortRow_1_SortOut++;

											/**
											 * [tSortRow_1_SortOut main ] stop
											 */

											/**
											 * [tSortRow_1_SortOut process_data_begin ] start
											 */

											currentVirtualComponent = "tSortRow_1";

											currentComponent = "tSortRow_1_SortOut";

											/**
											 * [tSortRow_1_SortOut process_data_begin ] stop
											 */

											/**
											 * [tSortRow_1_SortOut process_data_end ] start
											 */

											currentVirtualComponent = "tSortRow_1";

											currentComponent = "tSortRow_1_SortOut";

											/**
											 * [tSortRow_1_SortOut process_data_end ] stop
											 */

											/**
											 * [tLogRow_5 process_data_end ] start
											 */

											currentComponent = "tLogRow_5";

											/**
											 * [tLogRow_5 process_data_end ] stop
											 */

										} // End of branch "Joint_rev_budg_op"

// Start of branch "Joint_rev_budget_date"
										if (Joint_rev_budget_date != null) {

											/**
											 * [tLogRow_6 main ] start
											 */

											currentComponent = "tLogRow_6";

											if (execStat) {
												runStat.updateStatOnConnection(iterateId, 1, 1

														, "Joint_rev_budget_date"

												);
											}

///////////////////////		

											strBuffer_tLogRow_6 = new StringBuilder();

											if (Joint_rev_budget_date.id != null) { //

												strBuffer_tLogRow_6.append(String.valueOf(Joint_rev_budget_date.id));

											} //

											strBuffer_tLogRow_6.append("|");

											if (Joint_rev_budget_date.title != null) { //

												strBuffer_tLogRow_6.append(String.valueOf(Joint_rev_budget_date.title));

											} //

											strBuffer_tLogRow_6.append("|");

											if (Joint_rev_budget_date.budget != null) { //

												strBuffer_tLogRow_6
														.append(String.valueOf(Joint_rev_budget_date.budget));

											} //

											strBuffer_tLogRow_6.append("|");

											if (Joint_rev_budget_date.revenue != null) { //

												strBuffer_tLogRow_6
														.append(String.valueOf(Joint_rev_budget_date.revenue));

											} //

											strBuffer_tLogRow_6.append("|");

											if (Joint_rev_budget_date.date != null) { //

												strBuffer_tLogRow_6.append(FormatterUtils
														.format_Date(Joint_rev_budget_date.date, "dd-MM-yyyy"));

											} //

											if (globalMap.get("tLogRow_CONSOLE") != null) {
												consoleOut_tLogRow_6 = (java.io.PrintStream) globalMap
														.get("tLogRow_CONSOLE");
											} else {
												consoleOut_tLogRow_6 = new java.io.PrintStream(
														new java.io.BufferedOutputStream(System.out));
												globalMap.put("tLogRow_CONSOLE", consoleOut_tLogRow_6);
											}
											consoleOut_tLogRow_6.println(strBuffer_tLogRow_6.toString());
											consoleOut_tLogRow_6.flush();
											nb_line_tLogRow_6++;
//////

//////                    

///////////////////////    			

											row11 = Joint_rev_budget_date;

											tos_count_tLogRow_6++;

											/**
											 * [tLogRow_6 main ] stop
											 */

											/**
											 * [tLogRow_6 process_data_begin ] start
											 */

											currentComponent = "tLogRow_6";

											/**
											 * [tLogRow_6 process_data_begin ] stop
											 */

											/**
											 * [tSortRow_2_SortOut main ] start
											 */

											currentVirtualComponent = "tSortRow_2";

											currentComponent = "tSortRow_2_SortOut";

											if (execStat) {
												runStat.updateStatOnConnection(iterateId, 1, 1

														, "row11"

												);
											}

											Comparablerow11Struct arrayRowtSortRow_2_SortOut = new Comparablerow11Struct();

											arrayRowtSortRow_2_SortOut.id = row11.id;
											arrayRowtSortRow_2_SortOut.title = row11.title;
											arrayRowtSortRow_2_SortOut.budget = row11.budget;
											arrayRowtSortRow_2_SortOut.revenue = row11.revenue;
											arrayRowtSortRow_2_SortOut.date = row11.date;
											list_tSortRow_2_SortOut.add(arrayRowtSortRow_2_SortOut);

											tos_count_tSortRow_2_SortOut++;

											/**
											 * [tSortRow_2_SortOut main ] stop
											 */

											/**
											 * [tSortRow_2_SortOut process_data_begin ] start
											 */

											currentVirtualComponent = "tSortRow_2";

											currentComponent = "tSortRow_2_SortOut";

											/**
											 * [tSortRow_2_SortOut process_data_begin ] stop
											 */

											/**
											 * [tSortRow_2_SortOut process_data_end ] start
											 */

											currentVirtualComponent = "tSortRow_2";

											currentComponent = "tSortRow_2_SortOut";

											/**
											 * [tSortRow_2_SortOut process_data_end ] stop
											 */

											/**
											 * [tLogRow_6 process_data_end ] start
											 */

											currentComponent = "tLogRow_6";

											/**
											 * [tLogRow_6 process_data_end ] stop
											 */

										} // End of branch "Joint_rev_budget_date"

// Start of branch "RatingXml"
										if (RatingXml != null) {

											/**
											 * [tLogRow_4 main ] start
											 */

											currentComponent = "tLogRow_4";

											if (execStat) {
												runStat.updateStatOnConnection(iterateId, 1, 1

														, "RatingXml"

												);
											}

///////////////////////		

											strBuffer_tLogRow_4 = new StringBuilder();

											if (RatingXml.id != null) { //

												strBuffer_tLogRow_4.append(String.valueOf(RatingXml.id));

											} //

											strBuffer_tLogRow_4.append("|");

											if (RatingXml.title != null) { //

												strBuffer_tLogRow_4.append(String.valueOf(RatingXml.title));

											} //

											strBuffer_tLogRow_4.append("|");

											if (RatingXml.date != null) { //

												strBuffer_tLogRow_4.append(
														FormatterUtils.format_Date(RatingXml.date, "dd-MM-yyyy"));

											} //

											strBuffer_tLogRow_4.append("|");

											if (RatingXml.popularity != null) { //

												strBuffer_tLogRow_4
														.append(FormatterUtils.formatUnwithE(RatingXml.popularity));

											} //

											strBuffer_tLogRow_4.append("|");

											if (RatingXml.vote_count != null) { //

												strBuffer_tLogRow_4.append(String.valueOf(RatingXml.vote_count));

											} //

											strBuffer_tLogRow_4.append("|");

											if (RatingXml.vote_average != null) { //

												strBuffer_tLogRow_4
														.append(FormatterUtils.formatUnwithE(RatingXml.vote_average));

											} //

											if (globalMap.get("tLogRow_CONSOLE") != null) {
												consoleOut_tLogRow_4 = (java.io.PrintStream) globalMap
														.get("tLogRow_CONSOLE");
											} else {
												consoleOut_tLogRow_4 = new java.io.PrintStream(
														new java.io.BufferedOutputStream(System.out));
												globalMap.put("tLogRow_CONSOLE", consoleOut_tLogRow_4);
											}
											consoleOut_tLogRow_4.println(strBuffer_tLogRow_4.toString());
											consoleOut_tLogRow_4.flush();
											nb_line_tLogRow_4++;
//////

//////                    

///////////////////////    			

											row13 = RatingXml;

											tos_count_tLogRow_4++;

											/**
											 * [tLogRow_4 main ] stop
											 */

											/**
											 * [tLogRow_4 process_data_begin ] start
											 */

											currentComponent = "tLogRow_4";

											/**
											 * [tLogRow_4 process_data_begin ] stop
											 */

											/**
											 * [tFileOutputXML_1 main ] start
											 */

											currentComponent = "tFileOutputXML_1";

											if (execStat) {
												runStat.updateStatOnConnection(iterateId, 1, 1

														, "row13"

												);
											}

											StringBuilder tempRes_tFileOutputXML_1 = new StringBuilder("<" + "row");
											tempRes_tFileOutputXML_1.append(">");
											out_tFileOutputXML_1.write(tempRes_tFileOutputXML_1.toString());

											out_tFileOutputXML_1.newLine();
											out_tFileOutputXML_1.write("<" + "id" + ">"
													+ ((row13.id == null) ? "" : (row13.id)) + "</" + "id" + ">");

											out_tFileOutputXML_1.newLine();
											out_tFileOutputXML_1.write("<" + "title" + ">"
													+ ((row13.title == null) ? ""
															: (TalendString.checkCDATAForXML(row13.title)))
													+ "</" + "title" + ">");

											out_tFileOutputXML_1.newLine();
											out_tFileOutputXML_1.write("<" + "date" + ">" + ((row13.date == null) ? ""
													: (TalendString.checkCDATAForXML(
															FormatterUtils.format_Date(row13.date, "dd-MM-yyyy"))))
													+ "</" + "date" + ">");

											out_tFileOutputXML_1.newLine();
											out_tFileOutputXML_1.write("<" + "popularity" + ">"
													+ ((row13.popularity == null) ? "" : (row13.popularity)) + "</"
													+ "popularity" + ">");

											out_tFileOutputXML_1.newLine();
											out_tFileOutputXML_1.write("<" + "vote_count" + ">"
													+ ((row13.vote_count == null) ? "" : (row13.vote_count)) + "</"
													+ "vote_count" + ">");

											out_tFileOutputXML_1.newLine();
											out_tFileOutputXML_1.write("<" + "vote_average" + ">"
													+ ((row13.vote_average == null) ? "" : (row13.vote_average)) + "</"
													+ "vote_average" + ">");

											out_tFileOutputXML_1.newLine();
											out_tFileOutputXML_1.write("</" + "row" + ">");

											out_tFileOutputXML_1.newLine();

											nb_line_tFileOutputXML_1++;

											tos_count_tFileOutputXML_1++;

											/**
											 * [tFileOutputXML_1 main ] stop
											 */

											/**
											 * [tFileOutputXML_1 process_data_begin ] start
											 */

											currentComponent = "tFileOutputXML_1";

											/**
											 * [tFileOutputXML_1 process_data_begin ] stop
											 */

											/**
											 * [tFileOutputXML_1 process_data_end ] start
											 */

											currentComponent = "tFileOutputXML_1";

											/**
											 * [tFileOutputXML_1 process_data_end ] stop
											 */

											/**
											 * [tLogRow_4 process_data_end ] start
											 */

											currentComponent = "tLogRow_4";

											/**
											 * [tLogRow_4 process_data_end ] stop
											 */

										} // End of branch "RatingXml"

// Start of branch "Joint_rev_budget_date2"
										if (Joint_rev_budget_date2 != null) {

											/**
											 * [tLogRow_7 main ] start
											 */

											currentComponent = "tLogRow_7";

											if (execStat) {
												runStat.updateStatOnConnection(iterateId, 1, 1

														, "Joint_rev_budget_date2"

												);
											}

///////////////////////		

											String[] row_tLogRow_7 = new String[5];

											if (Joint_rev_budget_date2.id != null) { //
												row_tLogRow_7[0] = String.valueOf(Joint_rev_budget_date2.id);

											} //

											if (Joint_rev_budget_date2.title != null) { //
												row_tLogRow_7[1] = String.valueOf(Joint_rev_budget_date2.title);

											} //

											if (Joint_rev_budget_date2.date != null) { //
												row_tLogRow_7[2] = FormatterUtils
														.format_Date(Joint_rev_budget_date2.date, "dd-MM-yyyy");

											} //

											if (Joint_rev_budget_date2.budget != null) { //
												row_tLogRow_7[3] = String.valueOf(Joint_rev_budget_date2.budget);

											} //

											if (Joint_rev_budget_date2.revenue != null) { //
												row_tLogRow_7[4] = String.valueOf(Joint_rev_budget_date2.revenue);

											} //

											util_tLogRow_7.addRow(row_tLogRow_7);
											nb_line_tLogRow_7++;
//////

//////                    

///////////////////////    			

											row15 = Joint_rev_budget_date2;

											tos_count_tLogRow_7++;

											/**
											 * [tLogRow_7 main ] stop
											 */

											/**
											 * [tLogRow_7 process_data_begin ] start
											 */

											currentComponent = "tLogRow_7";

											/**
											 * [tLogRow_7 process_data_begin ] stop
											 */

											/**
											 * [tSortRow_3_SortOut main ] start
											 */

											currentVirtualComponent = "tSortRow_3";

											currentComponent = "tSortRow_3_SortOut";

											if (execStat) {
												runStat.updateStatOnConnection(iterateId, 1, 1

														, "row15"

												);
											}

											Comparablerow15Struct arrayRowtSortRow_3_SortOut = new Comparablerow15Struct();

											arrayRowtSortRow_3_SortOut.id = row15.id;
											arrayRowtSortRow_3_SortOut.title = row15.title;
											arrayRowtSortRow_3_SortOut.date = row15.date;
											arrayRowtSortRow_3_SortOut.budget = row15.budget;
											arrayRowtSortRow_3_SortOut.revenue = row15.revenue;
											list_tSortRow_3_SortOut.add(arrayRowtSortRow_3_SortOut);

											tos_count_tSortRow_3_SortOut++;

											/**
											 * [tSortRow_3_SortOut main ] stop
											 */

											/**
											 * [tSortRow_3_SortOut process_data_begin ] start
											 */

											currentVirtualComponent = "tSortRow_3";

											currentComponent = "tSortRow_3_SortOut";

											/**
											 * [tSortRow_3_SortOut process_data_begin ] stop
											 */

											/**
											 * [tSortRow_3_SortOut process_data_end ] start
											 */

											currentVirtualComponent = "tSortRow_3";

											currentComponent = "tSortRow_3_SortOut";

											/**
											 * [tSortRow_3_SortOut process_data_end ] stop
											 */

											/**
											 * [tLogRow_7 process_data_end ] start
											 */

											currentComponent = "tLogRow_7";

											/**
											 * [tLogRow_7 process_data_end ] stop
											 */

										} // End of branch "Joint_rev_budget_date2"

// Start of branch "JointSheet2"
										if (JointSheet2 != null) {

											/**
											 * [tLogRow_8 main ] start
											 */

											currentComponent = "tLogRow_8";

											if (execStat) {
												runStat.updateStatOnConnection(iterateId, 1, 1

														, "JointSheet2"

												);
											}

///////////////////////		

											strBuffer_tLogRow_8 = new StringBuilder();

											if (JointSheet2.id != null) { //

												strBuffer_tLogRow_8.append(String.valueOf(JointSheet2.id));

											} //

											strBuffer_tLogRow_8.append("|");

											if (JointSheet2.title != null) { //

												strBuffer_tLogRow_8.append(String.valueOf(JointSheet2.title));

											} //

											strBuffer_tLogRow_8.append("|");

											if (JointSheet2.date != null) { //

												strBuffer_tLogRow_8.append(
														FormatterUtils.format_Date(JointSheet2.date, "dd-MM-yyyy"));

											} //

											strBuffer_tLogRow_8.append("|");

											if (JointSheet2.budget != null) { //

												strBuffer_tLogRow_8.append(String.valueOf(JointSheet2.budget));

											} //

											strBuffer_tLogRow_8.append("|");

											if (JointSheet2.revenue != null) { //

												strBuffer_tLogRow_8.append(String.valueOf(JointSheet2.revenue));

											} //

											if (globalMap.get("tLogRow_CONSOLE") != null) {
												consoleOut_tLogRow_8 = (java.io.PrintStream) globalMap
														.get("tLogRow_CONSOLE");
											} else {
												consoleOut_tLogRow_8 = new java.io.PrintStream(
														new java.io.BufferedOutputStream(System.out));
												globalMap.put("tLogRow_CONSOLE", consoleOut_tLogRow_8);
											}
											consoleOut_tLogRow_8.println(strBuffer_tLogRow_8.toString());
											consoleOut_tLogRow_8.flush();
											nb_line_tLogRow_8++;
//////

//////                    

///////////////////////    			

											row17 = JointSheet2;

											tos_count_tLogRow_8++;

											/**
											 * [tLogRow_8 main ] stop
											 */

											/**
											 * [tLogRow_8 process_data_begin ] start
											 */

											currentComponent = "tLogRow_8";

											/**
											 * [tLogRow_8 process_data_begin ] stop
											 */

											/**
											 * [tAggregateRow_1_AGGOUT main ] start
											 */

											currentVirtualComponent = "tAggregateRow_1";

											currentComponent = "tAggregateRow_1_AGGOUT";

											if (execStat) {
												runStat.updateStatOnConnection(iterateId, 1, 1

														, "row17"

												);
											}

											operation_finder_tAggregateRow_1.date = row17.date;

											operation_finder_tAggregateRow_1.hashCodeDirty = true;

											operation_result_tAggregateRow_1 = hash_tAggregateRow_1
													.get(operation_finder_tAggregateRow_1);

											if (operation_result_tAggregateRow_1 == null) { // G_OutMain_AggR_001

												operation_result_tAggregateRow_1 = new AggOperationStruct_tAggregateRow_1();

												operation_result_tAggregateRow_1.date = operation_finder_tAggregateRow_1.date;

												hash_tAggregateRow_1.put(operation_result_tAggregateRow_1,
														operation_result_tAggregateRow_1);

											} // G_OutMain_AggR_001

											if (operation_result_tAggregateRow_1.revenue_sum == null) {
												operation_result_tAggregateRow_1.revenue_sum = (long) 0;
											}

											if (row17.revenue != null)
												operation_result_tAggregateRow_1.revenue_sum += row17.revenue;
											if (operation_result_tAggregateRow_1.budget_sum == null) {
												operation_result_tAggregateRow_1.budget_sum = (int) 0;
											}

											if (row17.budget != null)
												operation_result_tAggregateRow_1.budget_sum += row17.budget;
											operation_result_tAggregateRow_1.id_clmCount++;
											operation_result_tAggregateRow_1.count++;

											tos_count_tAggregateRow_1_AGGOUT++;

											/**
											 * [tAggregateRow_1_AGGOUT main ] stop
											 */

											/**
											 * [tAggregateRow_1_AGGOUT process_data_begin ] start
											 */

											currentVirtualComponent = "tAggregateRow_1";

											currentComponent = "tAggregateRow_1_AGGOUT";

											/**
											 * [tAggregateRow_1_AGGOUT process_data_begin ] stop
											 */

											/**
											 * [tAggregateRow_1_AGGOUT process_data_end ] start
											 */

											currentVirtualComponent = "tAggregateRow_1";

											currentComponent = "tAggregateRow_1_AGGOUT";

											/**
											 * [tAggregateRow_1_AGGOUT process_data_end ] stop
											 */

											/**
											 * [tLogRow_8 process_data_end ] start
											 */

											currentComponent = "tLogRow_8";

											/**
											 * [tLogRow_8 process_data_end ] stop
											 */

										} // End of branch "JointSheet2"

// Start of branch "JoinSheet3"
										if (JoinSheet3 != null) {

											/**
											 * [tLogRow_9 main ] start
											 */

											currentComponent = "tLogRow_9";

											if (execStat) {
												runStat.updateStatOnConnection(iterateId, 1, 1

														, "JoinSheet3"

												);
											}

///////////////////////		

											strBuffer_tLogRow_9 = new StringBuilder();

											if (JoinSheet3.id != null) { //

												strBuffer_tLogRow_9.append(String.valueOf(JoinSheet3.id));

											} //

											strBuffer_tLogRow_9.append("|");

											if (JoinSheet3.title != null) { //

												strBuffer_tLogRow_9.append(String.valueOf(JoinSheet3.title));

											} //

											strBuffer_tLogRow_9.append("|");

											if (JoinSheet3.date != null) { //

												strBuffer_tLogRow_9.append(
														FormatterUtils.format_Date(JoinSheet3.date, "dd-MM-yyyy"));

											} //

											strBuffer_tLogRow_9.append("|");

											if (JoinSheet3.budget != null) { //

												strBuffer_tLogRow_9.append(String.valueOf(JoinSheet3.budget));

											} //

											strBuffer_tLogRow_9.append("|");

											if (JoinSheet3.revenue != null) { //

												strBuffer_tLogRow_9.append(String.valueOf(JoinSheet3.revenue));

											} //

											strBuffer_tLogRow_9.append("|");

											if (JoinSheet3.gain_perte != null) { //

												strBuffer_tLogRow_9.append(String.valueOf(JoinSheet3.gain_perte));

											} //

											if (globalMap.get("tLogRow_CONSOLE") != null) {
												consoleOut_tLogRow_9 = (java.io.PrintStream) globalMap
														.get("tLogRow_CONSOLE");
											} else {
												consoleOut_tLogRow_9 = new java.io.PrintStream(
														new java.io.BufferedOutputStream(System.out));
												globalMap.put("tLogRow_CONSOLE", consoleOut_tLogRow_9);
											}
											consoleOut_tLogRow_9.println(strBuffer_tLogRow_9.toString());
											consoleOut_tLogRow_9.flush();
											nb_line_tLogRow_9++;
//////

//////                    

///////////////////////    			

											row20 = JoinSheet3;

											tos_count_tLogRow_9++;

											/**
											 * [tLogRow_9 main ] stop
											 */

											/**
											 * [tLogRow_9 process_data_begin ] start
											 */

											currentComponent = "tLogRow_9";

											/**
											 * [tLogRow_9 process_data_begin ] stop
											 */

											/**
											 * [tSortRow_5_SortOut main ] start
											 */

											currentVirtualComponent = "tSortRow_5";

											currentComponent = "tSortRow_5_SortOut";

											if (execStat) {
												runStat.updateStatOnConnection(iterateId, 1, 1

														, "row20"

												);
											}

											Comparablerow20Struct arrayRowtSortRow_5_SortOut = new Comparablerow20Struct();

											arrayRowtSortRow_5_SortOut.id = row20.id;
											arrayRowtSortRow_5_SortOut.title = row20.title;
											arrayRowtSortRow_5_SortOut.date = row20.date;
											arrayRowtSortRow_5_SortOut.budget = row20.budget;
											arrayRowtSortRow_5_SortOut.revenue = row20.revenue;
											arrayRowtSortRow_5_SortOut.gain_perte = row20.gain_perte;
											list_tSortRow_5_SortOut.add(arrayRowtSortRow_5_SortOut);

											tos_count_tSortRow_5_SortOut++;

											/**
											 * [tSortRow_5_SortOut main ] stop
											 */

											/**
											 * [tSortRow_5_SortOut process_data_begin ] start
											 */

											currentVirtualComponent = "tSortRow_5";

											currentComponent = "tSortRow_5_SortOut";

											/**
											 * [tSortRow_5_SortOut process_data_begin ] stop
											 */

											/**
											 * [tSortRow_5_SortOut process_data_end ] start
											 */

											currentVirtualComponent = "tSortRow_5";

											currentComponent = "tSortRow_5_SortOut";

											/**
											 * [tSortRow_5_SortOut process_data_end ] stop
											 */

											/**
											 * [tLogRow_9 process_data_end ] start
											 */

											currentComponent = "tLogRow_9";

											/**
											 * [tLogRow_9 process_data_end ] stop
											 */

										} // End of branch "JoinSheet3"

										/**
										 * [tMap_2 process_data_end ] start
										 */

										currentComponent = "tMap_2";

										/**
										 * [tMap_2 process_data_end ] stop
										 */

									} // End of branch "row14"

// Start of branch "row8"
									if (row8 != null) {

										/**
										 * [tFileOutputDelimited_1 main ] start
										 */

										currentComponent = "tFileOutputDelimited_1";

										if (execStat) {
											runStat.updateStatOnConnection(iterateId, 1, 1

													, "row8"

											);
										}

										StringBuilder sb_tFileOutputDelimited_1 = new StringBuilder();
										if (row8.id != null) {
											sb_tFileOutputDelimited_1.append(row8.id);
										}
										sb_tFileOutputDelimited_1.append(OUT_DELIM_tFileOutputDelimited_1);
										if (row8.title != null) {
											sb_tFileOutputDelimited_1.append(row8.title);
										}
										sb_tFileOutputDelimited_1.append(OUT_DELIM_tFileOutputDelimited_1);
										if (row8.date != null) {
											sb_tFileOutputDelimited_1
													.append(FormatterUtils.format_Date(row8.date, "dd-MM-yyyy"));
										}
										sb_tFileOutputDelimited_1.append(OUT_DELIM_tFileOutputDelimited_1);
										if (row8.popularity != null) {
											sb_tFileOutputDelimited_1.append(row8.popularity);
										}
										sb_tFileOutputDelimited_1.append(OUT_DELIM_tFileOutputDelimited_1);
										if (row8.vote_count != null) {
											sb_tFileOutputDelimited_1.append(row8.vote_count);
										}
										sb_tFileOutputDelimited_1.append(OUT_DELIM_tFileOutputDelimited_1);
										if (row8.vote_average != null) {
											sb_tFileOutputDelimited_1.append(row8.vote_average);
										}
										sb_tFileOutputDelimited_1.append(OUT_DELIM_tFileOutputDelimited_1);
										if (row8.budget != null) {
											sb_tFileOutputDelimited_1.append(row8.budget);
										}
										sb_tFileOutputDelimited_1.append(OUT_DELIM_tFileOutputDelimited_1);
										if (row8.revenue != null) {
											sb_tFileOutputDelimited_1.append(row8.revenue);
										}
										sb_tFileOutputDelimited_1.append(OUT_DELIM_ROWSEP_tFileOutputDelimited_1);

										nb_line_tFileOutputDelimited_1++;
										resourceMap.put("nb_line_tFileOutputDelimited_1",
												nb_line_tFileOutputDelimited_1);

										outtFileOutputDelimited_1.write(sb_tFileOutputDelimited_1.toString());

										tos_count_tFileOutputDelimited_1++;

										/**
										 * [tFileOutputDelimited_1 main ] stop
										 */

										/**
										 * [tFileOutputDelimited_1 process_data_begin ] start
										 */

										currentComponent = "tFileOutputDelimited_1";

										/**
										 * [tFileOutputDelimited_1 process_data_begin ] stop
										 */

										/**
										 * [tFileOutputDelimited_1 process_data_end ] start
										 */

										currentComponent = "tFileOutputDelimited_1";

										/**
										 * [tFileOutputDelimited_1 process_data_end ] stop
										 */

									} // End of branch "row8"

									/**
									 * [tFilterRow_1 process_data_end ] start
									 */

									currentComponent = "tFilterRow_1";

									/**
									 * [tFilterRow_1 process_data_end ] stop
									 */

								} // End of branch "movieJoint"

								/**
								 * [tMap_1 process_data_end ] start
								 */

								currentComponent = "tMap_1";

								/**
								 * [tMap_1 process_data_end ] stop
								 */

								/**
								 * [tFilterColumns_1 process_data_end ] start
								 */

								currentComponent = "tFilterColumns_1";

								/**
								 * [tFilterColumns_1 process_data_end ] stop
								 */

								/**
								 * [tLogRow_1 process_data_end ] start
								 */

								currentComponent = "tLogRow_1";

								/**
								 * [tLogRow_1 process_data_end ] stop
								 */

							} // End of branch "row3"

							/**
							 * [tFileInputExcel_1 process_data_end ] start
							 */

							currentComponent = "tFileInputExcel_1";

							/**
							 * [tFileInputExcel_1 process_data_end ] stop
							 */

							/**
							 * [tFileInputExcel_1 end ] start
							 */

							currentComponent = "tFileInputExcel_1";

						}

						globalMap.put("tFileInputExcel_1_NB_LINE", nb_line_tFileInputExcel_1);

					}

				} finally {

					if (!(source_tFileInputExcel_1 instanceof java.io.InputStream)) {
						workbook_tFileInputExcel_1.close();
					}

				}

				ok_Hash.put("tFileInputExcel_1", true);
				end_Hash.put("tFileInputExcel_1", System.currentTimeMillis());

				/**
				 * [tFileInputExcel_1 end ] stop
				 */

				/**
				 * [tLogRow_1 end ] start
				 */

				currentComponent = "tLogRow_1";

//////

				java.io.PrintStream consoleOut_tLogRow_1 = null;
				if (globalMap.get("tLogRow_CONSOLE") != null) {
					consoleOut_tLogRow_1 = (java.io.PrintStream) globalMap.get("tLogRow_CONSOLE");
				} else {
					consoleOut_tLogRow_1 = new java.io.PrintStream(new java.io.BufferedOutputStream(System.out));
					globalMap.put("tLogRow_CONSOLE", consoleOut_tLogRow_1);
				}

				consoleOut_tLogRow_1.println(util_tLogRow_1.format().toString());
				consoleOut_tLogRow_1.flush();
//////
				globalMap.put("tLogRow_1_NB_LINE", nb_line_tLogRow_1);

///////////////////////    			

				if (execStat) {
					runStat.updateStat(resourceMap, iterateId, 2, 0, "row3");
				}

				ok_Hash.put("tLogRow_1", true);
				end_Hash.put("tLogRow_1", System.currentTimeMillis());

				/**
				 * [tLogRow_1 end ] stop
				 */

				/**
				 * [tFilterColumns_1 end ] start
				 */

				currentComponent = "tFilterColumns_1";

				globalMap.put("tFilterColumns_1_NB_LINE", nb_line_tFilterColumns_1);
				if (execStat) {
					runStat.updateStat(resourceMap, iterateId, 2, 0, "row5");
				}

				ok_Hash.put("tFilterColumns_1", true);
				end_Hash.put("tFilterColumns_1", System.currentTimeMillis());

				/**
				 * [tFilterColumns_1 end ] stop
				 */

				/**
				 * [tMap_1 end ] start
				 */

				currentComponent = "tMap_1";

// ###############################
// # Lookup hashes releasing
				if (tHash_Lookup_row6 != null) {
					tHash_Lookup_row6.endGet();
				}
				globalMap.remove("tHash_Lookup_row6");

				if (tHash_Lookup_row2 != null) {
					tHash_Lookup_row2.endGet();
				}
				globalMap.remove("tHash_Lookup_row2");

// ###############################      

				if (execStat) {
					runStat.updateStat(resourceMap, iterateId, 2, 0, "row7");
				}

				ok_Hash.put("tMap_1", true);
				end_Hash.put("tMap_1", System.currentTimeMillis());

				/**
				 * [tMap_1 end ] stop
				 */

				/**
				 * [tFilterRow_1 end ] start
				 */

				currentComponent = "tFilterRow_1";

				globalMap.put("tFilterRow_1_NB_LINE", nb_line_tFilterRow_1);
				globalMap.put("tFilterRow_1_NB_LINE_OK", nb_line_ok_tFilterRow_1);
				globalMap.put("tFilterRow_1_NB_LINE_REJECT", nb_line_reject_tFilterRow_1);

				if (execStat) {
					runStat.updateStat(resourceMap, iterateId, 2, 0, "movieJoint");
				}

				ok_Hash.put("tFilterRow_1", true);
				end_Hash.put("tFilterRow_1", System.currentTimeMillis());

				/**
				 * [tFilterRow_1 end ] stop
				 */

				/**
				 * [tMap_2 end ] start
				 */

				currentComponent = "tMap_2";

// ###############################
// # Lookup hashes releasing
// ###############################      

				if (execStat) {
					runStat.updateStat(resourceMap, iterateId, 2, 0, "row14");
				}

				ok_Hash.put("tMap_2", true);
				end_Hash.put("tMap_2", System.currentTimeMillis());

				/**
				 * [tMap_2 end ] stop
				 */

				/**
				 * [tLogRow_5 end ] start
				 */

				currentComponent = "tLogRow_5";

//////
//////
				globalMap.put("tLogRow_5_NB_LINE", nb_line_tLogRow_5);

///////////////////////    			

				if (execStat) {
					runStat.updateStat(resourceMap, iterateId, 2, 0, "Joint_rev_budg_op");
				}

				ok_Hash.put("tLogRow_5", true);
				end_Hash.put("tLogRow_5", System.currentTimeMillis());

				/**
				 * [tLogRow_5 end ] stop
				 */

				/**
				 * [tSortRow_1_SortOut end ] start
				 */

				currentVirtualComponent = "tSortRow_1";

				currentComponent = "tSortRow_1_SortOut";

				row9Struct[] array_tSortRow_1_SortOut = list_tSortRow_1_SortOut.toArray(new Comparablerow9Struct[0]);

				java.util.Arrays.sort(array_tSortRow_1_SortOut);

				globalMap.put("tSortRow_1", array_tSortRow_1_SortOut);

				if (execStat) {
					runStat.updateStat(resourceMap, iterateId, 2, 0, "row9");
				}

				ok_Hash.put("tSortRow_1_SortOut", true);
				end_Hash.put("tSortRow_1_SortOut", System.currentTimeMillis());

				/**
				 * [tSortRow_1_SortOut end ] stop
				 */

				/**
				 * [tFileOutputDelimited_2 begin ] start
				 */

				ok_Hash.put("tFileOutputDelimited_2", false);
				start_Hash.put("tFileOutputDelimited_2", System.currentTimeMillis());

				currentComponent = "tFileOutputDelimited_2";

				if (execStat) {
					runStat.updateStatOnConnection(resourceMap, iterateId, 0, 0, "row10");
				}

				int tos_count_tFileOutputDelimited_2 = 0;

				String fileName_tFileOutputDelimited_2 = "";
				fileName_tFileOutputDelimited_2 = (new java.io.File(
						"C:/Users/ananf/OneDrive/Documents/Aivancity/DATA pipeline/Client1.csv")).getAbsolutePath()
								.replace("\\", "/");
				String fullName_tFileOutputDelimited_2 = null;
				String extension_tFileOutputDelimited_2 = null;
				String directory_tFileOutputDelimited_2 = null;
				if ((fileName_tFileOutputDelimited_2.indexOf("/") != -1)) {
					if (fileName_tFileOutputDelimited_2.lastIndexOf(".") < fileName_tFileOutputDelimited_2
							.lastIndexOf("/")) {
						fullName_tFileOutputDelimited_2 = fileName_tFileOutputDelimited_2;
						extension_tFileOutputDelimited_2 = "";
					} else {
						fullName_tFileOutputDelimited_2 = fileName_tFileOutputDelimited_2.substring(0,
								fileName_tFileOutputDelimited_2.lastIndexOf("."));
						extension_tFileOutputDelimited_2 = fileName_tFileOutputDelimited_2
								.substring(fileName_tFileOutputDelimited_2.lastIndexOf("."));
					}
					directory_tFileOutputDelimited_2 = fileName_tFileOutputDelimited_2.substring(0,
							fileName_tFileOutputDelimited_2.lastIndexOf("/"));
				} else {
					if (fileName_tFileOutputDelimited_2.lastIndexOf(".") != -1) {
						fullName_tFileOutputDelimited_2 = fileName_tFileOutputDelimited_2.substring(0,
								fileName_tFileOutputDelimited_2.lastIndexOf("."));
						extension_tFileOutputDelimited_2 = fileName_tFileOutputDelimited_2
								.substring(fileName_tFileOutputDelimited_2.lastIndexOf("."));
					} else {
						fullName_tFileOutputDelimited_2 = fileName_tFileOutputDelimited_2;
						extension_tFileOutputDelimited_2 = "";
					}
					directory_tFileOutputDelimited_2 = "";
				}
				boolean isFileGenerated_tFileOutputDelimited_2 = true;
				java.io.File filetFileOutputDelimited_2 = new java.io.File(fileName_tFileOutputDelimited_2);
				globalMap.put("tFileOutputDelimited_2_FILE_NAME", fileName_tFileOutputDelimited_2);
				if (filetFileOutputDelimited_2.exists()) {
					throw new RuntimeException("The particular file \"" + filetFileOutputDelimited_2.getAbsoluteFile()
							+ "\" already exist. If you want to overwrite the file, please uncheck the"
							+ " \"Throw an error if the file already exist\" option in Advanced settings.");
				}
				int nb_line_tFileOutputDelimited_2 = 0;
				int splitedFileNo_tFileOutputDelimited_2 = 0;
				int currentRow_tFileOutputDelimited_2 = 0;

				final String OUT_DELIM_tFileOutputDelimited_2 = /** Start field tFileOutputDelimited_2:FIELDSEPARATOR */
						";"/** End field tFileOutputDelimited_2:FIELDSEPARATOR */
				;

				final String OUT_DELIM_ROWSEP_tFileOutputDelimited_2 = /**
																		 * Start field
																		 * tFileOutputDelimited_2:ROWSEPARATOR
																		 */
						"\n"/** End field tFileOutputDelimited_2:ROWSEPARATOR */
				;

				// create directory only if not exists
				if (directory_tFileOutputDelimited_2 != null && directory_tFileOutputDelimited_2.trim().length() != 0) {
					java.io.File dir_tFileOutputDelimited_2 = new java.io.File(directory_tFileOutputDelimited_2);
					if (!dir_tFileOutputDelimited_2.exists()) {
						dir_tFileOutputDelimited_2.mkdirs();
					}
				}

				// routines.system.Row
				java.io.Writer outtFileOutputDelimited_2 = null;

				java.io.File fileToDelete_tFileOutputDelimited_2 = new java.io.File(fileName_tFileOutputDelimited_2);
				if (fileToDelete_tFileOutputDelimited_2.exists()) {
					fileToDelete_tFileOutputDelimited_2.delete();
				}
				outtFileOutputDelimited_2 = new java.io.BufferedWriter(new java.io.OutputStreamWriter(
						new java.io.FileOutputStream(fileName_tFileOutputDelimited_2, false), "ISO-8859-15"));
				if (filetFileOutputDelimited_2.length() == 0) {
					outtFileOutputDelimited_2.write("id");
					outtFileOutputDelimited_2.write(OUT_DELIM_tFileOutputDelimited_2);
					outtFileOutputDelimited_2.write("title");
					outtFileOutputDelimited_2.write(OUT_DELIM_tFileOutputDelimited_2);
					outtFileOutputDelimited_2.write("popularity");
					outtFileOutputDelimited_2.write(OUT_DELIM_tFileOutputDelimited_2);
					outtFileOutputDelimited_2.write("budget");
					outtFileOutputDelimited_2.write(OUT_DELIM_tFileOutputDelimited_2);
					outtFileOutputDelimited_2.write("revenue");
					outtFileOutputDelimited_2.write(OUT_DELIM_ROWSEP_tFileOutputDelimited_2);
					outtFileOutputDelimited_2.flush();
				}

				resourceMap.put("out_tFileOutputDelimited_2", outtFileOutputDelimited_2);
				resourceMap.put("nb_line_tFileOutputDelimited_2", nb_line_tFileOutputDelimited_2);

				/**
				 * [tFileOutputDelimited_2 begin ] stop
				 */

				/**
				 * [tSortRow_1_SortIn begin ] start
				 */

				ok_Hash.put("tSortRow_1_SortIn", false);
				start_Hash.put("tSortRow_1_SortIn", System.currentTimeMillis());

				currentVirtualComponent = "tSortRow_1";

				currentComponent = "tSortRow_1_SortIn";

				int tos_count_tSortRow_1_SortIn = 0;

				row9Struct[] array_tSortRow_1_SortIn = (row9Struct[]) globalMap.remove("tSortRow_1");

				int nb_line_tSortRow_1_SortIn = 0;

				row9Struct current_tSortRow_1_SortIn = null;

				for (int i_tSortRow_1_SortIn = 0; i_tSortRow_1_SortIn < array_tSortRow_1_SortIn.length; i_tSortRow_1_SortIn++) {
					current_tSortRow_1_SortIn = array_tSortRow_1_SortIn[i_tSortRow_1_SortIn];
					row10.id = current_tSortRow_1_SortIn.id;
					row10.title = current_tSortRow_1_SortIn.title;
					row10.popularity = current_tSortRow_1_SortIn.popularity;
					row10.budget = current_tSortRow_1_SortIn.budget;
					row10.revenue = current_tSortRow_1_SortIn.revenue;
					// increase number of line sorted
					nb_line_tSortRow_1_SortIn++;

					/**
					 * [tSortRow_1_SortIn begin ] stop
					 */

					/**
					 * [tSortRow_1_SortIn main ] start
					 */

					currentVirtualComponent = "tSortRow_1";

					currentComponent = "tSortRow_1_SortIn";

					tos_count_tSortRow_1_SortIn++;

					/**
					 * [tSortRow_1_SortIn main ] stop
					 */

					/**
					 * [tSortRow_1_SortIn process_data_begin ] start
					 */

					currentVirtualComponent = "tSortRow_1";

					currentComponent = "tSortRow_1_SortIn";

					/**
					 * [tSortRow_1_SortIn process_data_begin ] stop
					 */

					/**
					 * [tFileOutputDelimited_2 main ] start
					 */

					currentComponent = "tFileOutputDelimited_2";

					if (execStat) {
						runStat.updateStatOnConnection(iterateId, 1, 1

								, "row10"

						);
					}

					StringBuilder sb_tFileOutputDelimited_2 = new StringBuilder();
					if (row10.id != null) {
						sb_tFileOutputDelimited_2.append(row10.id);
					}
					sb_tFileOutputDelimited_2.append(OUT_DELIM_tFileOutputDelimited_2);
					if (row10.title != null) {
						sb_tFileOutputDelimited_2.append(row10.title);
					}
					sb_tFileOutputDelimited_2.append(OUT_DELIM_tFileOutputDelimited_2);
					if (row10.popularity != null) {
						sb_tFileOutputDelimited_2.append(row10.popularity);
					}
					sb_tFileOutputDelimited_2.append(OUT_DELIM_tFileOutputDelimited_2);
					if (row10.budget != null) {
						sb_tFileOutputDelimited_2.append(row10.budget);
					}
					sb_tFileOutputDelimited_2.append(OUT_DELIM_tFileOutputDelimited_2);
					if (row10.revenue != null) {
						sb_tFileOutputDelimited_2.append(row10.revenue);
					}
					sb_tFileOutputDelimited_2.append(OUT_DELIM_ROWSEP_tFileOutputDelimited_2);

					nb_line_tFileOutputDelimited_2++;
					resourceMap.put("nb_line_tFileOutputDelimited_2", nb_line_tFileOutputDelimited_2);

					outtFileOutputDelimited_2.write(sb_tFileOutputDelimited_2.toString());

					tos_count_tFileOutputDelimited_2++;

					/**
					 * [tFileOutputDelimited_2 main ] stop
					 */

					/**
					 * [tFileOutputDelimited_2 process_data_begin ] start
					 */

					currentComponent = "tFileOutputDelimited_2";

					/**
					 * [tFileOutputDelimited_2 process_data_begin ] stop
					 */

					/**
					 * [tFileOutputDelimited_2 process_data_end ] start
					 */

					currentComponent = "tFileOutputDelimited_2";

					/**
					 * [tFileOutputDelimited_2 process_data_end ] stop
					 */

					/**
					 * [tSortRow_1_SortIn process_data_end ] start
					 */

					currentVirtualComponent = "tSortRow_1";

					currentComponent = "tSortRow_1_SortIn";

					/**
					 * [tSortRow_1_SortIn process_data_end ] stop
					 */

					/**
					 * [tSortRow_1_SortIn end ] start
					 */

					currentVirtualComponent = "tSortRow_1";

					currentComponent = "tSortRow_1_SortIn";

				}

				globalMap.put("tSortRow_1_SortIn_NB_LINE", nb_line_tSortRow_1_SortIn);

				ok_Hash.put("tSortRow_1_SortIn", true);
				end_Hash.put("tSortRow_1_SortIn", System.currentTimeMillis());

				/**
				 * [tSortRow_1_SortIn end ] stop
				 */

				/**
				 * [tFileOutputDelimited_2 end ] start
				 */

				currentComponent = "tFileOutputDelimited_2";

				if (outtFileOutputDelimited_2 != null) {
					outtFileOutputDelimited_2.flush();
					outtFileOutputDelimited_2.close();
				}

				globalMap.put("tFileOutputDelimited_2_NB_LINE", nb_line_tFileOutputDelimited_2);
				globalMap.put("tFileOutputDelimited_2_FILE_NAME", fileName_tFileOutputDelimited_2);

				resourceMap.put("finish_tFileOutputDelimited_2", true);

				if (execStat) {
					runStat.updateStat(resourceMap, iterateId, 2, 0, "row10");
				}

				ok_Hash.put("tFileOutputDelimited_2", true);
				end_Hash.put("tFileOutputDelimited_2", System.currentTimeMillis());

				/**
				 * [tFileOutputDelimited_2 end ] stop
				 */

				/**
				 * [tLogRow_6 end ] start
				 */

				currentComponent = "tLogRow_6";

//////
//////
				globalMap.put("tLogRow_6_NB_LINE", nb_line_tLogRow_6);

///////////////////////    			

				if (execStat) {
					runStat.updateStat(resourceMap, iterateId, 2, 0, "Joint_rev_budget_date");
				}

				ok_Hash.put("tLogRow_6", true);
				end_Hash.put("tLogRow_6", System.currentTimeMillis());

				/**
				 * [tLogRow_6 end ] stop
				 */

				/**
				 * [tSortRow_2_SortOut end ] start
				 */

				currentVirtualComponent = "tSortRow_2";

				currentComponent = "tSortRow_2_SortOut";

				row11Struct[] array_tSortRow_2_SortOut = list_tSortRow_2_SortOut.toArray(new Comparablerow11Struct[0]);

				java.util.Arrays.sort(array_tSortRow_2_SortOut);

				globalMap.put("tSortRow_2", array_tSortRow_2_SortOut);

				if (execStat) {
					runStat.updateStat(resourceMap, iterateId, 2, 0, "row11");
				}

				ok_Hash.put("tSortRow_2_SortOut", true);
				end_Hash.put("tSortRow_2_SortOut", System.currentTimeMillis());

				/**
				 * [tSortRow_2_SortOut end ] stop
				 */

				/**
				 * [tFileOutputDelimited_3 begin ] start
				 */

				ok_Hash.put("tFileOutputDelimited_3", false);
				start_Hash.put("tFileOutputDelimited_3", System.currentTimeMillis());

				currentComponent = "tFileOutputDelimited_3";

				if (execStat) {
					runStat.updateStatOnConnection(resourceMap, iterateId, 0, 0, "row12");
				}

				int tos_count_tFileOutputDelimited_3 = 0;

				String fileName_tFileOutputDelimited_3 = "";
				fileName_tFileOutputDelimited_3 = (new java.io.File(
						"C:/Users/ananf/OneDrive/Documents/Aivancity/DATA pipeline/Client2.csv")).getAbsolutePath()
								.replace("\\", "/");
				String fullName_tFileOutputDelimited_3 = null;
				String extension_tFileOutputDelimited_3 = null;
				String directory_tFileOutputDelimited_3 = null;
				if ((fileName_tFileOutputDelimited_3.indexOf("/") != -1)) {
					if (fileName_tFileOutputDelimited_3.lastIndexOf(".") < fileName_tFileOutputDelimited_3
							.lastIndexOf("/")) {
						fullName_tFileOutputDelimited_3 = fileName_tFileOutputDelimited_3;
						extension_tFileOutputDelimited_3 = "";
					} else {
						fullName_tFileOutputDelimited_3 = fileName_tFileOutputDelimited_3.substring(0,
								fileName_tFileOutputDelimited_3.lastIndexOf("."));
						extension_tFileOutputDelimited_3 = fileName_tFileOutputDelimited_3
								.substring(fileName_tFileOutputDelimited_3.lastIndexOf("."));
					}
					directory_tFileOutputDelimited_3 = fileName_tFileOutputDelimited_3.substring(0,
							fileName_tFileOutputDelimited_3.lastIndexOf("/"));
				} else {
					if (fileName_tFileOutputDelimited_3.lastIndexOf(".") != -1) {
						fullName_tFileOutputDelimited_3 = fileName_tFileOutputDelimited_3.substring(0,
								fileName_tFileOutputDelimited_3.lastIndexOf("."));
						extension_tFileOutputDelimited_3 = fileName_tFileOutputDelimited_3
								.substring(fileName_tFileOutputDelimited_3.lastIndexOf("."));
					} else {
						fullName_tFileOutputDelimited_3 = fileName_tFileOutputDelimited_3;
						extension_tFileOutputDelimited_3 = "";
					}
					directory_tFileOutputDelimited_3 = "";
				}
				boolean isFileGenerated_tFileOutputDelimited_3 = true;
				java.io.File filetFileOutputDelimited_3 = new java.io.File(fileName_tFileOutputDelimited_3);
				globalMap.put("tFileOutputDelimited_3_FILE_NAME", fileName_tFileOutputDelimited_3);
				if (filetFileOutputDelimited_3.exists()) {
					throw new RuntimeException("The particular file \"" + filetFileOutputDelimited_3.getAbsoluteFile()
							+ "\" already exist. If you want to overwrite the file, please uncheck the"
							+ " \"Throw an error if the file already exist\" option in Advanced settings.");
				}
				int nb_line_tFileOutputDelimited_3 = 0;
				int splitedFileNo_tFileOutputDelimited_3 = 0;
				int currentRow_tFileOutputDelimited_3 = 0;

				final String OUT_DELIM_tFileOutputDelimited_3 = /** Start field tFileOutputDelimited_3:FIELDSEPARATOR */
						"„,"/** End field tFileOutputDelimited_3:FIELDSEPARATOR */
				;

				final String OUT_DELIM_ROWSEP_tFileOutputDelimited_3 = /**
																		 * Start field
																		 * tFileOutputDelimited_3:ROWSEPARATOR
																		 */
						"\n"/** End field tFileOutputDelimited_3:ROWSEPARATOR */
				;

				// create directory only if not exists
				if (directory_tFileOutputDelimited_3 != null && directory_tFileOutputDelimited_3.trim().length() != 0) {
					java.io.File dir_tFileOutputDelimited_3 = new java.io.File(directory_tFileOutputDelimited_3);
					if (!dir_tFileOutputDelimited_3.exists()) {
						dir_tFileOutputDelimited_3.mkdirs();
					}
				}

				// routines.system.Row
				java.io.Writer outtFileOutputDelimited_3 = null;

				java.io.File fileToDelete_tFileOutputDelimited_3 = new java.io.File(fileName_tFileOutputDelimited_3);
				if (fileToDelete_tFileOutputDelimited_3.exists()) {
					fileToDelete_tFileOutputDelimited_3.delete();
				}
				outtFileOutputDelimited_3 = new java.io.BufferedWriter(new java.io.OutputStreamWriter(
						new java.io.FileOutputStream(fileName_tFileOutputDelimited_3, false), "ISO-8859-15"));
				if (filetFileOutputDelimited_3.length() == 0) {
					outtFileOutputDelimited_3.write("id");
					outtFileOutputDelimited_3.write(OUT_DELIM_tFileOutputDelimited_3);
					outtFileOutputDelimited_3.write("title");
					outtFileOutputDelimited_3.write(OUT_DELIM_tFileOutputDelimited_3);
					outtFileOutputDelimited_3.write("budget");
					outtFileOutputDelimited_3.write(OUT_DELIM_tFileOutputDelimited_3);
					outtFileOutputDelimited_3.write("revenue");
					outtFileOutputDelimited_3.write(OUT_DELIM_tFileOutputDelimited_3);
					outtFileOutputDelimited_3.write("date");
					outtFileOutputDelimited_3.write(OUT_DELIM_ROWSEP_tFileOutputDelimited_3);
					outtFileOutputDelimited_3.flush();
				}

				resourceMap.put("out_tFileOutputDelimited_3", outtFileOutputDelimited_3);
				resourceMap.put("nb_line_tFileOutputDelimited_3", nb_line_tFileOutputDelimited_3);

				/**
				 * [tFileOutputDelimited_3 begin ] stop
				 */

				/**
				 * [tSortRow_2_SortIn begin ] start
				 */

				ok_Hash.put("tSortRow_2_SortIn", false);
				start_Hash.put("tSortRow_2_SortIn", System.currentTimeMillis());

				currentVirtualComponent = "tSortRow_2";

				currentComponent = "tSortRow_2_SortIn";

				int tos_count_tSortRow_2_SortIn = 0;

				row11Struct[] array_tSortRow_2_SortIn = (row11Struct[]) globalMap.remove("tSortRow_2");

				int nb_line_tSortRow_2_SortIn = 0;

				row11Struct current_tSortRow_2_SortIn = null;

				for (int i_tSortRow_2_SortIn = 0; i_tSortRow_2_SortIn < array_tSortRow_2_SortIn.length; i_tSortRow_2_SortIn++) {
					current_tSortRow_2_SortIn = array_tSortRow_2_SortIn[i_tSortRow_2_SortIn];
					row12.id = current_tSortRow_2_SortIn.id;
					row12.title = current_tSortRow_2_SortIn.title;
					row12.budget = current_tSortRow_2_SortIn.budget;
					row12.revenue = current_tSortRow_2_SortIn.revenue;
					row12.date = current_tSortRow_2_SortIn.date;
					// increase number of line sorted
					nb_line_tSortRow_2_SortIn++;

					/**
					 * [tSortRow_2_SortIn begin ] stop
					 */

					/**
					 * [tSortRow_2_SortIn main ] start
					 */

					currentVirtualComponent = "tSortRow_2";

					currentComponent = "tSortRow_2_SortIn";

					tos_count_tSortRow_2_SortIn++;

					/**
					 * [tSortRow_2_SortIn main ] stop
					 */

					/**
					 * [tSortRow_2_SortIn process_data_begin ] start
					 */

					currentVirtualComponent = "tSortRow_2";

					currentComponent = "tSortRow_2_SortIn";

					/**
					 * [tSortRow_2_SortIn process_data_begin ] stop
					 */

					/**
					 * [tFileOutputDelimited_3 main ] start
					 */

					currentComponent = "tFileOutputDelimited_3";

					if (execStat) {
						runStat.updateStatOnConnection(iterateId, 1, 1

								, "row12"

						);
					}

					StringBuilder sb_tFileOutputDelimited_3 = new StringBuilder();
					if (row12.id != null) {
						sb_tFileOutputDelimited_3.append(row12.id);
					}
					sb_tFileOutputDelimited_3.append(OUT_DELIM_tFileOutputDelimited_3);
					if (row12.title != null) {
						sb_tFileOutputDelimited_3.append(row12.title);
					}
					sb_tFileOutputDelimited_3.append(OUT_DELIM_tFileOutputDelimited_3);
					if (row12.budget != null) {
						sb_tFileOutputDelimited_3.append(row12.budget);
					}
					sb_tFileOutputDelimited_3.append(OUT_DELIM_tFileOutputDelimited_3);
					if (row12.revenue != null) {
						sb_tFileOutputDelimited_3.append(row12.revenue);
					}
					sb_tFileOutputDelimited_3.append(OUT_DELIM_tFileOutputDelimited_3);
					if (row12.date != null) {
						sb_tFileOutputDelimited_3.append(FormatterUtils.format_Date(row12.date, "dd-MM-yyyy"));
					}
					sb_tFileOutputDelimited_3.append(OUT_DELIM_ROWSEP_tFileOutputDelimited_3);

					nb_line_tFileOutputDelimited_3++;
					resourceMap.put("nb_line_tFileOutputDelimited_3", nb_line_tFileOutputDelimited_3);

					outtFileOutputDelimited_3.write(sb_tFileOutputDelimited_3.toString());

					tos_count_tFileOutputDelimited_3++;

					/**
					 * [tFileOutputDelimited_3 main ] stop
					 */

					/**
					 * [tFileOutputDelimited_3 process_data_begin ] start
					 */

					currentComponent = "tFileOutputDelimited_3";

					/**
					 * [tFileOutputDelimited_3 process_data_begin ] stop
					 */

					/**
					 * [tFileOutputDelimited_3 process_data_end ] start
					 */

					currentComponent = "tFileOutputDelimited_3";

					/**
					 * [tFileOutputDelimited_3 process_data_end ] stop
					 */

					/**
					 * [tSortRow_2_SortIn process_data_end ] start
					 */

					currentVirtualComponent = "tSortRow_2";

					currentComponent = "tSortRow_2_SortIn";

					/**
					 * [tSortRow_2_SortIn process_data_end ] stop
					 */

					/**
					 * [tSortRow_2_SortIn end ] start
					 */

					currentVirtualComponent = "tSortRow_2";

					currentComponent = "tSortRow_2_SortIn";

				}

				globalMap.put("tSortRow_2_SortIn_NB_LINE", nb_line_tSortRow_2_SortIn);

				ok_Hash.put("tSortRow_2_SortIn", true);
				end_Hash.put("tSortRow_2_SortIn", System.currentTimeMillis());

				/**
				 * [tSortRow_2_SortIn end ] stop
				 */

				/**
				 * [tFileOutputDelimited_3 end ] start
				 */

				currentComponent = "tFileOutputDelimited_3";

				if (outtFileOutputDelimited_3 != null) {
					outtFileOutputDelimited_3.flush();
					outtFileOutputDelimited_3.close();
				}

				globalMap.put("tFileOutputDelimited_3_NB_LINE", nb_line_tFileOutputDelimited_3);
				globalMap.put("tFileOutputDelimited_3_FILE_NAME", fileName_tFileOutputDelimited_3);

				resourceMap.put("finish_tFileOutputDelimited_3", true);

				if (execStat) {
					runStat.updateStat(resourceMap, iterateId, 2, 0, "row12");
				}

				ok_Hash.put("tFileOutputDelimited_3", true);
				end_Hash.put("tFileOutputDelimited_3", System.currentTimeMillis());

				/**
				 * [tFileOutputDelimited_3 end ] stop
				 */

				/**
				 * [tLogRow_4 end ] start
				 */

				currentComponent = "tLogRow_4";

//////
//////
				globalMap.put("tLogRow_4_NB_LINE", nb_line_tLogRow_4);

///////////////////////    			

				if (execStat) {
					runStat.updateStat(resourceMap, iterateId, 2, 0, "RatingXml");
				}

				ok_Hash.put("tLogRow_4", true);
				end_Hash.put("tLogRow_4", System.currentTimeMillis());

				/**
				 * [tLogRow_4 end ] stop
				 */

				/**
				 * [tFileOutputXML_1 end ] start
				 */

				currentComponent = "tFileOutputXML_1";

				out_tFileOutputXML_1.write(footers_tFileOutputXML_1[0]);

				out_tFileOutputXML_1.newLine();
				out_tFileOutputXML_1.close();
				globalMap.put("tFileOutputXML_1_NB_LINE", nb_line_tFileOutputXML_1);

				if (execStat) {
					runStat.updateStat(resourceMap, iterateId, 2, 0, "row13");
				}

				ok_Hash.put("tFileOutputXML_1", true);
				end_Hash.put("tFileOutputXML_1", System.currentTimeMillis());

				/**
				 * [tFileOutputXML_1 end ] stop
				 */

				/**
				 * [tLogRow_7 end ] start
				 */

				currentComponent = "tLogRow_7";

//////

				java.io.PrintStream consoleOut_tLogRow_7 = null;
				if (globalMap.get("tLogRow_CONSOLE") != null) {
					consoleOut_tLogRow_7 = (java.io.PrintStream) globalMap.get("tLogRow_CONSOLE");
				} else {
					consoleOut_tLogRow_7 = new java.io.PrintStream(new java.io.BufferedOutputStream(System.out));
					globalMap.put("tLogRow_CONSOLE", consoleOut_tLogRow_7);
				}

				consoleOut_tLogRow_7.println(util_tLogRow_7.format().toString());
				consoleOut_tLogRow_7.flush();
//////
				globalMap.put("tLogRow_7_NB_LINE", nb_line_tLogRow_7);

///////////////////////    			

				if (execStat) {
					runStat.updateStat(resourceMap, iterateId, 2, 0, "Joint_rev_budget_date2");
				}

				ok_Hash.put("tLogRow_7", true);
				end_Hash.put("tLogRow_7", System.currentTimeMillis());

				/**
				 * [tLogRow_7 end ] stop
				 */

				/**
				 * [tSortRow_3_SortOut end ] start
				 */

				currentVirtualComponent = "tSortRow_3";

				currentComponent = "tSortRow_3_SortOut";

				row15Struct[] array_tSortRow_3_SortOut = list_tSortRow_3_SortOut.toArray(new Comparablerow15Struct[0]);

				java.util.Arrays.sort(array_tSortRow_3_SortOut);

				globalMap.put("tSortRow_3", array_tSortRow_3_SortOut);

				if (execStat) {
					runStat.updateStat(resourceMap, iterateId, 2, 0, "row15");
				}

				ok_Hash.put("tSortRow_3_SortOut", true);
				end_Hash.put("tSortRow_3_SortOut", System.currentTimeMillis());

				/**
				 * [tSortRow_3_SortOut end ] stop
				 */

				/**
				 * [tFileOutputExcel_1 begin ] start
				 */

				ok_Hash.put("tFileOutputExcel_1", false);
				start_Hash.put("tFileOutputExcel_1", System.currentTimeMillis());

				currentComponent = "tFileOutputExcel_1";

				if (execStat) {
					runStat.updateStatOnConnection(resourceMap, iterateId, 0, 0, "row16");
				}

				int tos_count_tFileOutputExcel_1 = 0;

				int columnIndex_tFileOutputExcel_1 = 0;
				boolean headerIsInserted_tFileOutputExcel_1 = false;

				int nb_line_tFileOutputExcel_1 = 0;

				String fileName_tFileOutputExcel_1 = "C:/Users/ananf/OneDrive/Documents/Aivancity/DATA pipeline/Client2New.csv";
				java.io.File file_tFileOutputExcel_1 = new java.io.File(fileName_tFileOutputExcel_1);
				boolean isFileGenerated_tFileOutputExcel_1 = true;
//create directory only if not exists
				java.io.File parentFile_tFileOutputExcel_1 = file_tFileOutputExcel_1.getParentFile();
				if (parentFile_tFileOutputExcel_1 != null && !parentFile_tFileOutputExcel_1.exists()) {

					parentFile_tFileOutputExcel_1.mkdirs();

				}

				jxl.write.WritableWorkbook writeableWorkbook_tFileOutputExcel_1 = null;
				jxl.write.WritableSheet writableSheet_tFileOutputExcel_1 = null;

				jxl.WorkbookSettings workbookSettings_tFileOutputExcel_1 = new jxl.WorkbookSettings();
				workbookSettings_tFileOutputExcel_1.setEncoding("ISO-8859-15");
				writeableWorkbook_tFileOutputExcel_1 = new jxl.write.biff.WritableWorkbookImpl(
						new java.io.BufferedOutputStream(new java.io.FileOutputStream(fileName_tFileOutputExcel_1)),
						true, workbookSettings_tFileOutputExcel_1);

				writableSheet_tFileOutputExcel_1 = writeableWorkbook_tFileOutputExcel_1.getSheet("Sheet1");
				if (writableSheet_tFileOutputExcel_1 == null) {
					writableSheet_tFileOutputExcel_1 = writeableWorkbook_tFileOutputExcel_1.createSheet("Sheet1",
							writeableWorkbook_tFileOutputExcel_1.getNumberOfSheets());
				}

				// modif start
				int startRowNum_tFileOutputExcel_1 = writableSheet_tFileOutputExcel_1.getRows();
				// modif end

				int[] fitWidth_tFileOutputExcel_1 = new int[5];
				for (int i_tFileOutputExcel_1 = 0; i_tFileOutputExcel_1 < 5; i_tFileOutputExcel_1++) {
					int fitCellViewSize_tFileOutputExcel_1 = writableSheet_tFileOutputExcel_1
							.getColumnView(i_tFileOutputExcel_1).getSize();
					fitWidth_tFileOutputExcel_1[i_tFileOutputExcel_1] = fitCellViewSize_tFileOutputExcel_1 / 256;
					if (fitCellViewSize_tFileOutputExcel_1 % 256 != 0) {
						fitWidth_tFileOutputExcel_1[i_tFileOutputExcel_1] += 1;
					}
				}

				final jxl.write.WritableCellFormat cell_format_date_tFileOutputExcel_1 = new jxl.write.WritableCellFormat(
						new jxl.write.DateFormat("dd-MM-yyyy"));

				if (startRowNum_tFileOutputExcel_1 == 0) {
					// modif end
					// modif start
					writableSheet_tFileOutputExcel_1.addCell(new jxl.write.Label(0, nb_line_tFileOutputExcel_1, "id"));
					// modif end
					fitWidth_tFileOutputExcel_1[0] = fitWidth_tFileOutputExcel_1[0] > 2 ? fitWidth_tFileOutputExcel_1[0]
							: 2;
					// modif start
					writableSheet_tFileOutputExcel_1
							.addCell(new jxl.write.Label(1, nb_line_tFileOutputExcel_1, "title"));
					// modif end
					fitWidth_tFileOutputExcel_1[1] = fitWidth_tFileOutputExcel_1[1] > 5 ? fitWidth_tFileOutputExcel_1[1]
							: 5;
					// modif start
					writableSheet_tFileOutputExcel_1
							.addCell(new jxl.write.Label(2, nb_line_tFileOutputExcel_1, "date"));
					// modif end
					fitWidth_tFileOutputExcel_1[2] = fitWidth_tFileOutputExcel_1[2] > 4 ? fitWidth_tFileOutputExcel_1[2]
							: 4;
					// modif start
					writableSheet_tFileOutputExcel_1
							.addCell(new jxl.write.Label(3, nb_line_tFileOutputExcel_1, "budget"));
					// modif end
					fitWidth_tFileOutputExcel_1[3] = fitWidth_tFileOutputExcel_1[3] > 6 ? fitWidth_tFileOutputExcel_1[3]
							: 6;
					// modif start
					writableSheet_tFileOutputExcel_1
							.addCell(new jxl.write.Label(4, nb_line_tFileOutputExcel_1, "revenue"));
					// modif end
					fitWidth_tFileOutputExcel_1[4] = fitWidth_tFileOutputExcel_1[4] > 7 ? fitWidth_tFileOutputExcel_1[4]
							: 7;
					nb_line_tFileOutputExcel_1++;
					headerIsInserted_tFileOutputExcel_1 = true;
				}

				/**
				 * [tFileOutputExcel_1 begin ] stop
				 */

				/**
				 * [tSortRow_3_SortIn begin ] start
				 */

				ok_Hash.put("tSortRow_3_SortIn", false);
				start_Hash.put("tSortRow_3_SortIn", System.currentTimeMillis());

				currentVirtualComponent = "tSortRow_3";

				currentComponent = "tSortRow_3_SortIn";

				int tos_count_tSortRow_3_SortIn = 0;

				row15Struct[] array_tSortRow_3_SortIn = (row15Struct[]) globalMap.remove("tSortRow_3");

				int nb_line_tSortRow_3_SortIn = 0;

				row15Struct current_tSortRow_3_SortIn = null;

				for (int i_tSortRow_3_SortIn = 0; i_tSortRow_3_SortIn < array_tSortRow_3_SortIn.length; i_tSortRow_3_SortIn++) {
					current_tSortRow_3_SortIn = array_tSortRow_3_SortIn[i_tSortRow_3_SortIn];
					row16.id = current_tSortRow_3_SortIn.id;
					row16.title = current_tSortRow_3_SortIn.title;
					row16.date = current_tSortRow_3_SortIn.date;
					row16.budget = current_tSortRow_3_SortIn.budget;
					row16.revenue = current_tSortRow_3_SortIn.revenue;
					// increase number of line sorted
					nb_line_tSortRow_3_SortIn++;

					/**
					 * [tSortRow_3_SortIn begin ] stop
					 */

					/**
					 * [tSortRow_3_SortIn main ] start
					 */

					currentVirtualComponent = "tSortRow_3";

					currentComponent = "tSortRow_3_SortIn";

					tos_count_tSortRow_3_SortIn++;

					/**
					 * [tSortRow_3_SortIn main ] stop
					 */

					/**
					 * [tSortRow_3_SortIn process_data_begin ] start
					 */

					currentVirtualComponent = "tSortRow_3";

					currentComponent = "tSortRow_3_SortIn";

					/**
					 * [tSortRow_3_SortIn process_data_begin ] stop
					 */

					/**
					 * [tFileOutputExcel_1 main ] start
					 */

					currentComponent = "tFileOutputExcel_1";

					if (execStat) {
						runStat.updateStatOnConnection(iterateId, 1, 1

								, "row16"

						);
					}

					if (row16.id != null) {

//modif start

						columnIndex_tFileOutputExcel_1 = 0;

						jxl.write.WritableCell cell_0_tFileOutputExcel_1 = new jxl.write.Number(
								columnIndex_tFileOutputExcel_1,
								startRowNum_tFileOutputExcel_1 + nb_line_tFileOutputExcel_1,

//modif end
								row16.id);
//modif start					
						// If we keep the cell format from the existing cell in sheet

//modif ends							
						writableSheet_tFileOutputExcel_1.addCell(cell_0_tFileOutputExcel_1);
						int currentWith_0_tFileOutputExcel_1 = String
								.valueOf(((jxl.write.Number) cell_0_tFileOutputExcel_1).getValue()).trim().length();
						currentWith_0_tFileOutputExcel_1 = currentWith_0_tFileOutputExcel_1 > 10 ? 10
								: currentWith_0_tFileOutputExcel_1;
						fitWidth_tFileOutputExcel_1[0] = fitWidth_tFileOutputExcel_1[0] > currentWith_0_tFileOutputExcel_1
								? fitWidth_tFileOutputExcel_1[0]
								: currentWith_0_tFileOutputExcel_1 + 2;
					}

					if (row16.title != null) {

//modif start

						columnIndex_tFileOutputExcel_1 = 1;

						jxl.write.WritableCell cell_1_tFileOutputExcel_1 = new jxl.write.Label(
								columnIndex_tFileOutputExcel_1,
								startRowNum_tFileOutputExcel_1 + nb_line_tFileOutputExcel_1,

//modif end
								row16.title);
//modif start					
						// If we keep the cell format from the existing cell in sheet

//modif ends							
						writableSheet_tFileOutputExcel_1.addCell(cell_1_tFileOutputExcel_1);
						int currentWith_1_tFileOutputExcel_1 = cell_1_tFileOutputExcel_1.getContents().trim().length();
						fitWidth_tFileOutputExcel_1[1] = fitWidth_tFileOutputExcel_1[1] > currentWith_1_tFileOutputExcel_1
								? fitWidth_tFileOutputExcel_1[1]
								: currentWith_1_tFileOutputExcel_1 + 2;
					}

					if (row16.date != null) {

//modif start

						columnIndex_tFileOutputExcel_1 = 2;

						jxl.write.WritableCell cell_2_tFileOutputExcel_1 = new jxl.write.DateTime(
								columnIndex_tFileOutputExcel_1,
								startRowNum_tFileOutputExcel_1 + nb_line_tFileOutputExcel_1,

//modif end
								row16.date, cell_format_date_tFileOutputExcel_1);
//modif start					
						// If we keep the cell format from the existing cell in sheet

//modif ends							
						writableSheet_tFileOutputExcel_1.addCell(cell_2_tFileOutputExcel_1);
						int currentWith_2_tFileOutputExcel_1 = cell_2_tFileOutputExcel_1.getContents().trim().length();
						currentWith_2_tFileOutputExcel_1 = 12;
						fitWidth_tFileOutputExcel_1[2] = fitWidth_tFileOutputExcel_1[2] > currentWith_2_tFileOutputExcel_1
								? fitWidth_tFileOutputExcel_1[2]
								: currentWith_2_tFileOutputExcel_1 + 2;
					}

					if (row16.budget != null) {

//modif start

						columnIndex_tFileOutputExcel_1 = 3;

						jxl.write.WritableCell cell_3_tFileOutputExcel_1 = new jxl.write.Number(
								columnIndex_tFileOutputExcel_1,
								startRowNum_tFileOutputExcel_1 + nb_line_tFileOutputExcel_1,

//modif end
								row16.budget);
//modif start					
						// If we keep the cell format from the existing cell in sheet

//modif ends							
						writableSheet_tFileOutputExcel_1.addCell(cell_3_tFileOutputExcel_1);
						int currentWith_3_tFileOutputExcel_1 = String
								.valueOf(((jxl.write.Number) cell_3_tFileOutputExcel_1).getValue()).trim().length();
						currentWith_3_tFileOutputExcel_1 = currentWith_3_tFileOutputExcel_1 > 10 ? 10
								: currentWith_3_tFileOutputExcel_1;
						fitWidth_tFileOutputExcel_1[3] = fitWidth_tFileOutputExcel_1[3] > currentWith_3_tFileOutputExcel_1
								? fitWidth_tFileOutputExcel_1[3]
								: currentWith_3_tFileOutputExcel_1 + 2;
					}

					if (row16.revenue != null) {

//modif start

						columnIndex_tFileOutputExcel_1 = 4;

						jxl.write.WritableCell cell_4_tFileOutputExcel_1 = new jxl.write.Number(
								columnIndex_tFileOutputExcel_1,
								startRowNum_tFileOutputExcel_1 + nb_line_tFileOutputExcel_1,

//modif end
								row16.revenue);
//modif start					
						// If we keep the cell format from the existing cell in sheet

//modif ends							
						writableSheet_tFileOutputExcel_1.addCell(cell_4_tFileOutputExcel_1);
						int currentWith_4_tFileOutputExcel_1 = String
								.valueOf(((jxl.write.Number) cell_4_tFileOutputExcel_1).getValue()).trim().length();
						currentWith_4_tFileOutputExcel_1 = currentWith_4_tFileOutputExcel_1 > 10 ? 10
								: currentWith_4_tFileOutputExcel_1;
						fitWidth_tFileOutputExcel_1[4] = fitWidth_tFileOutputExcel_1[4] > currentWith_4_tFileOutputExcel_1
								? fitWidth_tFileOutputExcel_1[4]
								: currentWith_4_tFileOutputExcel_1 + 2;
					}

					nb_line_tFileOutputExcel_1++;

					tos_count_tFileOutputExcel_1++;

					/**
					 * [tFileOutputExcel_1 main ] stop
					 */

					/**
					 * [tFileOutputExcel_1 process_data_begin ] start
					 */

					currentComponent = "tFileOutputExcel_1";

					/**
					 * [tFileOutputExcel_1 process_data_begin ] stop
					 */

					/**
					 * [tFileOutputExcel_1 process_data_end ] start
					 */

					currentComponent = "tFileOutputExcel_1";

					/**
					 * [tFileOutputExcel_1 process_data_end ] stop
					 */

					/**
					 * [tSortRow_3_SortIn process_data_end ] start
					 */

					currentVirtualComponent = "tSortRow_3";

					currentComponent = "tSortRow_3_SortIn";

					/**
					 * [tSortRow_3_SortIn process_data_end ] stop
					 */

					/**
					 * [tSortRow_3_SortIn end ] start
					 */

					currentVirtualComponent = "tSortRow_3";

					currentComponent = "tSortRow_3_SortIn";

				}

				globalMap.put("tSortRow_3_SortIn_NB_LINE", nb_line_tSortRow_3_SortIn);

				ok_Hash.put("tSortRow_3_SortIn", true);
				end_Hash.put("tSortRow_3_SortIn", System.currentTimeMillis());

				/**
				 * [tSortRow_3_SortIn end ] stop
				 */

				/**
				 * [tFileOutputExcel_1 end ] start
				 */

				currentComponent = "tFileOutputExcel_1";

				writeableWorkbook_tFileOutputExcel_1.write();
				writeableWorkbook_tFileOutputExcel_1.close();
				if (headerIsInserted_tFileOutputExcel_1 && nb_line_tFileOutputExcel_1 > 0) {
					nb_line_tFileOutputExcel_1 = nb_line_tFileOutputExcel_1 - 1;
				}
				globalMap.put("tFileOutputExcel_1_NB_LINE", nb_line_tFileOutputExcel_1);

				if (execStat) {
					runStat.updateStat(resourceMap, iterateId, 2, 0, "row16");
				}

				ok_Hash.put("tFileOutputExcel_1", true);
				end_Hash.put("tFileOutputExcel_1", System.currentTimeMillis());

				/**
				 * [tFileOutputExcel_1 end ] stop
				 */

				/**
				 * [tLogRow_8 end ] start
				 */

				currentComponent = "tLogRow_8";

//////
//////
				globalMap.put("tLogRow_8_NB_LINE", nb_line_tLogRow_8);

///////////////////////    			

				if (execStat) {
					runStat.updateStat(resourceMap, iterateId, 2, 0, "JointSheet2");
				}

				ok_Hash.put("tLogRow_8", true);
				end_Hash.put("tLogRow_8", System.currentTimeMillis());

				/**
				 * [tLogRow_8 end ] stop
				 */

				/**
				 * [tAggregateRow_1_AGGOUT end ] start
				 */

				currentVirtualComponent = "tAggregateRow_1";

				currentComponent = "tAggregateRow_1_AGGOUT";

				if (execStat) {
					runStat.updateStat(resourceMap, iterateId, 2, 0, "row17");
				}

				ok_Hash.put("tAggregateRow_1_AGGOUT", true);
				end_Hash.put("tAggregateRow_1_AGGOUT", System.currentTimeMillis());

				/**
				 * [tAggregateRow_1_AGGOUT end ] stop
				 */

				/**
				 * [tSortRow_4_SortOut begin ] start
				 */

				ok_Hash.put("tSortRow_4_SortOut", false);
				start_Hash.put("tSortRow_4_SortOut", System.currentTimeMillis());

				currentVirtualComponent = "tSortRow_4";

				currentComponent = "tSortRow_4_SortOut";

				if (execStat) {
					runStat.updateStatOnConnection(resourceMap, iterateId, 0, 0, "row18");
				}

				int tos_count_tSortRow_4_SortOut = 0;

				class Comparablerow18Struct extends row18Struct implements Comparable<Comparablerow18Struct> {

					public int compareTo(Comparablerow18Struct other) {

						if (this.date == null && other.date != null) {
							return -1;

						} else if (this.date != null && other.date == null) {
							return 1;

						} else if (this.date != null && other.date != null) {
							if (!this.date.equals(other.date)) {
								return this.date.compareTo(other.date);
							}
						}
						return 0;
					}
				}

				java.util.List<Comparablerow18Struct> list_tSortRow_4_SortOut = new java.util.ArrayList<Comparablerow18Struct>();

				/**
				 * [tSortRow_4_SortOut begin ] stop
				 */

				/**
				 * [tAggregateRow_1_AGGIN begin ] start
				 */

				ok_Hash.put("tAggregateRow_1_AGGIN", false);
				start_Hash.put("tAggregateRow_1_AGGIN", System.currentTimeMillis());

				currentVirtualComponent = "tAggregateRow_1";

				currentComponent = "tAggregateRow_1_AGGIN";

				int tos_count_tAggregateRow_1_AGGIN = 0;

				java.util.Collection<AggOperationStruct_tAggregateRow_1> values_tAggregateRow_1 = hash_tAggregateRow_1
						.values();

				globalMap.put("tAggregateRow_1_NB_LINE", values_tAggregateRow_1.size());

				for (AggOperationStruct_tAggregateRow_1 aggregated_row_tAggregateRow_1 : values_tAggregateRow_1) { // G_AggR_600

					/**
					 * [tAggregateRow_1_AGGIN begin ] stop
					 */

					/**
					 * [tAggregateRow_1_AGGIN main ] start
					 */

					currentVirtualComponent = "tAggregateRow_1";

					currentComponent = "tAggregateRow_1_AGGIN";

					row18.id = (int) aggregated_row_tAggregateRow_1.count;
					row18.id = (int) aggregated_row_tAggregateRow_1.id_clmCount;

					row18.date = aggregated_row_tAggregateRow_1.date;
					row18.budget = aggregated_row_tAggregateRow_1.budget_sum;
					row18.revenue = aggregated_row_tAggregateRow_1.revenue_sum;

					tos_count_tAggregateRow_1_AGGIN++;

					/**
					 * [tAggregateRow_1_AGGIN main ] stop
					 */

					/**
					 * [tAggregateRow_1_AGGIN process_data_begin ] start
					 */

					currentVirtualComponent = "tAggregateRow_1";

					currentComponent = "tAggregateRow_1_AGGIN";

					/**
					 * [tAggregateRow_1_AGGIN process_data_begin ] stop
					 */

					/**
					 * [tSortRow_4_SortOut main ] start
					 */

					currentVirtualComponent = "tSortRow_4";

					currentComponent = "tSortRow_4_SortOut";

					if (execStat) {
						runStat.updateStatOnConnection(iterateId, 1, 1

								, "row18"

						);
					}

					Comparablerow18Struct arrayRowtSortRow_4_SortOut = new Comparablerow18Struct();

					arrayRowtSortRow_4_SortOut.id = row18.id;
					arrayRowtSortRow_4_SortOut.date = row18.date;
					arrayRowtSortRow_4_SortOut.budget = row18.budget;
					arrayRowtSortRow_4_SortOut.revenue = row18.revenue;
					list_tSortRow_4_SortOut.add(arrayRowtSortRow_4_SortOut);

					tos_count_tSortRow_4_SortOut++;

					/**
					 * [tSortRow_4_SortOut main ] stop
					 */

					/**
					 * [tSortRow_4_SortOut process_data_begin ] start
					 */

					currentVirtualComponent = "tSortRow_4";

					currentComponent = "tSortRow_4_SortOut";

					/**
					 * [tSortRow_4_SortOut process_data_begin ] stop
					 */

					/**
					 * [tSortRow_4_SortOut process_data_end ] start
					 */

					currentVirtualComponent = "tSortRow_4";

					currentComponent = "tSortRow_4_SortOut";

					/**
					 * [tSortRow_4_SortOut process_data_end ] stop
					 */

					/**
					 * [tAggregateRow_1_AGGIN process_data_end ] start
					 */

					currentVirtualComponent = "tAggregateRow_1";

					currentComponent = "tAggregateRow_1_AGGIN";

					/**
					 * [tAggregateRow_1_AGGIN process_data_end ] stop
					 */

					/**
					 * [tAggregateRow_1_AGGIN end ] start
					 */

					currentVirtualComponent = "tAggregateRow_1";

					currentComponent = "tAggregateRow_1_AGGIN";

				} // G_AggR_600

				ok_Hash.put("tAggregateRow_1_AGGIN", true);
				end_Hash.put("tAggregateRow_1_AGGIN", System.currentTimeMillis());

				/**
				 * [tAggregateRow_1_AGGIN end ] stop
				 */

				/**
				 * [tSortRow_4_SortOut end ] start
				 */

				currentVirtualComponent = "tSortRow_4";

				currentComponent = "tSortRow_4_SortOut";

				row18Struct[] array_tSortRow_4_SortOut = list_tSortRow_4_SortOut.toArray(new Comparablerow18Struct[0]);

				java.util.Arrays.sort(array_tSortRow_4_SortOut);

				globalMap.put("tSortRow_4", array_tSortRow_4_SortOut);

				if (execStat) {
					runStat.updateStat(resourceMap, iterateId, 2, 0, "row18");
				}

				ok_Hash.put("tSortRow_4_SortOut", true);
				end_Hash.put("tSortRow_4_SortOut", System.currentTimeMillis());

				/**
				 * [tSortRow_4_SortOut end ] stop
				 */

				/**
				 * [tFileOutputExcel_2 begin ] start
				 */

				ok_Hash.put("tFileOutputExcel_2", false);
				start_Hash.put("tFileOutputExcel_2", System.currentTimeMillis());

				currentComponent = "tFileOutputExcel_2";

				if (execStat) {
					runStat.updateStatOnConnection(resourceMap, iterateId, 0, 0, "row19");
				}

				int tos_count_tFileOutputExcel_2 = 0;

				int columnIndex_tFileOutputExcel_2 = 0;
				boolean headerIsInserted_tFileOutputExcel_2 = false;

				int nb_line_tFileOutputExcel_2 = 0;

				String fileName_tFileOutputExcel_2 = "C:/Users/ananf/OneDrive/Documents/Aivancity/DATA pipeline/Client2New.csv";
				java.io.File file_tFileOutputExcel_2 = new java.io.File(fileName_tFileOutputExcel_2);
				boolean isFileGenerated_tFileOutputExcel_2 = true;
				if (file_tFileOutputExcel_2.exists()) {
					isFileGenerated_tFileOutputExcel_2 = false;
				}
//create directory only if not exists
				java.io.File parentFile_tFileOutputExcel_2 = file_tFileOutputExcel_2.getParentFile();
				if (parentFile_tFileOutputExcel_2 != null && !parentFile_tFileOutputExcel_2.exists()) {

					parentFile_tFileOutputExcel_2.mkdirs();

				}

				jxl.write.WritableWorkbook writeableWorkbook_tFileOutputExcel_2 = null;
				jxl.write.WritableSheet writableSheet_tFileOutputExcel_2 = null;

				jxl.WorkbookSettings workbookSettings_tFileOutputExcel_2 = new jxl.WorkbookSettings();
				workbookSettings_tFileOutputExcel_2.setEncoding("ISO-8859-15");
				if (file_tFileOutputExcel_2.exists()) {
					jxl.Workbook workbook_tFileOutputExcel_2 = jxl.Workbook.getWorkbook(file_tFileOutputExcel_2,
							workbookSettings_tFileOutputExcel_2);
					workbookSettings_tFileOutputExcel_2.setWriteAccess(null);
					writeableWorkbook_tFileOutputExcel_2 = new jxl.write.biff.WritableWorkbookImpl(
							new java.io.BufferedOutputStream(
									new java.io.FileOutputStream(file_tFileOutputExcel_2, false)),
							workbook_tFileOutputExcel_2, true, workbookSettings_tFileOutputExcel_2);
				} else {
					writeableWorkbook_tFileOutputExcel_2 = new jxl.write.biff.WritableWorkbookImpl(
							new java.io.BufferedOutputStream(new java.io.FileOutputStream(fileName_tFileOutputExcel_2)),
							true, workbookSettings_tFileOutputExcel_2);
				}

				writableSheet_tFileOutputExcel_2 = writeableWorkbook_tFileOutputExcel_2.getSheet("Sheet2");
				if (writableSheet_tFileOutputExcel_2 == null) {
					writableSheet_tFileOutputExcel_2 = writeableWorkbook_tFileOutputExcel_2.createSheet("Sheet2",
							writeableWorkbook_tFileOutputExcel_2.getNumberOfSheets());
				}

				else {

					String[] sheetNames_tFileOutputExcel_2 = writeableWorkbook_tFileOutputExcel_2.getSheetNames();
					for (int i = 0; i < sheetNames_tFileOutputExcel_2.length; i++) {
						if (sheetNames_tFileOutputExcel_2[i].equals("Sheet2")) {
							writeableWorkbook_tFileOutputExcel_2.removeSheet(i);
							break;
						}
					}

					writableSheet_tFileOutputExcel_2 = writeableWorkbook_tFileOutputExcel_2.createSheet("Sheet2",
							writeableWorkbook_tFileOutputExcel_2.getNumberOfSheets());
				}

				// modif start
				int startRowNum_tFileOutputExcel_2 = writableSheet_tFileOutputExcel_2.getRows();
				// modif end

				int[] fitWidth_tFileOutputExcel_2 = new int[4];
				for (int i_tFileOutputExcel_2 = 0; i_tFileOutputExcel_2 < 4; i_tFileOutputExcel_2++) {
					int fitCellViewSize_tFileOutputExcel_2 = writableSheet_tFileOutputExcel_2
							.getColumnView(i_tFileOutputExcel_2).getSize();
					fitWidth_tFileOutputExcel_2[i_tFileOutputExcel_2] = fitCellViewSize_tFileOutputExcel_2 / 256;
					if (fitCellViewSize_tFileOutputExcel_2 % 256 != 0) {
						fitWidth_tFileOutputExcel_2[i_tFileOutputExcel_2] += 1;
					}
				}

				final jxl.write.WritableCellFormat cell_format_date_tFileOutputExcel_2 = new jxl.write.WritableCellFormat(
						new jxl.write.DateFormat("dd-MM-yyyy"));

				if (startRowNum_tFileOutputExcel_2 == 0) {
					// modif end
					// modif start
					writableSheet_tFileOutputExcel_2.addCell(new jxl.write.Label(0, nb_line_tFileOutputExcel_2, "id"));
					// modif end
					fitWidth_tFileOutputExcel_2[0] = fitWidth_tFileOutputExcel_2[0] > 2 ? fitWidth_tFileOutputExcel_2[0]
							: 2;
					// modif start
					writableSheet_tFileOutputExcel_2
							.addCell(new jxl.write.Label(1, nb_line_tFileOutputExcel_2, "date"));
					// modif end
					fitWidth_tFileOutputExcel_2[1] = fitWidth_tFileOutputExcel_2[1] > 4 ? fitWidth_tFileOutputExcel_2[1]
							: 4;
					// modif start
					writableSheet_tFileOutputExcel_2
							.addCell(new jxl.write.Label(2, nb_line_tFileOutputExcel_2, "budget"));
					// modif end
					fitWidth_tFileOutputExcel_2[2] = fitWidth_tFileOutputExcel_2[2] > 6 ? fitWidth_tFileOutputExcel_2[2]
							: 6;
					// modif start
					writableSheet_tFileOutputExcel_2
							.addCell(new jxl.write.Label(3, nb_line_tFileOutputExcel_2, "revenue"));
					// modif end
					fitWidth_tFileOutputExcel_2[3] = fitWidth_tFileOutputExcel_2[3] > 7 ? fitWidth_tFileOutputExcel_2[3]
							: 7;
					nb_line_tFileOutputExcel_2++;
					headerIsInserted_tFileOutputExcel_2 = true;
				}

				/**
				 * [tFileOutputExcel_2 begin ] stop
				 */

				/**
				 * [tSortRow_4_SortIn begin ] start
				 */

				ok_Hash.put("tSortRow_4_SortIn", false);
				start_Hash.put("tSortRow_4_SortIn", System.currentTimeMillis());

				currentVirtualComponent = "tSortRow_4";

				currentComponent = "tSortRow_4_SortIn";

				int tos_count_tSortRow_4_SortIn = 0;

				row18Struct[] array_tSortRow_4_SortIn = (row18Struct[]) globalMap.remove("tSortRow_4");

				int nb_line_tSortRow_4_SortIn = 0;

				row18Struct current_tSortRow_4_SortIn = null;

				for (int i_tSortRow_4_SortIn = 0; i_tSortRow_4_SortIn < array_tSortRow_4_SortIn.length; i_tSortRow_4_SortIn++) {
					current_tSortRow_4_SortIn = array_tSortRow_4_SortIn[i_tSortRow_4_SortIn];
					row19.id = current_tSortRow_4_SortIn.id;
					row19.date = current_tSortRow_4_SortIn.date;
					row19.budget = current_tSortRow_4_SortIn.budget;
					row19.revenue = current_tSortRow_4_SortIn.revenue;
					// increase number of line sorted
					nb_line_tSortRow_4_SortIn++;

					/**
					 * [tSortRow_4_SortIn begin ] stop
					 */

					/**
					 * [tSortRow_4_SortIn main ] start
					 */

					currentVirtualComponent = "tSortRow_4";

					currentComponent = "tSortRow_4_SortIn";

					tos_count_tSortRow_4_SortIn++;

					/**
					 * [tSortRow_4_SortIn main ] stop
					 */

					/**
					 * [tSortRow_4_SortIn process_data_begin ] start
					 */

					currentVirtualComponent = "tSortRow_4";

					currentComponent = "tSortRow_4_SortIn";

					/**
					 * [tSortRow_4_SortIn process_data_begin ] stop
					 */

					/**
					 * [tFileOutputExcel_2 main ] start
					 */

					currentComponent = "tFileOutputExcel_2";

					if (execStat) {
						runStat.updateStatOnConnection(iterateId, 1, 1

								, "row19"

						);
					}

					if (row19.id != null) {

//modif start

						columnIndex_tFileOutputExcel_2 = 0;

						jxl.write.WritableCell cell_0_tFileOutputExcel_2 = new jxl.write.Number(
								columnIndex_tFileOutputExcel_2,
								startRowNum_tFileOutputExcel_2 + nb_line_tFileOutputExcel_2,

//modif end
								row19.id);
//modif start					
						// If we keep the cell format from the existing cell in sheet

//modif ends							
						writableSheet_tFileOutputExcel_2.addCell(cell_0_tFileOutputExcel_2);
						int currentWith_0_tFileOutputExcel_2 = String
								.valueOf(((jxl.write.Number) cell_0_tFileOutputExcel_2).getValue()).trim().length();
						currentWith_0_tFileOutputExcel_2 = currentWith_0_tFileOutputExcel_2 > 10 ? 10
								: currentWith_0_tFileOutputExcel_2;
						fitWidth_tFileOutputExcel_2[0] = fitWidth_tFileOutputExcel_2[0] > currentWith_0_tFileOutputExcel_2
								? fitWidth_tFileOutputExcel_2[0]
								: currentWith_0_tFileOutputExcel_2 + 2;
					}

					if (row19.date != null) {

//modif start

						columnIndex_tFileOutputExcel_2 = 1;

						jxl.write.WritableCell cell_1_tFileOutputExcel_2 = new jxl.write.DateTime(
								columnIndex_tFileOutputExcel_2,
								startRowNum_tFileOutputExcel_2 + nb_line_tFileOutputExcel_2,

//modif end
								row19.date, cell_format_date_tFileOutputExcel_2);
//modif start					
						// If we keep the cell format from the existing cell in sheet

//modif ends							
						writableSheet_tFileOutputExcel_2.addCell(cell_1_tFileOutputExcel_2);
						int currentWith_1_tFileOutputExcel_2 = cell_1_tFileOutputExcel_2.getContents().trim().length();
						currentWith_1_tFileOutputExcel_2 = 12;
						fitWidth_tFileOutputExcel_2[1] = fitWidth_tFileOutputExcel_2[1] > currentWith_1_tFileOutputExcel_2
								? fitWidth_tFileOutputExcel_2[1]
								: currentWith_1_tFileOutputExcel_2 + 2;
					}

					if (row19.budget != null) {

//modif start

						columnIndex_tFileOutputExcel_2 = 2;

						jxl.write.WritableCell cell_2_tFileOutputExcel_2 = new jxl.write.Number(
								columnIndex_tFileOutputExcel_2,
								startRowNum_tFileOutputExcel_2 + nb_line_tFileOutputExcel_2,

//modif end
								row19.budget);
//modif start					
						// If we keep the cell format from the existing cell in sheet

//modif ends							
						writableSheet_tFileOutputExcel_2.addCell(cell_2_tFileOutputExcel_2);
						int currentWith_2_tFileOutputExcel_2 = String
								.valueOf(((jxl.write.Number) cell_2_tFileOutputExcel_2).getValue()).trim().length();
						currentWith_2_tFileOutputExcel_2 = currentWith_2_tFileOutputExcel_2 > 10 ? 10
								: currentWith_2_tFileOutputExcel_2;
						fitWidth_tFileOutputExcel_2[2] = fitWidth_tFileOutputExcel_2[2] > currentWith_2_tFileOutputExcel_2
								? fitWidth_tFileOutputExcel_2[2]
								: currentWith_2_tFileOutputExcel_2 + 2;
					}

					if (row19.revenue != null) {

//modif start

						columnIndex_tFileOutputExcel_2 = 3;

						jxl.write.WritableCell cell_3_tFileOutputExcel_2 = new jxl.write.Number(
								columnIndex_tFileOutputExcel_2,
								startRowNum_tFileOutputExcel_2 + nb_line_tFileOutputExcel_2,

//modif end
								row19.revenue);
//modif start					
						// If we keep the cell format from the existing cell in sheet

//modif ends							
						writableSheet_tFileOutputExcel_2.addCell(cell_3_tFileOutputExcel_2);
						int currentWith_3_tFileOutputExcel_2 = String
								.valueOf(((jxl.write.Number) cell_3_tFileOutputExcel_2).getValue()).trim().length();
						currentWith_3_tFileOutputExcel_2 = currentWith_3_tFileOutputExcel_2 > 10 ? 10
								: currentWith_3_tFileOutputExcel_2;
						fitWidth_tFileOutputExcel_2[3] = fitWidth_tFileOutputExcel_2[3] > currentWith_3_tFileOutputExcel_2
								? fitWidth_tFileOutputExcel_2[3]
								: currentWith_3_tFileOutputExcel_2 + 2;
					}

					nb_line_tFileOutputExcel_2++;

					tos_count_tFileOutputExcel_2++;

					/**
					 * [tFileOutputExcel_2 main ] stop
					 */

					/**
					 * [tFileOutputExcel_2 process_data_begin ] start
					 */

					currentComponent = "tFileOutputExcel_2";

					/**
					 * [tFileOutputExcel_2 process_data_begin ] stop
					 */

					/**
					 * [tFileOutputExcel_2 process_data_end ] start
					 */

					currentComponent = "tFileOutputExcel_2";

					/**
					 * [tFileOutputExcel_2 process_data_end ] stop
					 */

					/**
					 * [tSortRow_4_SortIn process_data_end ] start
					 */

					currentVirtualComponent = "tSortRow_4";

					currentComponent = "tSortRow_4_SortIn";

					/**
					 * [tSortRow_4_SortIn process_data_end ] stop
					 */

					/**
					 * [tSortRow_4_SortIn end ] start
					 */

					currentVirtualComponent = "tSortRow_4";

					currentComponent = "tSortRow_4_SortIn";

				}

				globalMap.put("tSortRow_4_SortIn_NB_LINE", nb_line_tSortRow_4_SortIn);

				ok_Hash.put("tSortRow_4_SortIn", true);
				end_Hash.put("tSortRow_4_SortIn", System.currentTimeMillis());

				/**
				 * [tSortRow_4_SortIn end ] stop
				 */

				/**
				 * [tFileOutputExcel_2 end ] start
				 */

				currentComponent = "tFileOutputExcel_2";

				writeableWorkbook_tFileOutputExcel_2.write();
				writeableWorkbook_tFileOutputExcel_2.close();
				if (headerIsInserted_tFileOutputExcel_2 && nb_line_tFileOutputExcel_2 > 0) {
					nb_line_tFileOutputExcel_2 = nb_line_tFileOutputExcel_2 - 1;
				}
				globalMap.put("tFileOutputExcel_2_NB_LINE", nb_line_tFileOutputExcel_2);

				if (execStat) {
					runStat.updateStat(resourceMap, iterateId, 2, 0, "row19");
				}

				ok_Hash.put("tFileOutputExcel_2", true);
				end_Hash.put("tFileOutputExcel_2", System.currentTimeMillis());

				/**
				 * [tFileOutputExcel_2 end ] stop
				 */

				/**
				 * [tLogRow_9 end ] start
				 */

				currentComponent = "tLogRow_9";

//////
//////
				globalMap.put("tLogRow_9_NB_LINE", nb_line_tLogRow_9);

///////////////////////    			

				if (execStat) {
					runStat.updateStat(resourceMap, iterateId, 2, 0, "JoinSheet3");
				}

				ok_Hash.put("tLogRow_9", true);
				end_Hash.put("tLogRow_9", System.currentTimeMillis());

				/**
				 * [tLogRow_9 end ] stop
				 */

				/**
				 * [tSortRow_5_SortOut end ] start
				 */

				currentVirtualComponent = "tSortRow_5";

				currentComponent = "tSortRow_5_SortOut";

				row20Struct[] array_tSortRow_5_SortOut = list_tSortRow_5_SortOut.toArray(new Comparablerow20Struct[0]);

				java.util.Arrays.sort(array_tSortRow_5_SortOut);

				globalMap.put("tSortRow_5", array_tSortRow_5_SortOut);

				if (execStat) {
					runStat.updateStat(resourceMap, iterateId, 2, 0, "row20");
				}

				ok_Hash.put("tSortRow_5_SortOut", true);
				end_Hash.put("tSortRow_5_SortOut", System.currentTimeMillis());

				/**
				 * [tSortRow_5_SortOut end ] stop
				 */

				/**
				 * [tFileOutputExcel_3 begin ] start
				 */

				ok_Hash.put("tFileOutputExcel_3", false);
				start_Hash.put("tFileOutputExcel_3", System.currentTimeMillis());

				currentComponent = "tFileOutputExcel_3";

				if (execStat) {
					runStat.updateStatOnConnection(resourceMap, iterateId, 0, 0, "row21");
				}

				int tos_count_tFileOutputExcel_3 = 0;

				int columnIndex_tFileOutputExcel_3 = 0;
				boolean headerIsInserted_tFileOutputExcel_3 = false;

				int nb_line_tFileOutputExcel_3 = 0;

				String fileName_tFileOutputExcel_3 = "C:/Users/ananf/OneDrive/Documents/Aivancity/DATA pipeline/Client2New.csv";
				java.io.File file_tFileOutputExcel_3 = new java.io.File(fileName_tFileOutputExcel_3);
				boolean isFileGenerated_tFileOutputExcel_3 = true;
				if (file_tFileOutputExcel_3.exists()) {
					isFileGenerated_tFileOutputExcel_3 = false;
				}
//create directory only if not exists
				java.io.File parentFile_tFileOutputExcel_3 = file_tFileOutputExcel_3.getParentFile();
				if (parentFile_tFileOutputExcel_3 != null && !parentFile_tFileOutputExcel_3.exists()) {

					parentFile_tFileOutputExcel_3.mkdirs();

				}

				jxl.write.WritableWorkbook writeableWorkbook_tFileOutputExcel_3 = null;
				jxl.write.WritableSheet writableSheet_tFileOutputExcel_3 = null;

				jxl.WorkbookSettings workbookSettings_tFileOutputExcel_3 = new jxl.WorkbookSettings();
				workbookSettings_tFileOutputExcel_3.setEncoding("ISO-8859-15");
				if (file_tFileOutputExcel_3.exists()) {
					jxl.Workbook workbook_tFileOutputExcel_3 = jxl.Workbook.getWorkbook(file_tFileOutputExcel_3,
							workbookSettings_tFileOutputExcel_3);
					workbookSettings_tFileOutputExcel_3.setWriteAccess(null);
					writeableWorkbook_tFileOutputExcel_3 = new jxl.write.biff.WritableWorkbookImpl(
							new java.io.BufferedOutputStream(
									new java.io.FileOutputStream(file_tFileOutputExcel_3, false)),
							workbook_tFileOutputExcel_3, true, workbookSettings_tFileOutputExcel_3);
				} else {
					writeableWorkbook_tFileOutputExcel_3 = new jxl.write.biff.WritableWorkbookImpl(
							new java.io.BufferedOutputStream(new java.io.FileOutputStream(fileName_tFileOutputExcel_3)),
							true, workbookSettings_tFileOutputExcel_3);
				}

				writableSheet_tFileOutputExcel_3 = writeableWorkbook_tFileOutputExcel_3.getSheet("Sheet3");
				if (writableSheet_tFileOutputExcel_3 == null) {
					writableSheet_tFileOutputExcel_3 = writeableWorkbook_tFileOutputExcel_3.createSheet("Sheet3",
							writeableWorkbook_tFileOutputExcel_3.getNumberOfSheets());
				}

				else {

					String[] sheetNames_tFileOutputExcel_3 = writeableWorkbook_tFileOutputExcel_3.getSheetNames();
					for (int i = 0; i < sheetNames_tFileOutputExcel_3.length; i++) {
						if (sheetNames_tFileOutputExcel_3[i].equals("Sheet3")) {
							writeableWorkbook_tFileOutputExcel_3.removeSheet(i);
							break;
						}
					}

					writableSheet_tFileOutputExcel_3 = writeableWorkbook_tFileOutputExcel_3.createSheet("Sheet3",
							writeableWorkbook_tFileOutputExcel_3.getNumberOfSheets());
				}

				// modif start
				int startRowNum_tFileOutputExcel_3 = writableSheet_tFileOutputExcel_3.getRows();
				// modif end

				int[] fitWidth_tFileOutputExcel_3 = new int[6];
				for (int i_tFileOutputExcel_3 = 0; i_tFileOutputExcel_3 < 6; i_tFileOutputExcel_3++) {
					int fitCellViewSize_tFileOutputExcel_3 = writableSheet_tFileOutputExcel_3
							.getColumnView(i_tFileOutputExcel_3).getSize();
					fitWidth_tFileOutputExcel_3[i_tFileOutputExcel_3] = fitCellViewSize_tFileOutputExcel_3 / 256;
					if (fitCellViewSize_tFileOutputExcel_3 % 256 != 0) {
						fitWidth_tFileOutputExcel_3[i_tFileOutputExcel_3] += 1;
					}
				}

				final jxl.write.WritableCellFormat cell_format_date_tFileOutputExcel_3 = new jxl.write.WritableCellFormat(
						new jxl.write.DateFormat("dd-MM-yyyy"));

				if (startRowNum_tFileOutputExcel_3 == 0) {
					// modif end
					// modif start
					writableSheet_tFileOutputExcel_3.addCell(new jxl.write.Label(0, nb_line_tFileOutputExcel_3, "id"));
					// modif end
					fitWidth_tFileOutputExcel_3[0] = fitWidth_tFileOutputExcel_3[0] > 2 ? fitWidth_tFileOutputExcel_3[0]
							: 2;
					// modif start
					writableSheet_tFileOutputExcel_3
							.addCell(new jxl.write.Label(1, nb_line_tFileOutputExcel_3, "title"));
					// modif end
					fitWidth_tFileOutputExcel_3[1] = fitWidth_tFileOutputExcel_3[1] > 5 ? fitWidth_tFileOutputExcel_3[1]
							: 5;
					// modif start
					writableSheet_tFileOutputExcel_3
							.addCell(new jxl.write.Label(2, nb_line_tFileOutputExcel_3, "date"));
					// modif end
					fitWidth_tFileOutputExcel_3[2] = fitWidth_tFileOutputExcel_3[2] > 4 ? fitWidth_tFileOutputExcel_3[2]
							: 4;
					// modif start
					writableSheet_tFileOutputExcel_3
							.addCell(new jxl.write.Label(3, nb_line_tFileOutputExcel_3, "budget"));
					// modif end
					fitWidth_tFileOutputExcel_3[3] = fitWidth_tFileOutputExcel_3[3] > 6 ? fitWidth_tFileOutputExcel_3[3]
							: 6;
					// modif start
					writableSheet_tFileOutputExcel_3
							.addCell(new jxl.write.Label(4, nb_line_tFileOutputExcel_3, "revenue"));
					// modif end
					fitWidth_tFileOutputExcel_3[4] = fitWidth_tFileOutputExcel_3[4] > 7 ? fitWidth_tFileOutputExcel_3[4]
							: 7;
					// modif start
					writableSheet_tFileOutputExcel_3
							.addCell(new jxl.write.Label(5, nb_line_tFileOutputExcel_3, "gain_perte"));
					// modif end
					fitWidth_tFileOutputExcel_3[5] = fitWidth_tFileOutputExcel_3[5] > 10
							? fitWidth_tFileOutputExcel_3[5]
							: 10;
					nb_line_tFileOutputExcel_3++;
					headerIsInserted_tFileOutputExcel_3 = true;
				}

				/**
				 * [tFileOutputExcel_3 begin ] stop
				 */

				/**
				 * [tSortRow_5_SortIn begin ] start
				 */

				ok_Hash.put("tSortRow_5_SortIn", false);
				start_Hash.put("tSortRow_5_SortIn", System.currentTimeMillis());

				currentVirtualComponent = "tSortRow_5";

				currentComponent = "tSortRow_5_SortIn";

				int tos_count_tSortRow_5_SortIn = 0;

				row20Struct[] array_tSortRow_5_SortIn = (row20Struct[]) globalMap.remove("tSortRow_5");

				int nb_line_tSortRow_5_SortIn = 0;

				row20Struct current_tSortRow_5_SortIn = null;

				for (int i_tSortRow_5_SortIn = 0; i_tSortRow_5_SortIn < array_tSortRow_5_SortIn.length; i_tSortRow_5_SortIn++) {
					current_tSortRow_5_SortIn = array_tSortRow_5_SortIn[i_tSortRow_5_SortIn];
					row21.id = current_tSortRow_5_SortIn.id;
					row21.title = current_tSortRow_5_SortIn.title;
					row21.date = current_tSortRow_5_SortIn.date;
					row21.budget = current_tSortRow_5_SortIn.budget;
					row21.revenue = current_tSortRow_5_SortIn.revenue;
					row21.gain_perte = current_tSortRow_5_SortIn.gain_perte;
					// increase number of line sorted
					nb_line_tSortRow_5_SortIn++;

					/**
					 * [tSortRow_5_SortIn begin ] stop
					 */

					/**
					 * [tSortRow_5_SortIn main ] start
					 */

					currentVirtualComponent = "tSortRow_5";

					currentComponent = "tSortRow_5_SortIn";

					tos_count_tSortRow_5_SortIn++;

					/**
					 * [tSortRow_5_SortIn main ] stop
					 */

					/**
					 * [tSortRow_5_SortIn process_data_begin ] start
					 */

					currentVirtualComponent = "tSortRow_5";

					currentComponent = "tSortRow_5_SortIn";

					/**
					 * [tSortRow_5_SortIn process_data_begin ] stop
					 */

					/**
					 * [tFileOutputExcel_3 main ] start
					 */

					currentComponent = "tFileOutputExcel_3";

					if (execStat) {
						runStat.updateStatOnConnection(iterateId, 1, 1

								, "row21"

						);
					}

					if (row21.id != null) {

//modif start

						columnIndex_tFileOutputExcel_3 = 0;

						jxl.write.WritableCell cell_0_tFileOutputExcel_3 = new jxl.write.Number(
								columnIndex_tFileOutputExcel_3,
								startRowNum_tFileOutputExcel_3 + nb_line_tFileOutputExcel_3,

//modif end
								row21.id);
//modif start					
						// If we keep the cell format from the existing cell in sheet

//modif ends							
						writableSheet_tFileOutputExcel_3.addCell(cell_0_tFileOutputExcel_3);
						int currentWith_0_tFileOutputExcel_3 = String
								.valueOf(((jxl.write.Number) cell_0_tFileOutputExcel_3).getValue()).trim().length();
						currentWith_0_tFileOutputExcel_3 = currentWith_0_tFileOutputExcel_3 > 10 ? 10
								: currentWith_0_tFileOutputExcel_3;
						fitWidth_tFileOutputExcel_3[0] = fitWidth_tFileOutputExcel_3[0] > currentWith_0_tFileOutputExcel_3
								? fitWidth_tFileOutputExcel_3[0]
								: currentWith_0_tFileOutputExcel_3 + 2;
					}

					if (row21.title != null) {

//modif start

						columnIndex_tFileOutputExcel_3 = 1;

						jxl.write.WritableCell cell_1_tFileOutputExcel_3 = new jxl.write.Label(
								columnIndex_tFileOutputExcel_3,
								startRowNum_tFileOutputExcel_3 + nb_line_tFileOutputExcel_3,

//modif end
								row21.title);
//modif start					
						// If we keep the cell format from the existing cell in sheet

//modif ends							
						writableSheet_tFileOutputExcel_3.addCell(cell_1_tFileOutputExcel_3);
						int currentWith_1_tFileOutputExcel_3 = cell_1_tFileOutputExcel_3.getContents().trim().length();
						fitWidth_tFileOutputExcel_3[1] = fitWidth_tFileOutputExcel_3[1] > currentWith_1_tFileOutputExcel_3
								? fitWidth_tFileOutputExcel_3[1]
								: currentWith_1_tFileOutputExcel_3 + 2;
					}

					if (row21.date != null) {

//modif start

						columnIndex_tFileOutputExcel_3 = 2;

						jxl.write.WritableCell cell_2_tFileOutputExcel_3 = new jxl.write.DateTime(
								columnIndex_tFileOutputExcel_3,
								startRowNum_tFileOutputExcel_3 + nb_line_tFileOutputExcel_3,

//modif end
								row21.date, cell_format_date_tFileOutputExcel_3);
//modif start					
						// If we keep the cell format from the existing cell in sheet

//modif ends							
						writableSheet_tFileOutputExcel_3.addCell(cell_2_tFileOutputExcel_3);
						int currentWith_2_tFileOutputExcel_3 = cell_2_tFileOutputExcel_3.getContents().trim().length();
						currentWith_2_tFileOutputExcel_3 = 12;
						fitWidth_tFileOutputExcel_3[2] = fitWidth_tFileOutputExcel_3[2] > currentWith_2_tFileOutputExcel_3
								? fitWidth_tFileOutputExcel_3[2]
								: currentWith_2_tFileOutputExcel_3 + 2;
					}

					if (row21.budget != null) {

//modif start

						columnIndex_tFileOutputExcel_3 = 3;

						jxl.write.WritableCell cell_3_tFileOutputExcel_3 = new jxl.write.Number(
								columnIndex_tFileOutputExcel_3,
								startRowNum_tFileOutputExcel_3 + nb_line_tFileOutputExcel_3,

//modif end
								row21.budget);
//modif start					
						// If we keep the cell format from the existing cell in sheet

//modif ends							
						writableSheet_tFileOutputExcel_3.addCell(cell_3_tFileOutputExcel_3);
						int currentWith_3_tFileOutputExcel_3 = String
								.valueOf(((jxl.write.Number) cell_3_tFileOutputExcel_3).getValue()).trim().length();
						currentWith_3_tFileOutputExcel_3 = currentWith_3_tFileOutputExcel_3 > 10 ? 10
								: currentWith_3_tFileOutputExcel_3;
						fitWidth_tFileOutputExcel_3[3] = fitWidth_tFileOutputExcel_3[3] > currentWith_3_tFileOutputExcel_3
								? fitWidth_tFileOutputExcel_3[3]
								: currentWith_3_tFileOutputExcel_3 + 2;
					}

					if (row21.revenue != null) {

//modif start

						columnIndex_tFileOutputExcel_3 = 4;

						jxl.write.WritableCell cell_4_tFileOutputExcel_3 = new jxl.write.Number(
								columnIndex_tFileOutputExcel_3,
								startRowNum_tFileOutputExcel_3 + nb_line_tFileOutputExcel_3,

//modif end
								row21.revenue);
//modif start					
						// If we keep the cell format from the existing cell in sheet

//modif ends							
						writableSheet_tFileOutputExcel_3.addCell(cell_4_tFileOutputExcel_3);
						int currentWith_4_tFileOutputExcel_3 = String
								.valueOf(((jxl.write.Number) cell_4_tFileOutputExcel_3).getValue()).trim().length();
						currentWith_4_tFileOutputExcel_3 = currentWith_4_tFileOutputExcel_3 > 10 ? 10
								: currentWith_4_tFileOutputExcel_3;
						fitWidth_tFileOutputExcel_3[4] = fitWidth_tFileOutputExcel_3[4] > currentWith_4_tFileOutputExcel_3
								? fitWidth_tFileOutputExcel_3[4]
								: currentWith_4_tFileOutputExcel_3 + 2;
					}

					if (row21.gain_perte != null) {

//modif start

						columnIndex_tFileOutputExcel_3 = 5;

						jxl.write.WritableCell cell_5_tFileOutputExcel_3 = new jxl.write.Number(
								columnIndex_tFileOutputExcel_3,
								startRowNum_tFileOutputExcel_3 + nb_line_tFileOutputExcel_3,

//modif end
								row21.gain_perte);
//modif start					
						// If we keep the cell format from the existing cell in sheet

//modif ends							
						writableSheet_tFileOutputExcel_3.addCell(cell_5_tFileOutputExcel_3);
						int currentWith_5_tFileOutputExcel_3 = String
								.valueOf(((jxl.write.Number) cell_5_tFileOutputExcel_3).getValue()).trim().length();
						currentWith_5_tFileOutputExcel_3 = currentWith_5_tFileOutputExcel_3 > 10 ? 10
								: currentWith_5_tFileOutputExcel_3;
						fitWidth_tFileOutputExcel_3[5] = fitWidth_tFileOutputExcel_3[5] > currentWith_5_tFileOutputExcel_3
								? fitWidth_tFileOutputExcel_3[5]
								: currentWith_5_tFileOutputExcel_3 + 2;
					}

					nb_line_tFileOutputExcel_3++;

					tos_count_tFileOutputExcel_3++;

					/**
					 * [tFileOutputExcel_3 main ] stop
					 */

					/**
					 * [tFileOutputExcel_3 process_data_begin ] start
					 */

					currentComponent = "tFileOutputExcel_3";

					/**
					 * [tFileOutputExcel_3 process_data_begin ] stop
					 */

					/**
					 * [tFileOutputExcel_3 process_data_end ] start
					 */

					currentComponent = "tFileOutputExcel_3";

					/**
					 * [tFileOutputExcel_3 process_data_end ] stop
					 */

					/**
					 * [tSortRow_5_SortIn process_data_end ] start
					 */

					currentVirtualComponent = "tSortRow_5";

					currentComponent = "tSortRow_5_SortIn";

					/**
					 * [tSortRow_5_SortIn process_data_end ] stop
					 */

					/**
					 * [tSortRow_5_SortIn end ] start
					 */

					currentVirtualComponent = "tSortRow_5";

					currentComponent = "tSortRow_5_SortIn";

				}

				globalMap.put("tSortRow_5_SortIn_NB_LINE", nb_line_tSortRow_5_SortIn);

				ok_Hash.put("tSortRow_5_SortIn", true);
				end_Hash.put("tSortRow_5_SortIn", System.currentTimeMillis());

				/**
				 * [tSortRow_5_SortIn end ] stop
				 */

				/**
				 * [tFileOutputExcel_3 end ] start
				 */

				currentComponent = "tFileOutputExcel_3";

				writeableWorkbook_tFileOutputExcel_3.write();
				writeableWorkbook_tFileOutputExcel_3.close();
				if (headerIsInserted_tFileOutputExcel_3 && nb_line_tFileOutputExcel_3 > 0) {
					nb_line_tFileOutputExcel_3 = nb_line_tFileOutputExcel_3 - 1;
				}
				globalMap.put("tFileOutputExcel_3_NB_LINE", nb_line_tFileOutputExcel_3);

				if (execStat) {
					runStat.updateStat(resourceMap, iterateId, 2, 0, "row21");
				}

				ok_Hash.put("tFileOutputExcel_3", true);
				end_Hash.put("tFileOutputExcel_3", System.currentTimeMillis());

				/**
				 * [tFileOutputExcel_3 end ] stop
				 */

				/**
				 * [tFileOutputDelimited_1 end ] start
				 */

				currentComponent = "tFileOutputDelimited_1";

				if (outtFileOutputDelimited_1 != null) {
					outtFileOutputDelimited_1.flush();
					outtFileOutputDelimited_1.close();
				}

				globalMap.put("tFileOutputDelimited_1_NB_LINE", nb_line_tFileOutputDelimited_1);
				globalMap.put("tFileOutputDelimited_1_FILE_NAME", fileName_tFileOutputDelimited_1);

				resourceMap.put("finish_tFileOutputDelimited_1", true);

				if (execStat) {
					runStat.updateStat(resourceMap, iterateId, 2, 0, "row8");
				}

				ok_Hash.put("tFileOutputDelimited_1", true);
				end_Hash.put("tFileOutputDelimited_1", System.currentTimeMillis());

				/**
				 * [tFileOutputDelimited_1 end ] stop
				 */

			} // end the resume

		} catch (java.lang.Exception e) {

			TalendException te = new TalendException(e, currentComponent, globalMap);

			te.setVirtualComponentName(currentVirtualComponent);

			throw te;
		} catch (java.lang.Error error) {

			runStat.stopThreadStat();

			throw error;
		} finally {

			// free memory for "tSortRow_5_SortIn"
			globalMap.remove("tSortRow_5");

			// free memory for "tSortRow_4_SortIn"
			globalMap.remove("tSortRow_4");

			// free memory for "tAggregateRow_1_AGGIN"
			globalMap.remove("tAggregateRow_1");

			// free memory for "tSortRow_3_SortIn"
			globalMap.remove("tSortRow_3");

			// free memory for "tSortRow_2_SortIn"
			globalMap.remove("tSortRow_2");

			// free memory for "tSortRow_1_SortIn"
			globalMap.remove("tSortRow_1");

			// free memory for "tMap_1"
			globalMap.remove("tHash_Lookup_row2");

			// free memory for "tMap_1"
			globalMap.remove("tHash_Lookup_row6");

			try {

				/**
				 * [tFileInputExcel_1 finally ] start
				 */

				currentComponent = "tFileInputExcel_1";

				/**
				 * [tFileInputExcel_1 finally ] stop
				 */

				/**
				 * [tLogRow_1 finally ] start
				 */

				currentComponent = "tLogRow_1";

				/**
				 * [tLogRow_1 finally ] stop
				 */

				/**
				 * [tFilterColumns_1 finally ] start
				 */

				currentComponent = "tFilterColumns_1";

				/**
				 * [tFilterColumns_1 finally ] stop
				 */

				/**
				 * [tMap_1 finally ] start
				 */

				currentComponent = "tMap_1";

				/**
				 * [tMap_1 finally ] stop
				 */

				/**
				 * [tFilterRow_1 finally ] start
				 */

				currentComponent = "tFilterRow_1";

				/**
				 * [tFilterRow_1 finally ] stop
				 */

				/**
				 * [tMap_2 finally ] start
				 */

				currentComponent = "tMap_2";

				/**
				 * [tMap_2 finally ] stop
				 */

				/**
				 * [tLogRow_5 finally ] start
				 */

				currentComponent = "tLogRow_5";

				/**
				 * [tLogRow_5 finally ] stop
				 */

				/**
				 * [tSortRow_1_SortOut finally ] start
				 */

				currentVirtualComponent = "tSortRow_1";

				currentComponent = "tSortRow_1_SortOut";

				/**
				 * [tSortRow_1_SortOut finally ] stop
				 */

				/**
				 * [tSortRow_1_SortIn finally ] start
				 */

				currentVirtualComponent = "tSortRow_1";

				currentComponent = "tSortRow_1_SortIn";

				/**
				 * [tSortRow_1_SortIn finally ] stop
				 */

				/**
				 * [tFileOutputDelimited_2 finally ] start
				 */

				currentComponent = "tFileOutputDelimited_2";

				if (resourceMap.get("finish_tFileOutputDelimited_2") == null) {

					java.io.Writer outtFileOutputDelimited_2 = (java.io.Writer) resourceMap
							.get("out_tFileOutputDelimited_2");
					if (outtFileOutputDelimited_2 != null) {
						outtFileOutputDelimited_2.flush();
						outtFileOutputDelimited_2.close();
					}

				}

				/**
				 * [tFileOutputDelimited_2 finally ] stop
				 */

				/**
				 * [tLogRow_6 finally ] start
				 */

				currentComponent = "tLogRow_6";

				/**
				 * [tLogRow_6 finally ] stop
				 */

				/**
				 * [tSortRow_2_SortOut finally ] start
				 */

				currentVirtualComponent = "tSortRow_2";

				currentComponent = "tSortRow_2_SortOut";

				/**
				 * [tSortRow_2_SortOut finally ] stop
				 */

				/**
				 * [tSortRow_2_SortIn finally ] start
				 */

				currentVirtualComponent = "tSortRow_2";

				currentComponent = "tSortRow_2_SortIn";

				/**
				 * [tSortRow_2_SortIn finally ] stop
				 */

				/**
				 * [tFileOutputDelimited_3 finally ] start
				 */

				currentComponent = "tFileOutputDelimited_3";

				if (resourceMap.get("finish_tFileOutputDelimited_3") == null) {

					java.io.Writer outtFileOutputDelimited_3 = (java.io.Writer) resourceMap
							.get("out_tFileOutputDelimited_3");
					if (outtFileOutputDelimited_3 != null) {
						outtFileOutputDelimited_3.flush();
						outtFileOutputDelimited_3.close();
					}

				}

				/**
				 * [tFileOutputDelimited_3 finally ] stop
				 */

				/**
				 * [tLogRow_4 finally ] start
				 */

				currentComponent = "tLogRow_4";

				/**
				 * [tLogRow_4 finally ] stop
				 */

				/**
				 * [tFileOutputXML_1 finally ] start
				 */

				currentComponent = "tFileOutputXML_1";

				/**
				 * [tFileOutputXML_1 finally ] stop
				 */

				/**
				 * [tLogRow_7 finally ] start
				 */

				currentComponent = "tLogRow_7";

				/**
				 * [tLogRow_7 finally ] stop
				 */

				/**
				 * [tSortRow_3_SortOut finally ] start
				 */

				currentVirtualComponent = "tSortRow_3";

				currentComponent = "tSortRow_3_SortOut";

				/**
				 * [tSortRow_3_SortOut finally ] stop
				 */

				/**
				 * [tSortRow_3_SortIn finally ] start
				 */

				currentVirtualComponent = "tSortRow_3";

				currentComponent = "tSortRow_3_SortIn";

				/**
				 * [tSortRow_3_SortIn finally ] stop
				 */

				/**
				 * [tFileOutputExcel_1 finally ] start
				 */

				currentComponent = "tFileOutputExcel_1";

				/**
				 * [tFileOutputExcel_1 finally ] stop
				 */

				/**
				 * [tLogRow_8 finally ] start
				 */

				currentComponent = "tLogRow_8";

				/**
				 * [tLogRow_8 finally ] stop
				 */

				/**
				 * [tAggregateRow_1_AGGOUT finally ] start
				 */

				currentVirtualComponent = "tAggregateRow_1";

				currentComponent = "tAggregateRow_1_AGGOUT";

				/**
				 * [tAggregateRow_1_AGGOUT finally ] stop
				 */

				/**
				 * [tAggregateRow_1_AGGIN finally ] start
				 */

				currentVirtualComponent = "tAggregateRow_1";

				currentComponent = "tAggregateRow_1_AGGIN";

				/**
				 * [tAggregateRow_1_AGGIN finally ] stop
				 */

				/**
				 * [tSortRow_4_SortOut finally ] start
				 */

				currentVirtualComponent = "tSortRow_4";

				currentComponent = "tSortRow_4_SortOut";

				/**
				 * [tSortRow_4_SortOut finally ] stop
				 */

				/**
				 * [tSortRow_4_SortIn finally ] start
				 */

				currentVirtualComponent = "tSortRow_4";

				currentComponent = "tSortRow_4_SortIn";

				/**
				 * [tSortRow_4_SortIn finally ] stop
				 */

				/**
				 * [tFileOutputExcel_2 finally ] start
				 */

				currentComponent = "tFileOutputExcel_2";

				/**
				 * [tFileOutputExcel_2 finally ] stop
				 */

				/**
				 * [tLogRow_9 finally ] start
				 */

				currentComponent = "tLogRow_9";

				/**
				 * [tLogRow_9 finally ] stop
				 */

				/**
				 * [tSortRow_5_SortOut finally ] start
				 */

				currentVirtualComponent = "tSortRow_5";

				currentComponent = "tSortRow_5_SortOut";

				/**
				 * [tSortRow_5_SortOut finally ] stop
				 */

				/**
				 * [tSortRow_5_SortIn finally ] start
				 */

				currentVirtualComponent = "tSortRow_5";

				currentComponent = "tSortRow_5_SortIn";

				/**
				 * [tSortRow_5_SortIn finally ] stop
				 */

				/**
				 * [tFileOutputExcel_3 finally ] start
				 */

				currentComponent = "tFileOutputExcel_3";

				/**
				 * [tFileOutputExcel_3 finally ] stop
				 */

				/**
				 * [tFileOutputDelimited_1 finally ] start
				 */

				currentComponent = "tFileOutputDelimited_1";

				if (resourceMap.get("finish_tFileOutputDelimited_1") == null) {

					java.io.Writer outtFileOutputDelimited_1 = (java.io.Writer) resourceMap
							.get("out_tFileOutputDelimited_1");
					if (outtFileOutputDelimited_1 != null) {
						outtFileOutputDelimited_1.flush();
						outtFileOutputDelimited_1.close();
					}

				}

				/**
				 * [tFileOutputDelimited_1 finally ] stop
				 */

			} catch (java.lang.Exception e) {
				// ignore
			} catch (java.lang.Error error) {
				// ignore
			}
			resourceMap = null;
		}

		globalMap.put("tFileInputExcel_1_SUBPROCESS_STATE", 1);
	}

	public static class row2Struct implements routines.system.IPersistableComparableLookupRow<row2Struct> {
		final static byte[] commonByteArrayLock_MYFIRSTJOB_TP_MAJ = new byte[0];
		static byte[] commonByteArray_MYFIRSTJOB_TP_MAJ = new byte[0];
		protected static final int DEFAULT_HASHCODE = 1;
		protected static final int PRIME = 31;
		protected int hashCode = DEFAULT_HASHCODE;
		public boolean hashCodeDirty = true;

		public String loopKey;

		public Integer movie_id;

		public Integer getMovie_id() {
			return this.movie_id;
		}

		public Integer budget;

		public Integer getBudget() {
			return this.budget;
		}

		public Long revenue;

		public Long getRevenue() {
			return this.revenue;
		}

		@Override
		public int hashCode() {
			if (this.hashCodeDirty) {
				final int prime = PRIME;
				int result = DEFAULT_HASHCODE;

				result = prime * result + ((this.movie_id == null) ? 0 : this.movie_id.hashCode());

				this.hashCode = result;
				this.hashCodeDirty = false;
			}
			return this.hashCode;
		}

		@Override
		public boolean equals(Object obj) {
			if (this == obj)
				return true;
			if (obj == null)
				return false;
			if (getClass() != obj.getClass())
				return false;
			final row2Struct other = (row2Struct) obj;

			if (this.movie_id == null) {
				if (other.movie_id != null)
					return false;

			} else if (!this.movie_id.equals(other.movie_id))

				return false;

			return true;
		}

		public void copyDataTo(row2Struct other) {

			other.movie_id = this.movie_id;
			other.budget = this.budget;
			other.revenue = this.revenue;

		}

		public void copyKeysDataTo(row2Struct other) {

			other.movie_id = this.movie_id;

		}

		private Integer readInteger(ObjectInputStream dis) throws IOException {
			Integer intReturn;
			int length = 0;
			length = dis.readByte();
			if (length == -1) {
				intReturn = null;
			} else {
				intReturn = dis.readInt();
			}
			return intReturn;
		}

		private Integer readInteger(org.jboss.marshalling.Unmarshaller dis) throws IOException {
			Integer intReturn;
			int length = 0;
			length = dis.readByte();
			if (length == -1) {
				intReturn = null;
			} else {
				intReturn = dis.readInt();
			}
			return intReturn;
		}

		private void writeInteger(Integer intNum, ObjectOutputStream dos) throws IOException {
			if (intNum == null) {
				dos.writeByte(-1);
			} else {
				dos.writeByte(0);
				dos.writeInt(intNum);
			}
		}

		private void writeInteger(Integer intNum, org.jboss.marshalling.Marshaller marshaller) throws IOException {
			if (intNum == null) {
				marshaller.writeByte(-1);
			} else {
				marshaller.writeByte(0);
				marshaller.writeInt(intNum);
			}
		}

		private Integer readInteger(DataInputStream dis, ObjectInputStream ois) throws IOException {
			Integer intReturn;
			int length = 0;
			length = dis.readByte();
			if (length == -1) {
				intReturn = null;
			} else {
				intReturn = dis.readInt();
			}
			return intReturn;
		}

		private Integer readInteger(DataInputStream dis, org.jboss.marshalling.Unmarshaller unmarshaller)
				throws IOException {
			Integer intReturn;
			int length = 0;
			length = unmarshaller.readByte();
			if (length == -1) {
				intReturn = null;
			} else {
				intReturn = unmarshaller.readInt();
			}
			return intReturn;
		}

		private void writeInteger(Integer intNum, DataOutputStream dos, ObjectOutputStream oos) throws IOException {
			if (intNum == null) {
				dos.writeByte(-1);
			} else {
				dos.writeByte(0);
				dos.writeInt(intNum);
			}
		}

		private void writeInteger(Integer intNum, DataOutputStream dos, org.jboss.marshalling.Marshaller marshaller)
				throws IOException {
			if (intNum == null) {
				marshaller.writeByte(-1);
			} else {
				marshaller.writeByte(0);
				marshaller.writeInt(intNum);
			}
		}

		public void readKeysData(ObjectInputStream dis) {

			synchronized (commonByteArrayLock_MYFIRSTJOB_TP_MAJ) {

				try {

					int length = 0;

					this.movie_id = readInteger(dis);

				} catch (IOException e) {
					throw new RuntimeException(e);

				}

			}

		}

		public void readKeysData(org.jboss.marshalling.Unmarshaller dis) {

			synchronized (commonByteArrayLock_MYFIRSTJOB_TP_MAJ) {

				try {

					int length = 0;

					this.movie_id = readInteger(dis);

				} catch (IOException e) {
					throw new RuntimeException(e);

				}

			}

		}

		public void writeKeysData(ObjectOutputStream dos) {
			try {

				// Integer

				writeInteger(this.movie_id, dos);

			} catch (IOException e) {
				throw new RuntimeException(e);
			}

		}

		public void writeKeysData(org.jboss.marshalling.Marshaller dos) {
			try {

				// Integer

				writeInteger(this.movie_id, dos);

			} catch (IOException e) {
				throw new RuntimeException(e);
			}

		}

		/**
		 * Fill Values data by reading ObjectInputStream.
		 */
		public void readValuesData(DataInputStream dis, ObjectInputStream ois) {
			try {

				int length = 0;

				this.budget = readInteger(dis, ois);

				length = dis.readByte();
				if (length == -1) {
					this.revenue = null;
				} else {
					this.revenue = dis.readLong();
				}

			} catch (IOException e) {
				throw new RuntimeException(e);

			}

		}

		public void readValuesData(DataInputStream dis, org.jboss.marshalling.Unmarshaller objectIn) {
			try {
				int length = 0;

				this.budget = readInteger(dis, objectIn);

				length = objectIn.readByte();
				if (length == -1) {
					this.revenue = null;
				} else {
					this.revenue = objectIn.readLong();
				}

			} catch (IOException e) {
				throw new RuntimeException(e);

			}

		}

		/**
		 * Return a byte array which represents Values data.
		 */
		public void writeValuesData(DataOutputStream dos, ObjectOutputStream oos) {
			try {

				writeInteger(this.budget, dos, oos);

				if (this.revenue == null) {
					dos.writeByte(-1);
				} else {
					dos.writeByte(0);
					dos.writeLong(this.revenue);
				}

			} catch (IOException e) {
				throw new RuntimeException(e);
			}

		}

		public void writeValuesData(DataOutputStream dos, org.jboss.marshalling.Marshaller objectOut) {
			try {

				writeInteger(this.budget, dos, objectOut);

				if (this.revenue == null) {
					objectOut.writeByte(-1);
				} else {
					objectOut.writeByte(0);
					objectOut.writeLong(this.revenue);
				}

			} catch (IOException e) {
				throw new RuntimeException(e);
			}
		}

		public boolean supportMarshaller() {
			return true;
		}

		public String toString() {

			StringBuilder sb = new StringBuilder();
			sb.append(super.toString());
			sb.append("[");
			sb.append("movie_id=" + String.valueOf(movie_id));
			sb.append(",budget=" + String.valueOf(budget));
			sb.append(",revenue=" + String.valueOf(revenue));
			sb.append("]");

			return sb.toString();
		}

		/**
		 * Compare keys
		 */
		public int compareTo(row2Struct other) {

			int returnValue = -1;

			returnValue = checkNullsAndCompare(this.movie_id, other.movie_id);
			if (returnValue != 0) {
				return returnValue;
			}

			return returnValue;
		}

		private int checkNullsAndCompare(Object object1, Object object2) {
			int returnValue = 0;
			if (object1 instanceof Comparable && object2 instanceof Comparable) {
				returnValue = ((Comparable) object1).compareTo(object2);
			} else if (object1 != null && object2 != null) {
				returnValue = compareStrings(object1.toString(), object2.toString());
			} else if (object1 == null && object2 != null) {
				returnValue = 1;
			} else if (object1 != null && object2 == null) {
				returnValue = -1;
			} else {
				returnValue = 0;
			}

			return returnValue;
		}

		private int compareStrings(String string1, String string2) {
			return string1.compareTo(string2);
		}

	}

	public static class row1Struct implements routines.system.IPersistableRow<row1Struct> {
		final static byte[] commonByteArrayLock_MYFIRSTJOB_TP_MAJ = new byte[0];
		static byte[] commonByteArray_MYFIRSTJOB_TP_MAJ = new byte[0];
		protected static final int DEFAULT_HASHCODE = 1;
		protected static final int PRIME = 31;
		protected int hashCode = DEFAULT_HASHCODE;
		public boolean hashCodeDirty = true;

		public String loopKey;

		public Integer movie_id;

		public Integer getMovie_id() {
			return this.movie_id;
		}

		public Integer budget;

		public Integer getBudget() {
			return this.budget;
		}

		public Long revenue;

		public Long getRevenue() {
			return this.revenue;
		}

		@Override
		public int hashCode() {
			if (this.hashCodeDirty) {
				final int prime = PRIME;
				int result = DEFAULT_HASHCODE;

				result = prime * result + ((this.movie_id == null) ? 0 : this.movie_id.hashCode());

				this.hashCode = result;
				this.hashCodeDirty = false;
			}
			return this.hashCode;
		}

		@Override
		public boolean equals(Object obj) {
			if (this == obj)
				return true;
			if (obj == null)
				return false;
			if (getClass() != obj.getClass())
				return false;
			final row1Struct other = (row1Struct) obj;

			if (this.movie_id == null) {
				if (other.movie_id != null)
					return false;

			} else if (!this.movie_id.equals(other.movie_id))

				return false;

			return true;
		}

		public void copyDataTo(row1Struct other) {

			other.movie_id = this.movie_id;
			other.budget = this.budget;
			other.revenue = this.revenue;

		}

		public void copyKeysDataTo(row1Struct other) {

			other.movie_id = this.movie_id;

		}

		private Integer readInteger(ObjectInputStream dis) throws IOException {
			Integer intReturn;
			int length = 0;
			length = dis.readByte();
			if (length == -1) {
				intReturn = null;
			} else {
				intReturn = dis.readInt();
			}
			return intReturn;
		}

		private Integer readInteger(org.jboss.marshalling.Unmarshaller dis) throws IOException {
			Integer intReturn;
			int length = 0;
			length = dis.readByte();
			if (length == -1) {
				intReturn = null;
			} else {
				intReturn = dis.readInt();
			}
			return intReturn;
		}

		private void writeInteger(Integer intNum, ObjectOutputStream dos) throws IOException {
			if (intNum == null) {
				dos.writeByte(-1);
			} else {
				dos.writeByte(0);
				dos.writeInt(intNum);
			}
		}

		private void writeInteger(Integer intNum, org.jboss.marshalling.Marshaller marshaller) throws IOException {
			if (intNum == null) {
				marshaller.writeByte(-1);
			} else {
				marshaller.writeByte(0);
				marshaller.writeInt(intNum);
			}
		}

		public void readData(ObjectInputStream dis) {

			synchronized (commonByteArrayLock_MYFIRSTJOB_TP_MAJ) {

				try {

					int length = 0;

					this.movie_id = readInteger(dis);

					this.budget = readInteger(dis);

					length = dis.readByte();
					if (length == -1) {
						this.revenue = null;
					} else {
						this.revenue = dis.readLong();
					}

				} catch (IOException e) {
					throw new RuntimeException(e);

				}

			}

		}

		public void readData(org.jboss.marshalling.Unmarshaller dis) {

			synchronized (commonByteArrayLock_MYFIRSTJOB_TP_MAJ) {

				try {

					int length = 0;

					this.movie_id = readInteger(dis);

					this.budget = readInteger(dis);

					length = dis.readByte();
					if (length == -1) {
						this.revenue = null;
					} else {
						this.revenue = dis.readLong();
					}

				} catch (IOException e) {
					throw new RuntimeException(e);

				}

			}

		}

		public void writeData(ObjectOutputStream dos) {
			try {

				// Integer

				writeInteger(this.movie_id, dos);

				// Integer

				writeInteger(this.budget, dos);

				// Long

				if (this.revenue == null) {
					dos.writeByte(-1);
				} else {
					dos.writeByte(0);
					dos.writeLong(this.revenue);
				}

			} catch (IOException e) {
				throw new RuntimeException(e);
			}

		}

		public void writeData(org.jboss.marshalling.Marshaller dos) {
			try {

				// Integer

				writeInteger(this.movie_id, dos);

				// Integer

				writeInteger(this.budget, dos);

				// Long

				if (this.revenue == null) {
					dos.writeByte(-1);
				} else {
					dos.writeByte(0);
					dos.writeLong(this.revenue);
				}

			} catch (IOException e) {
				throw new RuntimeException(e);
			}

		}

		public String toString() {

			StringBuilder sb = new StringBuilder();
			sb.append(super.toString());
			sb.append("[");
			sb.append("movie_id=" + String.valueOf(movie_id));
			sb.append(",budget=" + String.valueOf(budget));
			sb.append(",revenue=" + String.valueOf(revenue));
			sb.append("]");

			return sb.toString();
		}

		/**
		 * Compare keys
		 */
		public int compareTo(row1Struct other) {

			int returnValue = -1;

			returnValue = checkNullsAndCompare(this.movie_id, other.movie_id);
			if (returnValue != 0) {
				return returnValue;
			}

			return returnValue;
		}

		private int checkNullsAndCompare(Object object1, Object object2) {
			int returnValue = 0;
			if (object1 instanceof Comparable && object2 instanceof Comparable) {
				returnValue = ((Comparable) object1).compareTo(object2);
			} else if (object1 != null && object2 != null) {
				returnValue = compareStrings(object1.toString(), object2.toString());
			} else if (object1 == null && object2 != null) {
				returnValue = 1;
			} else if (object1 != null && object2 == null) {
				returnValue = -1;
			} else {
				returnValue = 0;
			}

			return returnValue;
		}

		private int compareStrings(String string1, String string2) {
			return string1.compareTo(string2);
		}

	}

	public void tFileInputDelimited_1Process(final java.util.Map<String, Object> globalMap) throws TalendException {
		globalMap.put("tFileInputDelimited_1_SUBPROCESS_STATE", 0);

		final boolean execStat = this.execStat;

		String iterateId = "";

		String currentComponent = "";
		java.util.Map<String, Object> resourceMap = new java.util.HashMap<String, Object>();

		try {
			// TDI-39566 avoid throwing an useless Exception
			boolean resumeIt = true;
			if (globalResumeTicket == false && resumeEntryMethodName != null) {
				String currentMethodName = new java.lang.Exception().getStackTrace()[0].getMethodName();
				resumeIt = resumeEntryMethodName.equals(currentMethodName);
			}
			if (resumeIt || globalResumeTicket) { // start the resume
				globalResumeTicket = true;

				row1Struct row1 = new row1Struct();
				row1Struct row2 = row1;

				/**
				 * [tAdvancedHash_row2 begin ] start
				 */

				ok_Hash.put("tAdvancedHash_row2", false);
				start_Hash.put("tAdvancedHash_row2", System.currentTimeMillis());

				currentComponent = "tAdvancedHash_row2";

				if (execStat) {
					runStat.updateStatOnConnection(resourceMap, iterateId, 0, 0, "row2");
				}

				int tos_count_tAdvancedHash_row2 = 0;

				// connection name:row2
				// source node:tLogRow_2 - inputs:(row1) outputs:(row2,row2) | target
				// node:tAdvancedHash_row2 - inputs:(row2) outputs:()
				// linked node: tMap_1 - inputs:(row7,row2,row6) outputs:(movieJoint)

				org.talend.designer.components.lookup.common.ICommonLookup.MATCHING_MODE matchingModeEnum_row2 = org.talend.designer.components.lookup.common.ICommonLookup.MATCHING_MODE.UNIQUE_MATCH;

				org.talend.designer.components.lookup.memory.AdvancedMemoryLookup<row2Struct> tHash_Lookup_row2 = org.talend.designer.components.lookup.memory.AdvancedMemoryLookup
						.<row2Struct>getLookup(matchingModeEnum_row2);

				globalMap.put("tHash_Lookup_row2", tHash_Lookup_row2);

				/**
				 * [tAdvancedHash_row2 begin ] stop
				 */

				/**
				 * [tLogRow_2 begin ] start
				 */

				ok_Hash.put("tLogRow_2", false);
				start_Hash.put("tLogRow_2", System.currentTimeMillis());

				currentComponent = "tLogRow_2";

				if (execStat) {
					runStat.updateStatOnConnection(resourceMap, iterateId, 0, 0, "row1");
				}

				int tos_count_tLogRow_2 = 0;

				///////////////////////

				class Util_tLogRow_2 {

					String[] des_top = { ".", ".", "-", "+" };

					String[] des_head = { "|=", "=|", "-", "+" };

					String[] des_bottom = { "'", "'", "-", "+" };

					String name = "";

					java.util.List<String[]> list = new java.util.ArrayList<String[]>();

					int[] colLengths = new int[3];

					public void addRow(String[] row) {

						for (int i = 0; i < 3; i++) {
							if (row[i] != null) {
								colLengths[i] = Math.max(colLengths[i], row[i].length());
							}
						}
						list.add(row);
					}

					public void setTableName(String name) {

						this.name = name;
					}

					public StringBuilder format() {

						StringBuilder sb = new StringBuilder();

						sb.append(print(des_top));

						int totals = 0;
						for (int i = 0; i < colLengths.length; i++) {
							totals = totals + colLengths[i];
						}

						// name
						sb.append("|");
						int k = 0;
						for (k = 0; k < (totals + 2 - name.length()) / 2; k++) {
							sb.append(' ');
						}
						sb.append(name);
						for (int i = 0; i < totals + 2 - name.length() - k; i++) {
							sb.append(' ');
						}
						sb.append("|\n");

						// head and rows
						sb.append(print(des_head));
						for (int i = 0; i < list.size(); i++) {

							String[] row = list.get(i);

							java.util.Formatter formatter = new java.util.Formatter(new StringBuilder());

							StringBuilder sbformat = new StringBuilder();
							sbformat.append("|%1$-");
							sbformat.append(colLengths[0]);
							sbformat.append("s");

							sbformat.append("|%2$-");
							sbformat.append(colLengths[1]);
							sbformat.append("s");

							sbformat.append("|%3$-");
							sbformat.append(colLengths[2]);
							sbformat.append("s");

							sbformat.append("|\n");

							formatter.format(sbformat.toString(), (Object[]) row);

							sb.append(formatter.toString());
							if (i == 0)
								sb.append(print(des_head)); // print the head
						}

						// end
						sb.append(print(des_bottom));
						return sb;
					}

					private StringBuilder print(String[] fillChars) {
						StringBuilder sb = new StringBuilder();
						// first column
						sb.append(fillChars[0]);
						for (int i = 0; i < colLengths[0] - fillChars[0].length() + 1; i++) {
							sb.append(fillChars[2]);
						}
						sb.append(fillChars[3]);

						for (int i = 0; i < colLengths[1] - fillChars[3].length() + 1; i++) {
							sb.append(fillChars[2]);
						}
						sb.append(fillChars[3]);

						// last column
						for (int i = 0; i < colLengths[2] - fillChars[1].length() + 1; i++) {
							sb.append(fillChars[2]);
						}
						sb.append(fillChars[1]);
						sb.append("\n");
						return sb;
					}

					public boolean isTableEmpty() {
						if (list.size() > 1)
							return false;
						return true;
					}
				}
				Util_tLogRow_2 util_tLogRow_2 = new Util_tLogRow_2();
				util_tLogRow_2.setTableName("logIncomes");
				util_tLogRow_2.addRow(new String[] { "movie_id", "budget", "revenue", });
				StringBuilder strBuffer_tLogRow_2 = null;
				int nb_line_tLogRow_2 = 0;
///////////////////////    			

				/**
				 * [tLogRow_2 begin ] stop
				 */

				/**
				 * [tFileInputDelimited_1 begin ] start
				 */

				ok_Hash.put("tFileInputDelimited_1", false);
				start_Hash.put("tFileInputDelimited_1", System.currentTimeMillis());

				currentComponent = "tFileInputDelimited_1";

				int tos_count_tFileInputDelimited_1 = 0;

				final routines.system.RowState rowstate_tFileInputDelimited_1 = new routines.system.RowState();

				int nb_line_tFileInputDelimited_1 = 0;
				org.talend.fileprocess.FileInputDelimited fid_tFileInputDelimited_1 = null;
				int limit_tFileInputDelimited_1 = -1;
				try {

					Object filename_tFileInputDelimited_1 = "C:/Users/ananf/OneDrive/Documents/Aivancity/DATA pipeline/moviesIncome.csv";
					if (filename_tFileInputDelimited_1 instanceof java.io.InputStream) {

						int footer_value_tFileInputDelimited_1 = 0, random_value_tFileInputDelimited_1 = -1;
						if (footer_value_tFileInputDelimited_1 > 0 || random_value_tFileInputDelimited_1 > 0) {
							throw new java.lang.Exception(
									"When the input source is a stream,footer and random shouldn't be bigger than 0.");
						}

					}
					try {
						fid_tFileInputDelimited_1 = new org.talend.fileprocess.FileInputDelimited(
								"C:/Users/ananf/OneDrive/Documents/Aivancity/DATA pipeline/moviesIncome.csv",
								"US-ASCII", ";", "\n", false, 1, 0, limit_tFileInputDelimited_1, -1, false);
					} catch (java.lang.Exception e) {
						globalMap.put("tFileInputDelimited_1_ERROR_MESSAGE", e.getMessage());

						System.err.println(e.getMessage());

					}

					while (fid_tFileInputDelimited_1 != null && fid_tFileInputDelimited_1.nextRecord()) {
						rowstate_tFileInputDelimited_1.reset();

						row1 = null;

						boolean whetherReject_tFileInputDelimited_1 = false;
						row1 = new row1Struct();
						try {

							int columnIndexWithD_tFileInputDelimited_1 = 0;

							String temp = "";

							columnIndexWithD_tFileInputDelimited_1 = 0;

							temp = fid_tFileInputDelimited_1.get(columnIndexWithD_tFileInputDelimited_1);
							if (temp.length() > 0) {

								try {

									row1.movie_id = ParserUtils.parseTo_Integer(temp);

								} catch (java.lang.Exception ex_tFileInputDelimited_1) {
									globalMap.put("tFileInputDelimited_1_ERROR_MESSAGE",
											ex_tFileInputDelimited_1.getMessage());
									rowstate_tFileInputDelimited_1.setException(new RuntimeException(String.format(
											"Couldn't parse value for column '%s' in '%s', value is '%s'. Details: %s",
											"movie_id", "row1", temp, ex_tFileInputDelimited_1),
											ex_tFileInputDelimited_1));
								}

							} else {

								row1.movie_id = null;

							}

							columnIndexWithD_tFileInputDelimited_1 = 1;

							temp = fid_tFileInputDelimited_1.get(columnIndexWithD_tFileInputDelimited_1);
							if (temp.length() > 0) {

								try {

									row1.budget = ParserUtils.parseTo_Integer(temp);

								} catch (java.lang.Exception ex_tFileInputDelimited_1) {
									globalMap.put("tFileInputDelimited_1_ERROR_MESSAGE",
											ex_tFileInputDelimited_1.getMessage());
									rowstate_tFileInputDelimited_1.setException(new RuntimeException(String.format(
											"Couldn't parse value for column '%s' in '%s', value is '%s'. Details: %s",
											"budget", "row1", temp, ex_tFileInputDelimited_1),
											ex_tFileInputDelimited_1));
								}

							} else {

								row1.budget = null;

							}

							columnIndexWithD_tFileInputDelimited_1 = 2;

							temp = fid_tFileInputDelimited_1.get(columnIndexWithD_tFileInputDelimited_1);
							if (temp.length() > 0) {

								try {

									row1.revenue = ParserUtils.parseTo_Long(temp);

								} catch (java.lang.Exception ex_tFileInputDelimited_1) {
									globalMap.put("tFileInputDelimited_1_ERROR_MESSAGE",
											ex_tFileInputDelimited_1.getMessage());
									rowstate_tFileInputDelimited_1.setException(new RuntimeException(String.format(
											"Couldn't parse value for column '%s' in '%s', value is '%s'. Details: %s",
											"revenue", "row1", temp, ex_tFileInputDelimited_1),
											ex_tFileInputDelimited_1));
								}

							} else {

								row1.revenue = null;

							}

							if (rowstate_tFileInputDelimited_1.getException() != null) {
								throw rowstate_tFileInputDelimited_1.getException();
							}

						} catch (java.lang.Exception e) {
							globalMap.put("tFileInputDelimited_1_ERROR_MESSAGE", e.getMessage());
							whetherReject_tFileInputDelimited_1 = true;

							System.err.println(e.getMessage());
							row1 = null;

						}

						/**
						 * [tFileInputDelimited_1 begin ] stop
						 */

						/**
						 * [tFileInputDelimited_1 main ] start
						 */

						currentComponent = "tFileInputDelimited_1";

						tos_count_tFileInputDelimited_1++;

						/**
						 * [tFileInputDelimited_1 main ] stop
						 */

						/**
						 * [tFileInputDelimited_1 process_data_begin ] start
						 */

						currentComponent = "tFileInputDelimited_1";

						/**
						 * [tFileInputDelimited_1 process_data_begin ] stop
						 */
// Start of branch "row1"
						if (row1 != null) {

							/**
							 * [tLogRow_2 main ] start
							 */

							currentComponent = "tLogRow_2";

							if (execStat) {
								runStat.updateStatOnConnection(iterateId, 1, 1

										, "row1"

								);
							}

///////////////////////		

							String[] row_tLogRow_2 = new String[3];

							if (row1.movie_id != null) { //
								row_tLogRow_2[0] = String.valueOf(row1.movie_id);

							} //

							if (row1.budget != null) { //
								row_tLogRow_2[1] = String.valueOf(row1.budget);

							} //

							if (row1.revenue != null) { //
								row_tLogRow_2[2] = String.valueOf(row1.revenue);

							} //

							util_tLogRow_2.addRow(row_tLogRow_2);
							nb_line_tLogRow_2++;
//////

//////                    

///////////////////////    			

							row2 = row1;

							tos_count_tLogRow_2++;

							/**
							 * [tLogRow_2 main ] stop
							 */

							/**
							 * [tLogRow_2 process_data_begin ] start
							 */

							currentComponent = "tLogRow_2";

							/**
							 * [tLogRow_2 process_data_begin ] stop
							 */

							/**
							 * [tAdvancedHash_row2 main ] start
							 */

							currentComponent = "tAdvancedHash_row2";

							if (execStat) {
								runStat.updateStatOnConnection(iterateId, 1, 1

										, "row2"

								);
							}

							row2Struct row2_HashRow = new row2Struct();

							row2_HashRow.movie_id = row2.movie_id;

							row2_HashRow.budget = row2.budget;

							row2_HashRow.revenue = row2.revenue;

							tHash_Lookup_row2.put(row2_HashRow);

							tos_count_tAdvancedHash_row2++;

							/**
							 * [tAdvancedHash_row2 main ] stop
							 */

							/**
							 * [tAdvancedHash_row2 process_data_begin ] start
							 */

							currentComponent = "tAdvancedHash_row2";

							/**
							 * [tAdvancedHash_row2 process_data_begin ] stop
							 */

							/**
							 * [tAdvancedHash_row2 process_data_end ] start
							 */

							currentComponent = "tAdvancedHash_row2";

							/**
							 * [tAdvancedHash_row2 process_data_end ] stop
							 */

							/**
							 * [tLogRow_2 process_data_end ] start
							 */

							currentComponent = "tLogRow_2";

							/**
							 * [tLogRow_2 process_data_end ] stop
							 */

						} // End of branch "row1"

						/**
						 * [tFileInputDelimited_1 process_data_end ] start
						 */

						currentComponent = "tFileInputDelimited_1";

						/**
						 * [tFileInputDelimited_1 process_data_end ] stop
						 */

						/**
						 * [tFileInputDelimited_1 end ] start
						 */

						currentComponent = "tFileInputDelimited_1";

					}
				} finally {
					if (!((Object) ("C:/Users/ananf/OneDrive/Documents/Aivancity/DATA pipeline/moviesIncome.csv") instanceof java.io.InputStream)) {
						if (fid_tFileInputDelimited_1 != null) {
							fid_tFileInputDelimited_1.close();
						}
					}
					if (fid_tFileInputDelimited_1 != null) {
						globalMap.put("tFileInputDelimited_1_NB_LINE", fid_tFileInputDelimited_1.getRowNumber());

					}
				}

				ok_Hash.put("tFileInputDelimited_1", true);
				end_Hash.put("tFileInputDelimited_1", System.currentTimeMillis());

				/**
				 * [tFileInputDelimited_1 end ] stop
				 */

				/**
				 * [tLogRow_2 end ] start
				 */

				currentComponent = "tLogRow_2";

//////

				java.io.PrintStream consoleOut_tLogRow_2 = null;
				if (globalMap.get("tLogRow_CONSOLE") != null) {
					consoleOut_tLogRow_2 = (java.io.PrintStream) globalMap.get("tLogRow_CONSOLE");
				} else {
					consoleOut_tLogRow_2 = new java.io.PrintStream(new java.io.BufferedOutputStream(System.out));
					globalMap.put("tLogRow_CONSOLE", consoleOut_tLogRow_2);
				}

				consoleOut_tLogRow_2.println(util_tLogRow_2.format().toString());
				consoleOut_tLogRow_2.flush();
//////
				globalMap.put("tLogRow_2_NB_LINE", nb_line_tLogRow_2);

///////////////////////    			

				if (execStat) {
					runStat.updateStat(resourceMap, iterateId, 2, 0, "row1");
				}

				ok_Hash.put("tLogRow_2", true);
				end_Hash.put("tLogRow_2", System.currentTimeMillis());

				/**
				 * [tLogRow_2 end ] stop
				 */

				/**
				 * [tAdvancedHash_row2 end ] start
				 */

				currentComponent = "tAdvancedHash_row2";

				tHash_Lookup_row2.endPut();

				if (execStat) {
					runStat.updateStat(resourceMap, iterateId, 2, 0, "row2");
				}

				ok_Hash.put("tAdvancedHash_row2", true);
				end_Hash.put("tAdvancedHash_row2", System.currentTimeMillis());

				/**
				 * [tAdvancedHash_row2 end ] stop
				 */

			} // end the resume

		} catch (java.lang.Exception e) {

			TalendException te = new TalendException(e, currentComponent, globalMap);

			throw te;
		} catch (java.lang.Error error) {

			runStat.stopThreadStat();

			throw error;
		} finally {

			try {

				/**
				 * [tFileInputDelimited_1 finally ] start
				 */

				currentComponent = "tFileInputDelimited_1";

				/**
				 * [tFileInputDelimited_1 finally ] stop
				 */

				/**
				 * [tLogRow_2 finally ] start
				 */

				currentComponent = "tLogRow_2";

				/**
				 * [tLogRow_2 finally ] stop
				 */

				/**
				 * [tAdvancedHash_row2 finally ] start
				 */

				currentComponent = "tAdvancedHash_row2";

				/**
				 * [tAdvancedHash_row2 finally ] stop
				 */

			} catch (java.lang.Exception e) {
				// ignore
			} catch (java.lang.Error error) {
				// ignore
			}
			resourceMap = null;
		}

		globalMap.put("tFileInputDelimited_1_SUBPROCESS_STATE", 1);
	}

	public static class row6Struct implements routines.system.IPersistableComparableLookupRow<row6Struct> {
		final static byte[] commonByteArrayLock_MYFIRSTJOB_TP_MAJ = new byte[0];
		static byte[] commonByteArray_MYFIRSTJOB_TP_MAJ = new byte[0];
		protected static final int DEFAULT_HASHCODE = 1;
		protected static final int PRIME = 31;
		protected int hashCode = DEFAULT_HASHCODE;
		public boolean hashCodeDirty = true;

		public String loopKey;

		public String title;

		public String getTitle() {
			return this.title;
		}

		public Float popularity;

		public Float getPopularity() {
			return this.popularity;
		}

		public Integer vote_count;

		public Integer getVote_count() {
			return this.vote_count;
		}

		public Float vote_average;

		public Float getVote_average() {
			return this.vote_average;
		}

		@Override
		public int hashCode() {
			if (this.hashCodeDirty) {
				final int prime = PRIME;
				int result = DEFAULT_HASHCODE;

				result = prime * result + ((this.title == null) ? 0 : this.title.hashCode());

				this.hashCode = result;
				this.hashCodeDirty = false;
			}
			return this.hashCode;
		}

		@Override
		public boolean equals(Object obj) {
			if (this == obj)
				return true;
			if (obj == null)
				return false;
			if (getClass() != obj.getClass())
				return false;
			final row6Struct other = (row6Struct) obj;

			if (this.title == null) {
				if (other.title != null)
					return false;

			} else if (!this.title.equals(other.title))

				return false;

			return true;
		}

		public void copyDataTo(row6Struct other) {

			other.title = this.title;
			other.popularity = this.popularity;
			other.vote_count = this.vote_count;
			other.vote_average = this.vote_average;

		}

		public void copyKeysDataTo(row6Struct other) {

			other.title = this.title;

		}

		private String readString(ObjectInputStream dis) throws IOException {
			String strReturn = null;
			int length = 0;
			length = dis.readInt();
			if (length == -1) {
				strReturn = null;
			} else {
				if (length > commonByteArray_MYFIRSTJOB_TP_MAJ.length) {
					if (length < 1024 && commonByteArray_MYFIRSTJOB_TP_MAJ.length == 0) {
						commonByteArray_MYFIRSTJOB_TP_MAJ = new byte[1024];
					} else {
						commonByteArray_MYFIRSTJOB_TP_MAJ = new byte[2 * length];
					}
				}
				dis.readFully(commonByteArray_MYFIRSTJOB_TP_MAJ, 0, length);
				strReturn = new String(commonByteArray_MYFIRSTJOB_TP_MAJ, 0, length, utf8Charset);
			}
			return strReturn;
		}

		private String readString(org.jboss.marshalling.Unmarshaller unmarshaller) throws IOException {
			String strReturn = null;
			int length = 0;
			length = unmarshaller.readInt();
			if (length == -1) {
				strReturn = null;
			} else {
				if (length > commonByteArray_MYFIRSTJOB_TP_MAJ.length) {
					if (length < 1024 && commonByteArray_MYFIRSTJOB_TP_MAJ.length == 0) {
						commonByteArray_MYFIRSTJOB_TP_MAJ = new byte[1024];
					} else {
						commonByteArray_MYFIRSTJOB_TP_MAJ = new byte[2 * length];
					}
				}
				unmarshaller.readFully(commonByteArray_MYFIRSTJOB_TP_MAJ, 0, length);
				strReturn = new String(commonByteArray_MYFIRSTJOB_TP_MAJ, 0, length, utf8Charset);
			}
			return strReturn;
		}

		private void writeString(String str, ObjectOutputStream dos) throws IOException {
			if (str == null) {
				dos.writeInt(-1);
			} else {
				byte[] byteArray = str.getBytes(utf8Charset);
				dos.writeInt(byteArray.length);
				dos.write(byteArray);
			}
		}

		private void writeString(String str, org.jboss.marshalling.Marshaller marshaller) throws IOException {
			if (str == null) {
				marshaller.writeInt(-1);
			} else {
				byte[] byteArray = str.getBytes(utf8Charset);
				marshaller.writeInt(byteArray.length);
				marshaller.write(byteArray);
			}
		}

		private Integer readInteger(DataInputStream dis, ObjectInputStream ois) throws IOException {
			Integer intReturn;
			int length = 0;
			length = dis.readByte();
			if (length == -1) {
				intReturn = null;
			} else {
				intReturn = dis.readInt();
			}
			return intReturn;
		}

		private Integer readInteger(DataInputStream dis, org.jboss.marshalling.Unmarshaller unmarshaller)
				throws IOException {
			Integer intReturn;
			int length = 0;
			length = unmarshaller.readByte();
			if (length == -1) {
				intReturn = null;
			} else {
				intReturn = unmarshaller.readInt();
			}
			return intReturn;
		}

		private void writeInteger(Integer intNum, DataOutputStream dos, ObjectOutputStream oos) throws IOException {
			if (intNum == null) {
				dos.writeByte(-1);
			} else {
				dos.writeByte(0);
				dos.writeInt(intNum);
			}
		}

		private void writeInteger(Integer intNum, DataOutputStream dos, org.jboss.marshalling.Marshaller marshaller)
				throws IOException {
			if (intNum == null) {
				marshaller.writeByte(-1);
			} else {
				marshaller.writeByte(0);
				marshaller.writeInt(intNum);
			}
		}

		public void readKeysData(ObjectInputStream dis) {

			synchronized (commonByteArrayLock_MYFIRSTJOB_TP_MAJ) {

				try {

					int length = 0;

					this.title = readString(dis);

				} catch (IOException e) {
					throw new RuntimeException(e);

				}

			}

		}

		public void readKeysData(org.jboss.marshalling.Unmarshaller dis) {

			synchronized (commonByteArrayLock_MYFIRSTJOB_TP_MAJ) {

				try {

					int length = 0;

					this.title = readString(dis);

				} catch (IOException e) {
					throw new RuntimeException(e);

				}

			}

		}

		public void writeKeysData(ObjectOutputStream dos) {
			try {

				// String

				writeString(this.title, dos);

			} catch (IOException e) {
				throw new RuntimeException(e);
			}

		}

		public void writeKeysData(org.jboss.marshalling.Marshaller dos) {
			try {

				// String

				writeString(this.title, dos);

			} catch (IOException e) {
				throw new RuntimeException(e);
			}

		}

		/**
		 * Fill Values data by reading ObjectInputStream.
		 */
		public void readValuesData(DataInputStream dis, ObjectInputStream ois) {
			try {

				int length = 0;

				length = dis.readByte();
				if (length == -1) {
					this.popularity = null;
				} else {
					this.popularity = dis.readFloat();
				}

				this.vote_count = readInteger(dis, ois);

				length = dis.readByte();
				if (length == -1) {
					this.vote_average = null;
				} else {
					this.vote_average = dis.readFloat();
				}

			} catch (IOException e) {
				throw new RuntimeException(e);

			}

		}

		public void readValuesData(DataInputStream dis, org.jboss.marshalling.Unmarshaller objectIn) {
			try {
				int length = 0;

				length = objectIn.readByte();
				if (length == -1) {
					this.popularity = null;
				} else {
					this.popularity = objectIn.readFloat();
				}

				this.vote_count = readInteger(dis, objectIn);

				length = objectIn.readByte();
				if (length == -1) {
					this.vote_average = null;
				} else {
					this.vote_average = objectIn.readFloat();
				}

			} catch (IOException e) {
				throw new RuntimeException(e);

			}

		}

		/**
		 * Return a byte array which represents Values data.
		 */
		public void writeValuesData(DataOutputStream dos, ObjectOutputStream oos) {
			try {

				if (this.popularity == null) {
					dos.writeByte(-1);
				} else {
					dos.writeByte(0);
					dos.writeFloat(this.popularity);
				}

				writeInteger(this.vote_count, dos, oos);

				if (this.vote_average == null) {
					dos.writeByte(-1);
				} else {
					dos.writeByte(0);
					dos.writeFloat(this.vote_average);
				}

			} catch (IOException e) {
				throw new RuntimeException(e);
			}

		}

		public void writeValuesData(DataOutputStream dos, org.jboss.marshalling.Marshaller objectOut) {
			try {

				if (this.popularity == null) {
					objectOut.writeByte(-1);
				} else {
					objectOut.writeByte(0);
					objectOut.writeFloat(this.popularity);
				}

				writeInteger(this.vote_count, dos, objectOut);

				if (this.vote_average == null) {
					objectOut.writeByte(-1);
				} else {
					objectOut.writeByte(0);
					objectOut.writeFloat(this.vote_average);
				}

			} catch (IOException e) {
				throw new RuntimeException(e);
			}
		}

		public boolean supportMarshaller() {
			return true;
		}

		public String toString() {

			StringBuilder sb = new StringBuilder();
			sb.append(super.toString());
			sb.append("[");
			sb.append("title=" + title);
			sb.append(",popularity=" + String.valueOf(popularity));
			sb.append(",vote_count=" + String.valueOf(vote_count));
			sb.append(",vote_average=" + String.valueOf(vote_average));
			sb.append("]");

			return sb.toString();
		}

		/**
		 * Compare keys
		 */
		public int compareTo(row6Struct other) {

			int returnValue = -1;

			returnValue = checkNullsAndCompare(this.title, other.title);
			if (returnValue != 0) {
				return returnValue;
			}

			return returnValue;
		}

		private int checkNullsAndCompare(Object object1, Object object2) {
			int returnValue = 0;
			if (object1 instanceof Comparable && object2 instanceof Comparable) {
				returnValue = ((Comparable) object1).compareTo(object2);
			} else if (object1 != null && object2 != null) {
				returnValue = compareStrings(object1.toString(), object2.toString());
			} else if (object1 == null && object2 != null) {
				returnValue = 1;
			} else if (object1 != null && object2 == null) {
				returnValue = -1;
			} else {
				returnValue = 0;
			}

			return returnValue;
		}

		private int compareStrings(String string1, String string2) {
			return string1.compareTo(string2);
		}

	}

	public static class row4Struct implements routines.system.IPersistableRow<row4Struct> {
		final static byte[] commonByteArrayLock_MYFIRSTJOB_TP_MAJ = new byte[0];
		static byte[] commonByteArray_MYFIRSTJOB_TP_MAJ = new byte[0];
		protected static final int DEFAULT_HASHCODE = 1;
		protected static final int PRIME = 31;
		protected int hashCode = DEFAULT_HASHCODE;
		public boolean hashCodeDirty = true;

		public String loopKey;

		public String title;

		public String getTitle() {
			return this.title;
		}

		public Float popularity;

		public Float getPopularity() {
			return this.popularity;
		}

		public Integer vote_count;

		public Integer getVote_count() {
			return this.vote_count;
		}

		public Float vote_average;

		public Float getVote_average() {
			return this.vote_average;
		}

		@Override
		public int hashCode() {
			if (this.hashCodeDirty) {
				final int prime = PRIME;
				int result = DEFAULT_HASHCODE;

				result = prime * result + ((this.title == null) ? 0 : this.title.hashCode());

				this.hashCode = result;
				this.hashCodeDirty = false;
			}
			return this.hashCode;
		}

		@Override
		public boolean equals(Object obj) {
			if (this == obj)
				return true;
			if (obj == null)
				return false;
			if (getClass() != obj.getClass())
				return false;
			final row4Struct other = (row4Struct) obj;

			if (this.title == null) {
				if (other.title != null)
					return false;

			} else if (!this.title.equals(other.title))

				return false;

			return true;
		}

		public void copyDataTo(row4Struct other) {

			other.title = this.title;
			other.popularity = this.popularity;
			other.vote_count = this.vote_count;
			other.vote_average = this.vote_average;

		}

		public void copyKeysDataTo(row4Struct other) {

			other.title = this.title;

		}

		private String readString(ObjectInputStream dis) throws IOException {
			String strReturn = null;
			int length = 0;
			length = dis.readInt();
			if (length == -1) {
				strReturn = null;
			} else {
				if (length > commonByteArray_MYFIRSTJOB_TP_MAJ.length) {
					if (length < 1024 && commonByteArray_MYFIRSTJOB_TP_MAJ.length == 0) {
						commonByteArray_MYFIRSTJOB_TP_MAJ = new byte[1024];
					} else {
						commonByteArray_MYFIRSTJOB_TP_MAJ = new byte[2 * length];
					}
				}
				dis.readFully(commonByteArray_MYFIRSTJOB_TP_MAJ, 0, length);
				strReturn = new String(commonByteArray_MYFIRSTJOB_TP_MAJ, 0, length, utf8Charset);
			}
			return strReturn;
		}

		private String readString(org.jboss.marshalling.Unmarshaller unmarshaller) throws IOException {
			String strReturn = null;
			int length = 0;
			length = unmarshaller.readInt();
			if (length == -1) {
				strReturn = null;
			} else {
				if (length > commonByteArray_MYFIRSTJOB_TP_MAJ.length) {
					if (length < 1024 && commonByteArray_MYFIRSTJOB_TP_MAJ.length == 0) {
						commonByteArray_MYFIRSTJOB_TP_MAJ = new byte[1024];
					} else {
						commonByteArray_MYFIRSTJOB_TP_MAJ = new byte[2 * length];
					}
				}
				unmarshaller.readFully(commonByteArray_MYFIRSTJOB_TP_MAJ, 0, length);
				strReturn = new String(commonByteArray_MYFIRSTJOB_TP_MAJ, 0, length, utf8Charset);
			}
			return strReturn;
		}

		private void writeString(String str, ObjectOutputStream dos) throws IOException {
			if (str == null) {
				dos.writeInt(-1);
			} else {
				byte[] byteArray = str.getBytes(utf8Charset);
				dos.writeInt(byteArray.length);
				dos.write(byteArray);
			}
		}

		private void writeString(String str, org.jboss.marshalling.Marshaller marshaller) throws IOException {
			if (str == null) {
				marshaller.writeInt(-1);
			} else {
				byte[] byteArray = str.getBytes(utf8Charset);
				marshaller.writeInt(byteArray.length);
				marshaller.write(byteArray);
			}
		}

		private Integer readInteger(ObjectInputStream dis) throws IOException {
			Integer intReturn;
			int length = 0;
			length = dis.readByte();
			if (length == -1) {
				intReturn = null;
			} else {
				intReturn = dis.readInt();
			}
			return intReturn;
		}

		private Integer readInteger(org.jboss.marshalling.Unmarshaller dis) throws IOException {
			Integer intReturn;
			int length = 0;
			length = dis.readByte();
			if (length == -1) {
				intReturn = null;
			} else {
				intReturn = dis.readInt();
			}
			return intReturn;
		}

		private void writeInteger(Integer intNum, ObjectOutputStream dos) throws IOException {
			if (intNum == null) {
				dos.writeByte(-1);
			} else {
				dos.writeByte(0);
				dos.writeInt(intNum);
			}
		}

		private void writeInteger(Integer intNum, org.jboss.marshalling.Marshaller marshaller) throws IOException {
			if (intNum == null) {
				marshaller.writeByte(-1);
			} else {
				marshaller.writeByte(0);
				marshaller.writeInt(intNum);
			}
		}

		public void readData(ObjectInputStream dis) {

			synchronized (commonByteArrayLock_MYFIRSTJOB_TP_MAJ) {

				try {

					int length = 0;

					this.title = readString(dis);

					length = dis.readByte();
					if (length == -1) {
						this.popularity = null;
					} else {
						this.popularity = dis.readFloat();
					}

					this.vote_count = readInteger(dis);

					length = dis.readByte();
					if (length == -1) {
						this.vote_average = null;
					} else {
						this.vote_average = dis.readFloat();
					}

				} catch (IOException e) {
					throw new RuntimeException(e);

				}

			}

		}

		public void readData(org.jboss.marshalling.Unmarshaller dis) {

			synchronized (commonByteArrayLock_MYFIRSTJOB_TP_MAJ) {

				try {

					int length = 0;

					this.title = readString(dis);

					length = dis.readByte();
					if (length == -1) {
						this.popularity = null;
					} else {
						this.popularity = dis.readFloat();
					}

					this.vote_count = readInteger(dis);

					length = dis.readByte();
					if (length == -1) {
						this.vote_average = null;
					} else {
						this.vote_average = dis.readFloat();
					}

				} catch (IOException e) {
					throw new RuntimeException(e);

				}

			}

		}

		public void writeData(ObjectOutputStream dos) {
			try {

				// String

				writeString(this.title, dos);

				// Float

				if (this.popularity == null) {
					dos.writeByte(-1);
				} else {
					dos.writeByte(0);
					dos.writeFloat(this.popularity);
				}

				// Integer

				writeInteger(this.vote_count, dos);

				// Float

				if (this.vote_average == null) {
					dos.writeByte(-1);
				} else {
					dos.writeByte(0);
					dos.writeFloat(this.vote_average);
				}

			} catch (IOException e) {
				throw new RuntimeException(e);
			}

		}

		public void writeData(org.jboss.marshalling.Marshaller dos) {
			try {

				// String

				writeString(this.title, dos);

				// Float

				if (this.popularity == null) {
					dos.writeByte(-1);
				} else {
					dos.writeByte(0);
					dos.writeFloat(this.popularity);
				}

				// Integer

				writeInteger(this.vote_count, dos);

				// Float

				if (this.vote_average == null) {
					dos.writeByte(-1);
				} else {
					dos.writeByte(0);
					dos.writeFloat(this.vote_average);
				}

			} catch (IOException e) {
				throw new RuntimeException(e);
			}

		}

		public String toString() {

			StringBuilder sb = new StringBuilder();
			sb.append(super.toString());
			sb.append("[");
			sb.append("title=" + title);
			sb.append(",popularity=" + String.valueOf(popularity));
			sb.append(",vote_count=" + String.valueOf(vote_count));
			sb.append(",vote_average=" + String.valueOf(vote_average));
			sb.append("]");

			return sb.toString();
		}

		/**
		 * Compare keys
		 */
		public int compareTo(row4Struct other) {

			int returnValue = -1;

			returnValue = checkNullsAndCompare(this.title, other.title);
			if (returnValue != 0) {
				return returnValue;
			}

			return returnValue;
		}

		private int checkNullsAndCompare(Object object1, Object object2) {
			int returnValue = 0;
			if (object1 instanceof Comparable && object2 instanceof Comparable) {
				returnValue = ((Comparable) object1).compareTo(object2);
			} else if (object1 != null && object2 != null) {
				returnValue = compareStrings(object1.toString(), object2.toString());
			} else if (object1 == null && object2 != null) {
				returnValue = 1;
			} else if (object1 != null && object2 == null) {
				returnValue = -1;
			} else {
				returnValue = 0;
			}

			return returnValue;
		}

		private int compareStrings(String string1, String string2) {
			return string1.compareTo(string2);
		}

	}

	public void tFileInputXML_1Process(final java.util.Map<String, Object> globalMap) throws TalendException {
		globalMap.put("tFileInputXML_1_SUBPROCESS_STATE", 0);

		final boolean execStat = this.execStat;

		String iterateId = "";

		String currentComponent = "";
		java.util.Map<String, Object> resourceMap = new java.util.HashMap<String, Object>();

		try {
			// TDI-39566 avoid throwing an useless Exception
			boolean resumeIt = true;
			if (globalResumeTicket == false && resumeEntryMethodName != null) {
				String currentMethodName = new java.lang.Exception().getStackTrace()[0].getMethodName();
				resumeIt = resumeEntryMethodName.equals(currentMethodName);
			}
			if (resumeIt || globalResumeTicket) { // start the resume
				globalResumeTicket = true;

				row4Struct row4 = new row4Struct();
				row4Struct row6 = row4;

				/**
				 * [tAdvancedHash_row6 begin ] start
				 */

				ok_Hash.put("tAdvancedHash_row6", false);
				start_Hash.put("tAdvancedHash_row6", System.currentTimeMillis());

				currentComponent = "tAdvancedHash_row6";

				if (execStat) {
					runStat.updateStatOnConnection(resourceMap, iterateId, 0, 0, "row6");
				}

				int tos_count_tAdvancedHash_row6 = 0;

				// connection name:row6
				// source node:tLogRow_3 - inputs:(row4) outputs:(row6,row6) | target
				// node:tAdvancedHash_row6 - inputs:(row6) outputs:()
				// linked node: tMap_1 - inputs:(row7,row2,row6) outputs:(movieJoint)

				org.talend.designer.components.lookup.common.ICommonLookup.MATCHING_MODE matchingModeEnum_row6 = org.talend.designer.components.lookup.common.ICommonLookup.MATCHING_MODE.UNIQUE_MATCH;

				org.talend.designer.components.lookup.memory.AdvancedMemoryLookup<row6Struct> tHash_Lookup_row6 = org.talend.designer.components.lookup.memory.AdvancedMemoryLookup
						.<row6Struct>getLookup(matchingModeEnum_row6);

				globalMap.put("tHash_Lookup_row6", tHash_Lookup_row6);

				/**
				 * [tAdvancedHash_row6 begin ] stop
				 */

				/**
				 * [tLogRow_3 begin ] start
				 */

				ok_Hash.put("tLogRow_3", false);
				start_Hash.put("tLogRow_3", System.currentTimeMillis());

				currentComponent = "tLogRow_3";

				if (execStat) {
					runStat.updateStatOnConnection(resourceMap, iterateId, 0, 0, "row4");
				}

				int tos_count_tLogRow_3 = 0;

				///////////////////////

				class Util_tLogRow_3 {

					String[] des_top = { ".", ".", "-", "+" };

					String[] des_head = { "|=", "=|", "-", "+" };

					String[] des_bottom = { "'", "'", "-", "+" };

					String name = "";

					java.util.List<String[]> list = new java.util.ArrayList<String[]>();

					int[] colLengths = new int[4];

					public void addRow(String[] row) {

						for (int i = 0; i < 4; i++) {
							if (row[i] != null) {
								colLengths[i] = Math.max(colLengths[i], row[i].length());
							}
						}
						list.add(row);
					}

					public void setTableName(String name) {

						this.name = name;
					}

					public StringBuilder format() {

						StringBuilder sb = new StringBuilder();

						sb.append(print(des_top));

						int totals = 0;
						for (int i = 0; i < colLengths.length; i++) {
							totals = totals + colLengths[i];
						}

						// name
						sb.append("|");
						int k = 0;
						for (k = 0; k < (totals + 3 - name.length()) / 2; k++) {
							sb.append(' ');
						}
						sb.append(name);
						for (int i = 0; i < totals + 3 - name.length() - k; i++) {
							sb.append(' ');
						}
						sb.append("|\n");

						// head and rows
						sb.append(print(des_head));
						for (int i = 0; i < list.size(); i++) {

							String[] row = list.get(i);

							java.util.Formatter formatter = new java.util.Formatter(new StringBuilder());

							StringBuilder sbformat = new StringBuilder();
							sbformat.append("|%1$-");
							sbformat.append(colLengths[0]);
							sbformat.append("s");

							sbformat.append("|%2$-");
							sbformat.append(colLengths[1]);
							sbformat.append("s");

							sbformat.append("|%3$-");
							sbformat.append(colLengths[2]);
							sbformat.append("s");

							sbformat.append("|%4$-");
							sbformat.append(colLengths[3]);
							sbformat.append("s");

							sbformat.append("|\n");

							formatter.format(sbformat.toString(), (Object[]) row);

							sb.append(formatter.toString());
							if (i == 0)
								sb.append(print(des_head)); // print the head
						}

						// end
						sb.append(print(des_bottom));
						return sb;
					}

					private StringBuilder print(String[] fillChars) {
						StringBuilder sb = new StringBuilder();
						// first column
						sb.append(fillChars[0]);
						for (int i = 0; i < colLengths[0] - fillChars[0].length() + 1; i++) {
							sb.append(fillChars[2]);
						}
						sb.append(fillChars[3]);

						for (int i = 0; i < colLengths[1] - fillChars[3].length() + 1; i++) {
							sb.append(fillChars[2]);
						}
						sb.append(fillChars[3]);
						for (int i = 0; i < colLengths[2] - fillChars[3].length() + 1; i++) {
							sb.append(fillChars[2]);
						}
						sb.append(fillChars[3]);

						// last column
						for (int i = 0; i < colLengths[3] - fillChars[1].length() + 1; i++) {
							sb.append(fillChars[2]);
						}
						sb.append(fillChars[1]);
						sb.append("\n");
						return sb;
					}

					public boolean isTableEmpty() {
						if (list.size() > 1)
							return false;
						return true;
					}
				}
				Util_tLogRow_3 util_tLogRow_3 = new Util_tLogRow_3();
				util_tLogRow_3.setTableName("logRatings");
				util_tLogRow_3.addRow(new String[] { "title", "popularity", "vote_count", "vote_average", });
				StringBuilder strBuffer_tLogRow_3 = null;
				int nb_line_tLogRow_3 = 0;
///////////////////////    			

				/**
				 * [tLogRow_3 begin ] stop
				 */

				/**
				 * [tFileInputXML_1 begin ] start
				 */

				ok_Hash.put("tFileInputXML_1", false);
				start_Hash.put("tFileInputXML_1", System.currentTimeMillis());

				currentComponent = "tFileInputXML_1";

				int tos_count_tFileInputXML_1 = 0;

				int nb_line_tFileInputXML_1 = 0;

				String os_tFileInputXML_1 = System.getProperty("os.name").toLowerCase();
				boolean isWindows_tFileInputXML_1 = false;
				if (os_tFileInputXML_1.indexOf("windows") > -1 || os_tFileInputXML_1.indexOf("nt") > -1) {
					isWindows_tFileInputXML_1 = true;
				}
				class NameSpaceTool_tFileInputXML_1 {

					public java.util.HashMap<String, String> xmlNameSpaceMap = new java.util.HashMap<String, String>();

					private java.util.List<String> defualtNSPath = new java.util.ArrayList<String>();

					public void countNSMap(org.dom4j.Element el) {
						for (org.dom4j.Namespace ns : (java.util.List<org.dom4j.Namespace>) el.declaredNamespaces()) {
							if (ns.getPrefix().trim().length() == 0) {
								xmlNameSpaceMap.put("pre" + defualtNSPath.size(), ns.getURI());
								String path = "";
								org.dom4j.Element elTmp = el;
								while (elTmp != null) {
									if (elTmp.getNamespacePrefix() != null && elTmp.getNamespacePrefix().length() > 0) {
										path = "/" + elTmp.getNamespacePrefix() + ":" + elTmp.getName() + path;
									} else {
										path = "/" + elTmp.getName() + path;
									}
									elTmp = elTmp.getParent();
								}
								defualtNSPath.add(path);
							} else {
								xmlNameSpaceMap.put(ns.getPrefix(), ns.getURI());
							}

						}
						for (org.dom4j.Element e : (java.util.List<org.dom4j.Element>) el.elements()) {
							countNSMap(e);
						}
					}

					private final org.talend.xpath.XPathUtil util = new org.talend.xpath.XPathUtil();

					{
						util.setDefaultNSPath(defualtNSPath);
					}

					public String addDefaultNSPrefix(String path) {
						return util.addDefaultNSPrefix(path);
					}

					public String addDefaultNSPrefix(String relativeXpression, String basePath) {
						return util.addDefaultNSPrefix(relativeXpression, basePath);
					}

				}

				class XML_API_tFileInputXML_1 {
					public boolean isDefNull(org.dom4j.Node node) throws javax.xml.transform.TransformerException {
						if (node != null && node instanceof org.dom4j.Element) {
							org.dom4j.Attribute attri = ((org.dom4j.Element) node).attribute("nil");
							if (attri != null && ("true").equals(attri.getText())) {
								return true;
							}
						}
						return false;
					}

					public boolean isMissing(org.dom4j.Node node) throws javax.xml.transform.TransformerException {
						return node == null ? true : false;
					}

					public boolean isEmpty(org.dom4j.Node node) throws javax.xml.transform.TransformerException {
						if (node != null) {
							return node.getText().length() == 0;
						}
						return false;
					}
				}

				org.dom4j.io.SAXReader reader_tFileInputXML_1 = new org.dom4j.io.SAXReader();
				Object filename_tFileInputXML_1 = null;
				try {
					filename_tFileInputXML_1 = "C:/Users/ananf/OneDrive/Documents/Aivancity/DATA pipeline/moviesRatings.xml";
				} catch (java.lang.Exception e) {
					globalMap.put("tFileInputXML_1_ERROR_MESSAGE", e.getMessage());

					System.err.println(e.getMessage());

				}
				if (filename_tFileInputXML_1 != null && filename_tFileInputXML_1 instanceof String
						&& filename_tFileInputXML_1.toString().startsWith("//")) {
					if (!isWindows_tFileInputXML_1) {
						filename_tFileInputXML_1 = filename_tFileInputXML_1.toString().replaceFirst("//", "/");
					}
				}

				boolean isValidFile_tFileInputXML_1 = true;
				org.dom4j.Document doc_tFileInputXML_1 = null;
				java.io.Closeable toClose_tFileInputXML_1 = null;
				try {
					if (filename_tFileInputXML_1 instanceof java.io.InputStream) {
						java.io.InputStream inputStream_tFileInputXML_1 = (java.io.InputStream) filename_tFileInputXML_1;
						toClose_tFileInputXML_1 = inputStream_tFileInputXML_1;
						doc_tFileInputXML_1 = reader_tFileInputXML_1.read(inputStream_tFileInputXML_1);
					} else {
						java.io.Reader unicodeReader_tFileInputXML_1 = new UnicodeReader(
								new java.io.FileInputStream(String.valueOf(filename_tFileInputXML_1)), "ISO-8859-15");
						toClose_tFileInputXML_1 = unicodeReader_tFileInputXML_1;
						org.xml.sax.InputSource in_tFileInputXML_1 = new org.xml.sax.InputSource(
								unicodeReader_tFileInputXML_1);
						doc_tFileInputXML_1 = reader_tFileInputXML_1.read(in_tFileInputXML_1);
					}
				} catch (java.lang.Exception e) {
					globalMap.put("tFileInputXML_1_ERROR_MESSAGE", e.getMessage());

					System.err.println(e.getMessage());
					isValidFile_tFileInputXML_1 = false;
				} finally {
					if (toClose_tFileInputXML_1 != null) {
						toClose_tFileInputXML_1.close();
					}
				}
				if (isValidFile_tFileInputXML_1) {
					NameSpaceTool_tFileInputXML_1 nsTool_tFileInputXML_1 = new NameSpaceTool_tFileInputXML_1();
					nsTool_tFileInputXML_1.countNSMap(doc_tFileInputXML_1.getRootElement());
					java.util.HashMap<String, String> xmlNameSpaceMap_tFileInputXML_1 = nsTool_tFileInputXML_1.xmlNameSpaceMap;

					org.dom4j.XPath x_tFileInputXML_1 = doc_tFileInputXML_1
							.createXPath(nsTool_tFileInputXML_1.addDefaultNSPrefix("/movies/movie"));
					x_tFileInputXML_1.setNamespaceURIs(xmlNameSpaceMap_tFileInputXML_1);

					java.util.List<org.dom4j.Node> nodeList_tFileInputXML_1 = (java.util.List<org.dom4j.Node>) x_tFileInputXML_1
							.selectNodes(doc_tFileInputXML_1);
					XML_API_tFileInputXML_1 xml_api_tFileInputXML_1 = new XML_API_tFileInputXML_1();
					String str_tFileInputXML_1 = "";
					org.dom4j.Node node_tFileInputXML_1 = null;

//init all mapping xpaths
					java.util.Map<Integer, org.dom4j.XPath> xpaths_tFileInputXML_1 = new java.util.HashMap<Integer, org.dom4j.XPath>();
					class XPathUtil_tFileInputXML_1 {

						public void initXPaths_0(java.util.Map<Integer, org.dom4j.XPath> xpaths,
								NameSpaceTool_tFileInputXML_1 nsTool,
								java.util.HashMap<String, String> xmlNameSpaceMap) {

							org.dom4j.XPath xpath_0 = org.dom4j.DocumentHelper
									.createXPath(nsTool.addDefaultNSPrefix("@title", "/movies/movie"));
							xpath_0.setNamespaceURIs(xmlNameSpaceMap);

							xpaths.put(0, xpath_0);

							org.dom4j.XPath xpath_1 = org.dom4j.DocumentHelper
									.createXPath(nsTool.addDefaultNSPrefix("@popularity", "/movies/movie"));
							xpath_1.setNamespaceURIs(xmlNameSpaceMap);

							xpaths.put(1, xpath_1);

							org.dom4j.XPath xpath_2 = org.dom4j.DocumentHelper
									.createXPath(nsTool.addDefaultNSPrefix("@vote_count", "/movies/movie"));
							xpath_2.setNamespaceURIs(xmlNameSpaceMap);

							xpaths.put(2, xpath_2);

							org.dom4j.XPath xpath_3 = org.dom4j.DocumentHelper
									.createXPath(nsTool.addDefaultNSPrefix("@vote_average", "/movies/movie"));
							xpath_3.setNamespaceURIs(xmlNameSpaceMap);

							xpaths.put(3, xpath_3);

						}

						public void initXPaths(java.util.Map<Integer, org.dom4j.XPath> xpaths,
								NameSpaceTool_tFileInputXML_1 nsTool,
								java.util.HashMap<String, String> xmlNameSpaceMap) {

							initXPaths_0(xpaths, nsTool, xmlNameSpaceMap);

						}
					}
					XPathUtil_tFileInputXML_1 xPathUtil_tFileInputXML_1 = new XPathUtil_tFileInputXML_1();
					xPathUtil_tFileInputXML_1.initXPaths(xpaths_tFileInputXML_1, nsTool_tFileInputXML_1,
							xmlNameSpaceMap_tFileInputXML_1);
					for (org.dom4j.Node temp_tFileInputXML_1 : nodeList_tFileInputXML_1) {
						if (nb_line_tFileInputXML_1 >= 50) {

							break;
						}
						nb_line_tFileInputXML_1++;

						row4 = null;
						boolean whetherReject_tFileInputXML_1 = false;
						row4 = new row4Struct();
						try {
							Object obj0_tFileInputXML_1 = xpaths_tFileInputXML_1.get(0).evaluate(temp_tFileInputXML_1);
							if (obj0_tFileInputXML_1 == null) {
								node_tFileInputXML_1 = null;
								str_tFileInputXML_1 = "";

							} else if (obj0_tFileInputXML_1 instanceof org.dom4j.Node) {
								node_tFileInputXML_1 = (org.dom4j.Node) obj0_tFileInputXML_1;
								str_tFileInputXML_1 = org.jaxen.function.StringFunction.evaluate(node_tFileInputXML_1,
										org.jaxen.dom4j.DocumentNavigator.getInstance());
							} else if (obj0_tFileInputXML_1 instanceof String
									|| obj0_tFileInputXML_1 instanceof Number) {
								node_tFileInputXML_1 = temp_tFileInputXML_1;
								str_tFileInputXML_1 = String.valueOf(obj0_tFileInputXML_1);
							} else if (obj0_tFileInputXML_1 instanceof java.util.List) {
								java.util.List<org.dom4j.Node> nodes_tFileInputXML_1 = (java.util.List<org.dom4j.Node>) obj0_tFileInputXML_1;
								node_tFileInputXML_1 = nodes_tFileInputXML_1.size() > 0 ? nodes_tFileInputXML_1.get(0)
										: null;
								str_tFileInputXML_1 = node_tFileInputXML_1 == null ? ""
										: org.jaxen.function.StringFunction.evaluate(node_tFileInputXML_1,
												org.jaxen.dom4j.DocumentNavigator.getInstance());
							}
							if (xml_api_tFileInputXML_1.isDefNull(node_tFileInputXML_1)) {
								row4.title = null;
							} else if (xml_api_tFileInputXML_1.isEmpty(node_tFileInputXML_1)) {
								row4.title = "";
							} else if (xml_api_tFileInputXML_1.isMissing(node_tFileInputXML_1)) {
								row4.title = null;
							} else {
								row4.title = str_tFileInputXML_1;
							}
							Object obj1_tFileInputXML_1 = xpaths_tFileInputXML_1.get(1).evaluate(temp_tFileInputXML_1);
							if (obj1_tFileInputXML_1 == null) {
								node_tFileInputXML_1 = null;
								str_tFileInputXML_1 = "";

							} else if (obj1_tFileInputXML_1 instanceof org.dom4j.Node) {
								node_tFileInputXML_1 = (org.dom4j.Node) obj1_tFileInputXML_1;
								str_tFileInputXML_1 = org.jaxen.function.StringFunction.evaluate(node_tFileInputXML_1,
										org.jaxen.dom4j.DocumentNavigator.getInstance());
							} else if (obj1_tFileInputXML_1 instanceof String
									|| obj1_tFileInputXML_1 instanceof Number) {
								node_tFileInputXML_1 = temp_tFileInputXML_1;
								str_tFileInputXML_1 = String.valueOf(obj1_tFileInputXML_1);
							} else if (obj1_tFileInputXML_1 instanceof java.util.List) {
								java.util.List<org.dom4j.Node> nodes_tFileInputXML_1 = (java.util.List<org.dom4j.Node>) obj1_tFileInputXML_1;
								node_tFileInputXML_1 = nodes_tFileInputXML_1.size() > 0 ? nodes_tFileInputXML_1.get(0)
										: null;
								str_tFileInputXML_1 = node_tFileInputXML_1 == null ? ""
										: org.jaxen.function.StringFunction.evaluate(node_tFileInputXML_1,
												org.jaxen.dom4j.DocumentNavigator.getInstance());
							}
							if (xml_api_tFileInputXML_1.isDefNull(node_tFileInputXML_1)) {
								row4.popularity = null;
							} else if (xml_api_tFileInputXML_1.isEmpty(node_tFileInputXML_1)
									|| xml_api_tFileInputXML_1.isMissing(node_tFileInputXML_1)) {
								row4.popularity = null;
							} else {
								row4.popularity = ParserUtils.parseTo_Float(str_tFileInputXML_1);
							}
							Object obj2_tFileInputXML_1 = xpaths_tFileInputXML_1.get(2).evaluate(temp_tFileInputXML_1);
							if (obj2_tFileInputXML_1 == null) {
								node_tFileInputXML_1 = null;
								str_tFileInputXML_1 = "";

							} else if (obj2_tFileInputXML_1 instanceof org.dom4j.Node) {
								node_tFileInputXML_1 = (org.dom4j.Node) obj2_tFileInputXML_1;
								str_tFileInputXML_1 = org.jaxen.function.StringFunction.evaluate(node_tFileInputXML_1,
										org.jaxen.dom4j.DocumentNavigator.getInstance());
							} else if (obj2_tFileInputXML_1 instanceof String
									|| obj2_tFileInputXML_1 instanceof Number) {
								node_tFileInputXML_1 = temp_tFileInputXML_1;
								str_tFileInputXML_1 = String.valueOf(obj2_tFileInputXML_1);
							} else if (obj2_tFileInputXML_1 instanceof java.util.List) {
								java.util.List<org.dom4j.Node> nodes_tFileInputXML_1 = (java.util.List<org.dom4j.Node>) obj2_tFileInputXML_1;
								node_tFileInputXML_1 = nodes_tFileInputXML_1.size() > 0 ? nodes_tFileInputXML_1.get(0)
										: null;
								str_tFileInputXML_1 = node_tFileInputXML_1 == null ? ""
										: org.jaxen.function.StringFunction.evaluate(node_tFileInputXML_1,
												org.jaxen.dom4j.DocumentNavigator.getInstance());
							}
							if (xml_api_tFileInputXML_1.isDefNull(node_tFileInputXML_1)) {
								row4.vote_count = null;
							} else if (xml_api_tFileInputXML_1.isEmpty(node_tFileInputXML_1)
									|| xml_api_tFileInputXML_1.isMissing(node_tFileInputXML_1)) {
								row4.vote_count = null;
							} else {
								row4.vote_count = ParserUtils.parseTo_Integer(str_tFileInputXML_1);
							}
							Object obj3_tFileInputXML_1 = xpaths_tFileInputXML_1.get(3).evaluate(temp_tFileInputXML_1);
							if (obj3_tFileInputXML_1 == null) {
								node_tFileInputXML_1 = null;
								str_tFileInputXML_1 = "";

							} else if (obj3_tFileInputXML_1 instanceof org.dom4j.Node) {
								node_tFileInputXML_1 = (org.dom4j.Node) obj3_tFileInputXML_1;
								str_tFileInputXML_1 = org.jaxen.function.StringFunction.evaluate(node_tFileInputXML_1,
										org.jaxen.dom4j.DocumentNavigator.getInstance());
							} else if (obj3_tFileInputXML_1 instanceof String
									|| obj3_tFileInputXML_1 instanceof Number) {
								node_tFileInputXML_1 = temp_tFileInputXML_1;
								str_tFileInputXML_1 = String.valueOf(obj3_tFileInputXML_1);
							} else if (obj3_tFileInputXML_1 instanceof java.util.List) {
								java.util.List<org.dom4j.Node> nodes_tFileInputXML_1 = (java.util.List<org.dom4j.Node>) obj3_tFileInputXML_1;
								node_tFileInputXML_1 = nodes_tFileInputXML_1.size() > 0 ? nodes_tFileInputXML_1.get(0)
										: null;
								str_tFileInputXML_1 = node_tFileInputXML_1 == null ? ""
										: org.jaxen.function.StringFunction.evaluate(node_tFileInputXML_1,
												org.jaxen.dom4j.DocumentNavigator.getInstance());
							}
							if (xml_api_tFileInputXML_1.isDefNull(node_tFileInputXML_1)) {
								row4.vote_average = null;
							} else if (xml_api_tFileInputXML_1.isEmpty(node_tFileInputXML_1)
									|| xml_api_tFileInputXML_1.isMissing(node_tFileInputXML_1)) {
								row4.vote_average = null;
							} else {
								row4.vote_average = ParserUtils.parseTo_Float(str_tFileInputXML_1);
							}

						} catch (java.lang.Exception e) {
							globalMap.put("tFileInputXML_1_ERROR_MESSAGE", e.getMessage());
							whetherReject_tFileInputXML_1 = true;
							System.err.println(e.getMessage());
							row4 = null;
						}

						/**
						 * [tFileInputXML_1 begin ] stop
						 */

						/**
						 * [tFileInputXML_1 main ] start
						 */

						currentComponent = "tFileInputXML_1";

						tos_count_tFileInputXML_1++;

						/**
						 * [tFileInputXML_1 main ] stop
						 */

						/**
						 * [tFileInputXML_1 process_data_begin ] start
						 */

						currentComponent = "tFileInputXML_1";

						/**
						 * [tFileInputXML_1 process_data_begin ] stop
						 */
// Start of branch "row4"
						if (row4 != null) {

							/**
							 * [tLogRow_3 main ] start
							 */

							currentComponent = "tLogRow_3";

							if (execStat) {
								runStat.updateStatOnConnection(iterateId, 1, 1

										, "row4"

								);
							}

///////////////////////		

							String[] row_tLogRow_3 = new String[4];

							if (row4.title != null) { //
								row_tLogRow_3[0] = String.valueOf(row4.title);

							} //

							if (row4.popularity != null) { //
								row_tLogRow_3[1] = FormatterUtils.formatUnwithE(row4.popularity);

							} //

							if (row4.vote_count != null) { //
								row_tLogRow_3[2] = String.valueOf(row4.vote_count);

							} //

							if (row4.vote_average != null) { //
								row_tLogRow_3[3] = FormatterUtils.formatUnwithE(row4.vote_average);

							} //

							util_tLogRow_3.addRow(row_tLogRow_3);
							nb_line_tLogRow_3++;
//////

//////                    

///////////////////////    			

							row6 = row4;

							tos_count_tLogRow_3++;

							/**
							 * [tLogRow_3 main ] stop
							 */

							/**
							 * [tLogRow_3 process_data_begin ] start
							 */

							currentComponent = "tLogRow_3";

							/**
							 * [tLogRow_3 process_data_begin ] stop
							 */

							/**
							 * [tAdvancedHash_row6 main ] start
							 */

							currentComponent = "tAdvancedHash_row6";

							if (execStat) {
								runStat.updateStatOnConnection(iterateId, 1, 1

										, "row6"

								);
							}

							row6Struct row6_HashRow = new row6Struct();

							row6_HashRow.title = row6.title;

							row6_HashRow.popularity = row6.popularity;

							row6_HashRow.vote_count = row6.vote_count;

							row6_HashRow.vote_average = row6.vote_average;

							tHash_Lookup_row6.put(row6_HashRow);

							tos_count_tAdvancedHash_row6++;

							/**
							 * [tAdvancedHash_row6 main ] stop
							 */

							/**
							 * [tAdvancedHash_row6 process_data_begin ] start
							 */

							currentComponent = "tAdvancedHash_row6";

							/**
							 * [tAdvancedHash_row6 process_data_begin ] stop
							 */

							/**
							 * [tAdvancedHash_row6 process_data_end ] start
							 */

							currentComponent = "tAdvancedHash_row6";

							/**
							 * [tAdvancedHash_row6 process_data_end ] stop
							 */

							/**
							 * [tLogRow_3 process_data_end ] start
							 */

							currentComponent = "tLogRow_3";

							/**
							 * [tLogRow_3 process_data_end ] stop
							 */

						} // End of branch "row4"

						/**
						 * [tFileInputXML_1 process_data_end ] start
						 */

						currentComponent = "tFileInputXML_1";

						/**
						 * [tFileInputXML_1 process_data_end ] stop
						 */

						/**
						 * [tFileInputXML_1 end ] start
						 */

						currentComponent = "tFileInputXML_1";

					}
				}
				globalMap.put("tFileInputXML_1_NB_LINE", nb_line_tFileInputXML_1);

				ok_Hash.put("tFileInputXML_1", true);
				end_Hash.put("tFileInputXML_1", System.currentTimeMillis());

				/**
				 * [tFileInputXML_1 end ] stop
				 */

				/**
				 * [tLogRow_3 end ] start
				 */

				currentComponent = "tLogRow_3";

//////

				java.io.PrintStream consoleOut_tLogRow_3 = null;
				if (globalMap.get("tLogRow_CONSOLE") != null) {
					consoleOut_tLogRow_3 = (java.io.PrintStream) globalMap.get("tLogRow_CONSOLE");
				} else {
					consoleOut_tLogRow_3 = new java.io.PrintStream(new java.io.BufferedOutputStream(System.out));
					globalMap.put("tLogRow_CONSOLE", consoleOut_tLogRow_3);
				}

				consoleOut_tLogRow_3.println(util_tLogRow_3.format().toString());
				consoleOut_tLogRow_3.flush();
//////
				globalMap.put("tLogRow_3_NB_LINE", nb_line_tLogRow_3);

///////////////////////    			

				if (execStat) {
					runStat.updateStat(resourceMap, iterateId, 2, 0, "row4");
				}

				ok_Hash.put("tLogRow_3", true);
				end_Hash.put("tLogRow_3", System.currentTimeMillis());

				/**
				 * [tLogRow_3 end ] stop
				 */

				/**
				 * [tAdvancedHash_row6 end ] start
				 */

				currentComponent = "tAdvancedHash_row6";

				tHash_Lookup_row6.endPut();

				if (execStat) {
					runStat.updateStat(resourceMap, iterateId, 2, 0, "row6");
				}

				ok_Hash.put("tAdvancedHash_row6", true);
				end_Hash.put("tAdvancedHash_row6", System.currentTimeMillis());

				/**
				 * [tAdvancedHash_row6 end ] stop
				 */

			} // end the resume

		} catch (java.lang.Exception e) {

			TalendException te = new TalendException(e, currentComponent, globalMap);

			throw te;
		} catch (java.lang.Error error) {

			runStat.stopThreadStat();

			throw error;
		} finally {

			try {

				/**
				 * [tFileInputXML_1 finally ] start
				 */

				currentComponent = "tFileInputXML_1";

				/**
				 * [tFileInputXML_1 finally ] stop
				 */

				/**
				 * [tLogRow_3 finally ] start
				 */

				currentComponent = "tLogRow_3";

				/**
				 * [tLogRow_3 finally ] stop
				 */

				/**
				 * [tAdvancedHash_row6 finally ] start
				 */

				currentComponent = "tAdvancedHash_row6";

				/**
				 * [tAdvancedHash_row6 finally ] stop
				 */

			} catch (java.lang.Exception e) {
				// ignore
			} catch (java.lang.Error error) {
				// ignore
			}
			resourceMap = null;
		}

		globalMap.put("tFileInputXML_1_SUBPROCESS_STATE", 1);
	}

	public void tMsgBox_1Process(final java.util.Map<String, Object> globalMap) throws TalendException {
		globalMap.put("tMsgBox_1_SUBPROCESS_STATE", 0);

		final boolean execStat = this.execStat;

		String iterateId = "";

		String currentComponent = "";
		java.util.Map<String, Object> resourceMap = new java.util.HashMap<String, Object>();

		try {
			// TDI-39566 avoid throwing an useless Exception
			boolean resumeIt = true;
			if (globalResumeTicket == false && resumeEntryMethodName != null) {
				String currentMethodName = new java.lang.Exception().getStackTrace()[0].getMethodName();
				resumeIt = resumeEntryMethodName.equals(currentMethodName);
			}
			if (resumeIt || globalResumeTicket) { // start the resume
				globalResumeTicket = true;

				/**
				 * [tMsgBox_1 begin ] start
				 */

				ok_Hash.put("tMsgBox_1", false);
				start_Hash.put("tMsgBox_1", System.currentTimeMillis());

				currentComponent = "tMsgBox_1";

				int tos_count_tMsgBox_1 = 0;

				/**
				 * [tMsgBox_1 begin ] stop
				 */

				/**
				 * [tMsgBox_1 main ] start
				 */

				currentComponent = "tMsgBox_1";

				int messageIcontMsgBox_1 = javax.swing.JOptionPane.INFORMATION_MESSAGE;
				String titletMsgBox_1 = "Programme";
				String messagetMsgBox_1 = "Debut du programme";
				String resulttMsgBox_1 = null;

				javax.swing.JOptionPane.showMessageDialog(null, messagetMsgBox_1, titletMsgBox_1, messageIcontMsgBox_1);
				resulttMsgBox_1 = String.valueOf(1);

				globalMap.put("tMsgBox_1_RESULT", resulttMsgBox_1);

				tos_count_tMsgBox_1++;

				/**
				 * [tMsgBox_1 main ] stop
				 */

				/**
				 * [tMsgBox_1 process_data_begin ] start
				 */

				currentComponent = "tMsgBox_1";

				/**
				 * [tMsgBox_1 process_data_begin ] stop
				 */

				/**
				 * [tMsgBox_1 process_data_end ] start
				 */

				currentComponent = "tMsgBox_1";

				/**
				 * [tMsgBox_1 process_data_end ] stop
				 */

				/**
				 * [tMsgBox_1 end ] start
				 */

				currentComponent = "tMsgBox_1";

				ok_Hash.put("tMsgBox_1", true);
				end_Hash.put("tMsgBox_1", System.currentTimeMillis());

				/**
				 * [tMsgBox_1 end ] stop
				 */
			} // end the resume

			if (resumeEntryMethodName == null || globalResumeTicket) {
				resumeUtil.addLog("CHECKPOINT", "CONNECTION:SUBJOB_OK:tMsgBox_1:OnSubjobOk", "",
						Thread.currentThread().getId() + "", "", "", "", "", "");
			}

			if (execStat) {
				runStat.updateStatOnConnection("OnSubjobOk1", 0, "ok");
			}

			tWarn_2Process(globalMap);

		} catch (java.lang.Exception e) {

			TalendException te = new TalendException(e, currentComponent, globalMap);

			throw te;
		} catch (java.lang.Error error) {

			runStat.stopThreadStat();

			throw error;
		} finally {

			try {

				/**
				 * [tMsgBox_1 finally ] start
				 */

				currentComponent = "tMsgBox_1";

				/**
				 * [tMsgBox_1 finally ] stop
				 */
			} catch (java.lang.Exception e) {
				// ignore
			} catch (java.lang.Error error) {
				// ignore
			}
			resourceMap = null;
		}

		globalMap.put("tMsgBox_1_SUBPROCESS_STATE", 1);
	}

	public void tWarn_2Process(final java.util.Map<String, Object> globalMap) throws TalendException {
		globalMap.put("tWarn_2_SUBPROCESS_STATE", 0);

		final boolean execStat = this.execStat;

		String iterateId = "";

		String currentComponent = "";
		java.util.Map<String, Object> resourceMap = new java.util.HashMap<String, Object>();

		try {
			// TDI-39566 avoid throwing an useless Exception
			boolean resumeIt = true;
			if (globalResumeTicket == false && resumeEntryMethodName != null) {
				String currentMethodName = new java.lang.Exception().getStackTrace()[0].getMethodName();
				resumeIt = resumeEntryMethodName.equals(currentMethodName);
			}
			if (resumeIt || globalResumeTicket) { // start the resume
				globalResumeTicket = true;

				/**
				 * [tWarn_2 begin ] start
				 */

				ok_Hash.put("tWarn_2", false);
				start_Hash.put("tWarn_2", System.currentTimeMillis());

				currentComponent = "tWarn_2";

				int tos_count_tWarn_2 = 0;

				/**
				 * [tWarn_2 begin ] stop
				 */

				/**
				 * [tWarn_2 main ] start
				 */

				currentComponent = "tWarn_2";

				try {

					resumeUtil.addLog("USER_DEF_LOG", "NODE:tWarn_2", "", Thread.currentThread().getId() + "", "WARN",
							"", "this is a warning", "", "");
					globalMap.put("tWarn_2_WARN_MESSAGES", "this is a warning");
					globalMap.put("tWarn_2_WARN_PRIORITY", 4);
					globalMap.put("tWarn_2_WARN_CODE", 42);

				} catch (Exception e_tWarn_2) {
					globalMap.put("tWarn_2_ERROR_MESSAGE", e_tWarn_2.getMessage());
					logIgnoredError(
							String.format("tWarn_2 - tWarn failed to log message due to internal error: %s", e_tWarn_2),
							e_tWarn_2);
				}

				tos_count_tWarn_2++;

				/**
				 * [tWarn_2 main ] stop
				 */

				/**
				 * [tWarn_2 process_data_begin ] start
				 */

				currentComponent = "tWarn_2";

				/**
				 * [tWarn_2 process_data_begin ] stop
				 */

				/**
				 * [tWarn_2 process_data_end ] start
				 */

				currentComponent = "tWarn_2";

				/**
				 * [tWarn_2 process_data_end ] stop
				 */

				/**
				 * [tWarn_2 end ] start
				 */

				currentComponent = "tWarn_2";

				ok_Hash.put("tWarn_2", true);
				end_Hash.put("tWarn_2", System.currentTimeMillis());

				/**
				 * [tWarn_2 end ] stop
				 */
			} // end the resume

		} catch (java.lang.Exception e) {

			TalendException te = new TalendException(e, currentComponent, globalMap);

			throw te;
		} catch (java.lang.Error error) {

			runStat.stopThreadStat();

			throw error;
		} finally {

			try {

				/**
				 * [tWarn_2 finally ] start
				 */

				currentComponent = "tWarn_2";

				/**
				 * [tWarn_2 finally ] stop
				 */
			} catch (java.lang.Exception e) {
				// ignore
			} catch (java.lang.Error error) {
				// ignore
			}
			resourceMap = null;
		}

		globalMap.put("tWarn_2_SUBPROCESS_STATE", 1);
	}

	public void tMsgBox_2Process(final java.util.Map<String, Object> globalMap) throws TalendException {
		globalMap.put("tMsgBox_2_SUBPROCESS_STATE", 0);

		final boolean execStat = this.execStat;

		String iterateId = "";

		String currentComponent = "";
		java.util.Map<String, Object> resourceMap = new java.util.HashMap<String, Object>();

		try {
			// TDI-39566 avoid throwing an useless Exception
			boolean resumeIt = true;
			if (globalResumeTicket == false && resumeEntryMethodName != null) {
				String currentMethodName = new java.lang.Exception().getStackTrace()[0].getMethodName();
				resumeIt = resumeEntryMethodName.equals(currentMethodName);
			}
			if (resumeIt || globalResumeTicket) { // start the resume
				globalResumeTicket = true;

				/**
				 * [tMsgBox_2 begin ] start
				 */

				ok_Hash.put("tMsgBox_2", false);
				start_Hash.put("tMsgBox_2", System.currentTimeMillis());

				currentComponent = "tMsgBox_2";

				int tos_count_tMsgBox_2 = 0;

				/**
				 * [tMsgBox_2 begin ] stop
				 */

				/**
				 * [tMsgBox_2 main ] start
				 */

				currentComponent = "tMsgBox_2";

				int messageIcontMsgBox_2 = javax.swing.JOptionPane.INFORMATION_MESSAGE;
				String titletMsgBox_2 = "Programme";
				String messagetMsgBox_2 = "Fin du traitement";
				String resulttMsgBox_2 = null;

				javax.swing.JOptionPane.showMessageDialog(null, messagetMsgBox_2, titletMsgBox_2, messageIcontMsgBox_2);
				resulttMsgBox_2 = String.valueOf(1);

				globalMap.put("tMsgBox_2_RESULT", resulttMsgBox_2);

				tos_count_tMsgBox_2++;

				/**
				 * [tMsgBox_2 main ] stop
				 */

				/**
				 * [tMsgBox_2 process_data_begin ] start
				 */

				currentComponent = "tMsgBox_2";

				/**
				 * [tMsgBox_2 process_data_begin ] stop
				 */

				/**
				 * [tMsgBox_2 process_data_end ] start
				 */

				currentComponent = "tMsgBox_2";

				/**
				 * [tMsgBox_2 process_data_end ] stop
				 */

				/**
				 * [tMsgBox_2 end ] start
				 */

				currentComponent = "tMsgBox_2";

				ok_Hash.put("tMsgBox_2", true);
				end_Hash.put("tMsgBox_2", System.currentTimeMillis());

				if (execStat) {
					runStat.updateStatOnConnection("OnComponentOk3", 0, "ok");
				}
				tWarn_3Process(globalMap);

				/**
				 * [tMsgBox_2 end ] stop
				 */
			} // end the resume

		} catch (java.lang.Exception e) {

			TalendException te = new TalendException(e, currentComponent, globalMap);

			throw te;
		} catch (java.lang.Error error) {

			runStat.stopThreadStat();

			throw error;
		} finally {

			try {

				/**
				 * [tMsgBox_2 finally ] start
				 */

				currentComponent = "tMsgBox_2";

				/**
				 * [tMsgBox_2 finally ] stop
				 */
			} catch (java.lang.Exception e) {
				// ignore
			} catch (java.lang.Error error) {
				// ignore
			}
			resourceMap = null;
		}

		globalMap.put("tMsgBox_2_SUBPROCESS_STATE", 1);
	}

	public void tWarn_3Process(final java.util.Map<String, Object> globalMap) throws TalendException {
		globalMap.put("tWarn_3_SUBPROCESS_STATE", 0);

		final boolean execStat = this.execStat;

		String iterateId = "";

		String currentComponent = "";
		java.util.Map<String, Object> resourceMap = new java.util.HashMap<String, Object>();

		try {
			// TDI-39566 avoid throwing an useless Exception
			boolean resumeIt = true;
			if (globalResumeTicket == false && resumeEntryMethodName != null) {
				String currentMethodName = new java.lang.Exception().getStackTrace()[0].getMethodName();
				resumeIt = resumeEntryMethodName.equals(currentMethodName);
			}
			if (resumeIt || globalResumeTicket) { // start the resume
				globalResumeTicket = true;

				/**
				 * [tWarn_3 begin ] start
				 */

				ok_Hash.put("tWarn_3", false);
				start_Hash.put("tWarn_3", System.currentTimeMillis());

				currentComponent = "tWarn_3";

				int tos_count_tWarn_3 = 0;

				/**
				 * [tWarn_3 begin ] stop
				 */

				/**
				 * [tWarn_3 main ] start
				 */

				currentComponent = "tWarn_3";

				try {

					resumeUtil.addLog("USER_DEF_LOG", "NODE:tWarn_3", "", Thread.currentThread().getId() + "", "WARN",
							"", "this is a warning", "", "");
					globalMap.put("tWarn_3_WARN_MESSAGES", "this is a warning");
					globalMap.put("tWarn_3_WARN_PRIORITY", 4);
					globalMap.put("tWarn_3_WARN_CODE", 42);

				} catch (Exception e_tWarn_3) {
					globalMap.put("tWarn_3_ERROR_MESSAGE", e_tWarn_3.getMessage());
					logIgnoredError(
							String.format("tWarn_3 - tWarn failed to log message due to internal error: %s", e_tWarn_3),
							e_tWarn_3);
				}

				tos_count_tWarn_3++;

				/**
				 * [tWarn_3 main ] stop
				 */

				/**
				 * [tWarn_3 process_data_begin ] start
				 */

				currentComponent = "tWarn_3";

				/**
				 * [tWarn_3 process_data_begin ] stop
				 */

				/**
				 * [tWarn_3 process_data_end ] start
				 */

				currentComponent = "tWarn_3";

				/**
				 * [tWarn_3 process_data_end ] stop
				 */

				/**
				 * [tWarn_3 end ] start
				 */

				currentComponent = "tWarn_3";

				ok_Hash.put("tWarn_3", true);
				end_Hash.put("tWarn_3", System.currentTimeMillis());

				/**
				 * [tWarn_3 end ] stop
				 */
			} // end the resume

		} catch (java.lang.Exception e) {

			TalendException te = new TalendException(e, currentComponent, globalMap);

			throw te;
		} catch (java.lang.Error error) {

			runStat.stopThreadStat();

			throw error;
		} finally {

			try {

				/**
				 * [tWarn_3 finally ] start
				 */

				currentComponent = "tWarn_3";

				/**
				 * [tWarn_3 finally ] stop
				 */
			} catch (java.lang.Exception e) {
				// ignore
			} catch (java.lang.Error error) {
				// ignore
			}
			resourceMap = null;
		}

		globalMap.put("tWarn_3_SUBPROCESS_STATE", 1);
	}

	public void tPostjob_1Process(final java.util.Map<String, Object> globalMap) throws TalendException {
		globalMap.put("tPostjob_1_SUBPROCESS_STATE", 0);

		final boolean execStat = this.execStat;

		String iterateId = "";

		String currentComponent = "";
		java.util.Map<String, Object> resourceMap = new java.util.HashMap<String, Object>();

		try {
			// TDI-39566 avoid throwing an useless Exception
			boolean resumeIt = true;
			if (globalResumeTicket == false && resumeEntryMethodName != null) {
				String currentMethodName = new java.lang.Exception().getStackTrace()[0].getMethodName();
				resumeIt = resumeEntryMethodName.equals(currentMethodName);
			}
			if (resumeIt || globalResumeTicket) { // start the resume
				globalResumeTicket = true;

				/**
				 * [tPostjob_1 begin ] start
				 */

				ok_Hash.put("tPostjob_1", false);
				start_Hash.put("tPostjob_1", System.currentTimeMillis());

				currentComponent = "tPostjob_1";

				int tos_count_tPostjob_1 = 0;

				/**
				 * [tPostjob_1 begin ] stop
				 */

				/**
				 * [tPostjob_1 main ] start
				 */

				currentComponent = "tPostjob_1";

				tos_count_tPostjob_1++;

				/**
				 * [tPostjob_1 main ] stop
				 */

				/**
				 * [tPostjob_1 process_data_begin ] start
				 */

				currentComponent = "tPostjob_1";

				/**
				 * [tPostjob_1 process_data_begin ] stop
				 */

				/**
				 * [tPostjob_1 process_data_end ] start
				 */

				currentComponent = "tPostjob_1";

				/**
				 * [tPostjob_1 process_data_end ] stop
				 */

				/**
				 * [tPostjob_1 end ] start
				 */

				currentComponent = "tPostjob_1";

				ok_Hash.put("tPostjob_1", true);
				end_Hash.put("tPostjob_1", System.currentTimeMillis());

				if (execStat) {
					runStat.updateStatOnConnection("OnComponentOk2", 0, "ok");
				}
				tMsgBox_2Process(globalMap);

				/**
				 * [tPostjob_1 end ] stop
				 */
			} // end the resume

		} catch (java.lang.Exception e) {

			TalendException te = new TalendException(e, currentComponent, globalMap);

			throw te;
		} catch (java.lang.Error error) {

			runStat.stopThreadStat();

			throw error;
		} finally {

			try {

				/**
				 * [tPostjob_1 finally ] start
				 */

				currentComponent = "tPostjob_1";

				/**
				 * [tPostjob_1 finally ] stop
				 */
			} catch (java.lang.Exception e) {
				// ignore
			} catch (java.lang.Error error) {
				// ignore
			}
			resourceMap = null;
		}

		globalMap.put("tPostjob_1_SUBPROCESS_STATE", 1);
	}

	public void tPrejob_1Process(final java.util.Map<String, Object> globalMap) throws TalendException {
		globalMap.put("tPrejob_1_SUBPROCESS_STATE", 0);

		final boolean execStat = this.execStat;

		String iterateId = "";

		String currentComponent = "";
		java.util.Map<String, Object> resourceMap = new java.util.HashMap<String, Object>();

		try {
			// TDI-39566 avoid throwing an useless Exception
			boolean resumeIt = true;
			if (globalResumeTicket == false && resumeEntryMethodName != null) {
				String currentMethodName = new java.lang.Exception().getStackTrace()[0].getMethodName();
				resumeIt = resumeEntryMethodName.equals(currentMethodName);
			}
			if (resumeIt || globalResumeTicket) { // start the resume
				globalResumeTicket = true;

				/**
				 * [tPrejob_1 begin ] start
				 */

				ok_Hash.put("tPrejob_1", false);
				start_Hash.put("tPrejob_1", System.currentTimeMillis());

				currentComponent = "tPrejob_1";

				int tos_count_tPrejob_1 = 0;

				/**
				 * [tPrejob_1 begin ] stop
				 */

				/**
				 * [tPrejob_1 main ] start
				 */

				currentComponent = "tPrejob_1";

				tos_count_tPrejob_1++;

				/**
				 * [tPrejob_1 main ] stop
				 */

				/**
				 * [tPrejob_1 process_data_begin ] start
				 */

				currentComponent = "tPrejob_1";

				/**
				 * [tPrejob_1 process_data_begin ] stop
				 */

				/**
				 * [tPrejob_1 process_data_end ] start
				 */

				currentComponent = "tPrejob_1";

				/**
				 * [tPrejob_1 process_data_end ] stop
				 */

				/**
				 * [tPrejob_1 end ] start
				 */

				currentComponent = "tPrejob_1";

				ok_Hash.put("tPrejob_1", true);
				end_Hash.put("tPrejob_1", System.currentTimeMillis());

				if (execStat) {
					runStat.updateStatOnConnection("OnComponentOk1", 0, "ok");
				}
				tMsgBox_1Process(globalMap);

				/**
				 * [tPrejob_1 end ] stop
				 */
			} // end the resume

		} catch (java.lang.Exception e) {

			TalendException te = new TalendException(e, currentComponent, globalMap);

			throw te;
		} catch (java.lang.Error error) {

			runStat.stopThreadStat();

			throw error;
		} finally {

			try {

				/**
				 * [tPrejob_1 finally ] start
				 */

				currentComponent = "tPrejob_1";

				/**
				 * [tPrejob_1 finally ] stop
				 */
			} catch (java.lang.Exception e) {
				// ignore
			} catch (java.lang.Error error) {
				// ignore
			}
			resourceMap = null;
		}

		globalMap.put("tPrejob_1_SUBPROCESS_STATE", 1);
	}

	public void tWarn_1Process(final java.util.Map<String, Object> globalMap) throws TalendException {
		globalMap.put("tWarn_1_SUBPROCESS_STATE", 0);

		final boolean execStat = this.execStat;

		String iterateId = "";

		String currentComponent = "";
		java.util.Map<String, Object> resourceMap = new java.util.HashMap<String, Object>();

		try {
			// TDI-39566 avoid throwing an useless Exception
			boolean resumeIt = true;
			if (globalResumeTicket == false && resumeEntryMethodName != null) {
				String currentMethodName = new java.lang.Exception().getStackTrace()[0].getMethodName();
				resumeIt = resumeEntryMethodName.equals(currentMethodName);
			}
			if (resumeIt || globalResumeTicket) { // start the resume
				globalResumeTicket = true;

				/**
				 * [tWarn_1 begin ] start
				 */

				ok_Hash.put("tWarn_1", false);
				start_Hash.put("tWarn_1", System.currentTimeMillis());

				currentComponent = "tWarn_1";

				int tos_count_tWarn_1 = 0;

				/**
				 * [tWarn_1 begin ] stop
				 */

				/**
				 * [tWarn_1 main ] start
				 */

				currentComponent = "tWarn_1";

				try {

					resumeUtil.addLog("USER_DEF_LOG", "NODE:tWarn_1", "", Thread.currentThread().getId() + "", "WARN",
							"", "this is a warning", "", "");
					globalMap.put("tWarn_1_WARN_MESSAGES", "this is a warning");
					globalMap.put("tWarn_1_WARN_PRIORITY", 4);
					globalMap.put("tWarn_1_WARN_CODE", 42);

				} catch (Exception e_tWarn_1) {
					globalMap.put("tWarn_1_ERROR_MESSAGE", e_tWarn_1.getMessage());
					logIgnoredError(
							String.format("tWarn_1 - tWarn failed to log message due to internal error: %s", e_tWarn_1),
							e_tWarn_1);
				}

				tos_count_tWarn_1++;

				/**
				 * [tWarn_1 main ] stop
				 */

				/**
				 * [tWarn_1 process_data_begin ] start
				 */

				currentComponent = "tWarn_1";

				/**
				 * [tWarn_1 process_data_begin ] stop
				 */

				/**
				 * [tWarn_1 process_data_end ] start
				 */

				currentComponent = "tWarn_1";

				/**
				 * [tWarn_1 process_data_end ] stop
				 */

				/**
				 * [tWarn_1 end ] start
				 */

				currentComponent = "tWarn_1";

				ok_Hash.put("tWarn_1", true);
				end_Hash.put("tWarn_1", System.currentTimeMillis());

				/**
				 * [tWarn_1 end ] stop
				 */
			} // end the resume

			if (resumeEntryMethodName == null || globalResumeTicket) {
				resumeUtil.addLog("CHECKPOINT", "CONNECTION:SUBJOB_OK:tWarn_1:OnSubjobOk", "",
						Thread.currentThread().getId() + "", "", "", "", "", "");
			}

			if (execStat) {
				runStat.updateStatOnConnection("OnSubjobOk2", 0, "ok");
			}

			tFileInputExcel_1Process(globalMap);

		} catch (java.lang.Exception e) {

			TalendException te = new TalendException(e, currentComponent, globalMap);

			throw te;
		} catch (java.lang.Error error) {

			runStat.stopThreadStat();

			throw error;
		} finally {

			try {

				/**
				 * [tWarn_1 finally ] start
				 */

				currentComponent = "tWarn_1";

				/**
				 * [tWarn_1 finally ] stop
				 */
			} catch (java.lang.Exception e) {
				// ignore
			} catch (java.lang.Error error) {
				// ignore
			}
			resourceMap = null;
		}

		globalMap.put("tWarn_1_SUBPROCESS_STATE", 1);
	}

	public String resuming_logs_dir_path = null;
	public String resuming_checkpoint_path = null;
	public String parent_part_launcher = null;
	private String resumeEntryMethodName = null;
	private boolean globalResumeTicket = false;

	public boolean watch = false;
	// portStats is null, it means don't execute the statistics
	public Integer portStats = null;
	public int portTraces = 4334;
	public String clientHost;
	public String defaultClientHost = "localhost";
	public String contextStr = "Default";
	public boolean isDefaultContext = true;
	public String pid = "0";
	public String rootPid = null;
	public String fatherPid = null;
	public String fatherNode = null;
	public long startTime = 0;
	public boolean isChildJob = false;
	public String log4jLevel = "";

	private boolean enableLogStash;

	private boolean execStat = true;

	private ThreadLocal<java.util.Map<String, String>> threadLocal = new ThreadLocal<java.util.Map<String, String>>() {
		protected java.util.Map<String, String> initialValue() {
			java.util.Map<String, String> threadRunResultMap = new java.util.HashMap<String, String>();
			threadRunResultMap.put("errorCode", null);
			threadRunResultMap.put("status", "");
			return threadRunResultMap;
		};
	};

	protected PropertiesWithType context_param = new PropertiesWithType();
	public java.util.Map<String, Object> parentContextMap = new java.util.HashMap<String, Object>();

	public String status = "";

	public static void main(String[] args) {
		final TP_MAJ TP_MAJClass = new TP_MAJ();

		int exitCode = TP_MAJClass.runJobInTOS(args);

		System.exit(exitCode);
	}

	public String[][] runJob(String[] args) {

		int exitCode = runJobInTOS(args);
		String[][] bufferValue = new String[][] { { Integer.toString(exitCode) } };

		return bufferValue;
	}

	public boolean hastBufferOutputComponent() {
		boolean hastBufferOutput = false;

		return hastBufferOutput;
	}

	public int runJobInTOS(String[] args) {
		// reset status
		status = "";

		String lastStr = "";
		for (String arg : args) {
			if (arg.equalsIgnoreCase("--context_param")) {
				lastStr = arg;
			} else if (lastStr.equals("")) {
				evalParam(arg);
			} else {
				evalParam(lastStr + " " + arg);
				lastStr = "";
			}
		}
		enableLogStash = "true".equalsIgnoreCase(System.getProperty("audit.enabled"));

		if (clientHost == null) {
			clientHost = defaultClientHost;
		}

		if (pid == null || "0".equals(pid)) {
			pid = TalendString.getAsciiRandomString(6);
		}

		if (rootPid == null) {
			rootPid = pid;
		}
		if (fatherPid == null) {
			fatherPid = pid;
		} else {
			isChildJob = true;
		}

		if (portStats != null) {
			// portStats = -1; //for testing
			if (portStats < 0 || portStats > 65535) {
				// issue:10869, the portStats is invalid, so this client socket can't open
				System.err.println("The statistics socket port " + portStats + " is invalid.");
				execStat = false;
			}
		} else {
			execStat = false;
		}
		boolean inOSGi = routines.system.BundleUtils.inOSGi();

		if (inOSGi) {
			java.util.Dictionary<String, Object> jobProperties = routines.system.BundleUtils.getJobProperties(jobName);

			if (jobProperties != null && jobProperties.get("context") != null) {
				contextStr = (String) jobProperties.get("context");
			}
		}

		try {
			// call job/subjob with an existing context, like: --context=production. if
			// without this parameter, there will use the default context instead.
			java.io.InputStream inContext = TP_MAJ.class.getClassLoader()
					.getResourceAsStream("myfirstjob/tp_maj_0_1/contexts/" + contextStr + ".properties");
			if (inContext == null) {
				inContext = TP_MAJ.class.getClassLoader()
						.getResourceAsStream("config/contexts/" + contextStr + ".properties");
			}
			if (inContext != null) {
				try {
					// defaultProps is in order to keep the original context value
					if (context != null && context.isEmpty()) {
						defaultProps.load(inContext);
						context = new ContextProperties(defaultProps);
					}
				} finally {
					inContext.close();
				}
			} else if (!isDefaultContext) {
				// print info and job continue to run, for case: context_param is not empty.
				System.err.println("Could not find the context " + contextStr);
			}

			if (!context_param.isEmpty()) {
				context.putAll(context_param);
				// set types for params from parentJobs
				for (Object key : context_param.keySet()) {
					String context_key = key.toString();
					String context_type = context_param.getContextType(context_key);
					context.setContextType(context_key, context_type);

				}
			}
			class ContextProcessing {
				private void processContext_0() {
				}

				public void processAllContext() {
					processContext_0();
				}
			}

			new ContextProcessing().processAllContext();
		} catch (java.io.IOException ie) {
			System.err.println("Could not load context " + contextStr);
			ie.printStackTrace();
		}

		// get context value from parent directly
		if (parentContextMap != null && !parentContextMap.isEmpty()) {
		}

		// Resume: init the resumeUtil
		resumeEntryMethodName = ResumeUtil.getResumeEntryMethodName(resuming_checkpoint_path);
		resumeUtil = new ResumeUtil(resuming_logs_dir_path, isChildJob, rootPid);
		resumeUtil.initCommonInfo(pid, rootPid, fatherPid, projectName, jobName, contextStr, jobVersion);

		List<String> parametersToEncrypt = new java.util.ArrayList<String>();
		// Resume: jobStart
		resumeUtil.addLog("JOB_STARTED", "JOB:" + jobName, parent_part_launcher, Thread.currentThread().getId() + "",
				"", "", "", "", resumeUtil.convertToJsonText(context, parametersToEncrypt));

		if (execStat) {
			try {
				runStat.openSocket(!isChildJob);
				runStat.setAllPID(rootPid, fatherPid, pid, jobName);
				runStat.startThreadStat(clientHost, portStats);
				runStat.updateStatOnJob(RunStat.JOBSTART, fatherNode);
			} catch (java.io.IOException ioException) {
				ioException.printStackTrace();
			}
		}

		java.util.concurrent.ConcurrentHashMap<Object, Object> concurrentHashMap = new java.util.concurrent.ConcurrentHashMap<Object, Object>();
		globalMap.put("concurrentHashMap", concurrentHashMap);

		long startUsedMemory = Runtime.getRuntime().totalMemory() - Runtime.getRuntime().freeMemory();
		long endUsedMemory = 0;
		long end = 0;

		startTime = System.currentTimeMillis();

		this.globalResumeTicket = true;// to run tPreJob

		try {
			errorCode = null;
			tPrejob_1Process(globalMap);
			if (!"failure".equals(status)) {
				status = "end";
			}
		} catch (TalendException e_tPrejob_1) {
			globalMap.put("tPrejob_1_SUBPROCESS_STATE", -1);

			e_tPrejob_1.printStackTrace();

		}

		this.globalResumeTicket = false;// to run others jobs

		try {
			errorCode = null;
			tDie_1Process(globalMap);
			if (!"failure".equals(status)) {
				status = "end";
			}
		} catch (TalendException e_tDie_1) {
			globalMap.put("tDie_1_SUBPROCESS_STATE", -1);

			e_tDie_1.printStackTrace();

		}
		try {
			errorCode = null;
			tWarn_1Process(globalMap);
			if (!"failure".equals(status)) {
				status = "end";
			}
		} catch (TalendException e_tWarn_1) {
			globalMap.put("tWarn_1_SUBPROCESS_STATE", -1);

			e_tWarn_1.printStackTrace();

		}

		this.globalResumeTicket = true;// to run tPostJob

		try {
			errorCode = null;
			tPostjob_1Process(globalMap);
			if (!"failure".equals(status)) {
				status = "end";
			}
		} catch (TalendException e_tPostjob_1) {
			globalMap.put("tPostjob_1_SUBPROCESS_STATE", -1);

			e_tPostjob_1.printStackTrace();

		}

		end = System.currentTimeMillis();

		if (watch) {
			System.out.println((end - startTime) + " milliseconds");
		}

		endUsedMemory = Runtime.getRuntime().totalMemory() - Runtime.getRuntime().freeMemory();
		if (false) {
			System.out.println((endUsedMemory - startUsedMemory) + " bytes memory increase when running : TP_MAJ");
		}

		if (execStat) {
			runStat.updateStatOnJob(RunStat.JOBEND, fatherNode);
			runStat.stopThreadStat();
		}
		int returnCode = 0;

		if (errorCode == null) {
			returnCode = status != null && status.equals("failure") ? 1 : 0;
		} else {
			returnCode = errorCode.intValue();
		}
		resumeUtil.addLog("JOB_ENDED", "JOB:" + jobName, parent_part_launcher, Thread.currentThread().getId() + "", "",
				"" + returnCode, "", "", "");

		return returnCode;

	}

	// only for OSGi env
	public void destroy() {

	}

	private java.util.Map<String, Object> getSharedConnections4REST() {
		java.util.Map<String, Object> connections = new java.util.HashMap<String, Object>();

		return connections;
	}

	private void evalParam(String arg) {
		if (arg.startsWith("--resuming_logs_dir_path")) {
			resuming_logs_dir_path = arg.substring(25);
		} else if (arg.startsWith("--resuming_checkpoint_path")) {
			resuming_checkpoint_path = arg.substring(27);
		} else if (arg.startsWith("--parent_part_launcher")) {
			parent_part_launcher = arg.substring(23);
		} else if (arg.startsWith("--watch")) {
			watch = true;
		} else if (arg.startsWith("--stat_port=")) {
			String portStatsStr = arg.substring(12);
			if (portStatsStr != null && !portStatsStr.equals("null")) {
				portStats = Integer.parseInt(portStatsStr);
			}
		} else if (arg.startsWith("--trace_port=")) {
			portTraces = Integer.parseInt(arg.substring(13));
		} else if (arg.startsWith("--client_host=")) {
			clientHost = arg.substring(14);
		} else if (arg.startsWith("--context=")) {
			contextStr = arg.substring(10);
			isDefaultContext = false;
		} else if (arg.startsWith("--father_pid=")) {
			fatherPid = arg.substring(13);
		} else if (arg.startsWith("--root_pid=")) {
			rootPid = arg.substring(11);
		} else if (arg.startsWith("--father_node=")) {
			fatherNode = arg.substring(14);
		} else if (arg.startsWith("--pid=")) {
			pid = arg.substring(6);
		} else if (arg.startsWith("--context_type")) {
			String keyValue = arg.substring(15);
			int index = -1;
			if (keyValue != null && (index = keyValue.indexOf('=')) > -1) {
				if (fatherPid == null) {
					context_param.setContextType(keyValue.substring(0, index),
							replaceEscapeChars(keyValue.substring(index + 1)));
				} else { // the subjob won't escape the especial chars
					context_param.setContextType(keyValue.substring(0, index), keyValue.substring(index + 1));
				}

			}

		} else if (arg.startsWith("--context_param")) {
			String keyValue = arg.substring(16);
			int index = -1;
			if (keyValue != null && (index = keyValue.indexOf('=')) > -1) {
				if (fatherPid == null) {
					context_param.put(keyValue.substring(0, index), replaceEscapeChars(keyValue.substring(index + 1)));
				} else { // the subjob won't escape the especial chars
					context_param.put(keyValue.substring(0, index), keyValue.substring(index + 1));
				}
			}
		} else if (arg.startsWith("--log4jLevel=")) {
			log4jLevel = arg.substring(13);
		} else if (arg.startsWith("--audit.enabled") && arg.contains("=")) {// for trunjob call
			final int equal = arg.indexOf('=');
			final String key = arg.substring("--".length(), equal);
			System.setProperty(key, arg.substring(equal + 1));
		}
	}

	private static final String NULL_VALUE_EXPRESSION_IN_COMMAND_STRING_FOR_CHILD_JOB_ONLY = "<TALEND_NULL>";

	private final String[][] escapeChars = { { "\\\\", "\\" }, { "\\n", "\n" }, { "\\'", "\'" }, { "\\r", "\r" },
			{ "\\f", "\f" }, { "\\b", "\b" }, { "\\t", "\t" } };

	private String replaceEscapeChars(String keyValue) {

		if (keyValue == null || ("").equals(keyValue.trim())) {
			return keyValue;
		}

		StringBuilder result = new StringBuilder();
		int currIndex = 0;
		while (currIndex < keyValue.length()) {
			int index = -1;
			// judege if the left string includes escape chars
			for (String[] strArray : escapeChars) {
				index = keyValue.indexOf(strArray[0], currIndex);
				if (index >= 0) {

					result.append(keyValue.substring(currIndex, index + strArray[0].length()).replace(strArray[0],
							strArray[1]));
					currIndex = index + strArray[0].length();
					break;
				}
			}
			// if the left string doesn't include escape chars, append the left into the
			// result
			if (index < 0) {
				result.append(keyValue.substring(currIndex));
				currIndex = currIndex + keyValue.length();
			}
		}

		return result.toString();
	}

	public Integer getErrorCode() {
		return errorCode;
	}

	public String getStatus() {
		return status;
	}

	ResumeUtil resumeUtil = null;
}
/************************************************************************************************
 * 671549 characters generated by Talend Open Studio for Data Integration on the
 * 15 octobre 2023, 20:03:14 CEST
 ************************************************************************************************/